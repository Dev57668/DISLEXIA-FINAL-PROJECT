import React, { useEffect, useRef } from "react";

/**
 * JungleEnvironment - Layered Hand-Drawn Daytime Jungle Scenery
 * 
 * Layers:
 * 1. Sunny Sky Dome with warm radial sunburst & drifting clouds
 * 2. Distant misty canopy mountain ridges & soaring silhouettes
 * 3. Midground ancient banyan trees & flowering jungle vines
 * 4. Fluttering tropical morpho butterflies & subtle sun spores
 * 5. Foreground framing palm fronds & monstera leaves with gentle breeze sway
 * 
 * NOTE: Strict compliance with design brief - ZERO mouse parallax.
 * Motion is coordinated, calm, and performance-optimized.
 */
export default function JungleEnvironment() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    // 24 gentle golden sun spores
    const spores = Array.from({ length: 24 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      radius: Math.random() * 2.2 + 1.2,
      baseAlpha: Math.random() * 0.4 + 0.2,
      phase: Math.random() * Math.PI * 2,
      speedX: (Math.random() - 0.4) * 0.35,
      speedY: -Math.random() * 0.4 - 0.2,
      hue: Math.random() > 0.45 ? 46 : 82
    }));

    let time = 0;
    const render = () => {
      time += 0.018;
      ctx.clearRect(0, 0, width, height);

      for (let i = 0; i < spores.length; i++) {
        const s = spores[i];
        s.x += s.speedX + Math.sin(time + s.phase) * 0.25;
        s.y += s.speedY;

        if (s.y < -10) {
          s.y = height + 10;
          s.x = Math.random() * width;
        }
        if (s.x < -10) s.x = width + 10;
        if (s.x > width + 10) s.x = -10;

        const pulse = s.baseAlpha + Math.sin(time * 2 + s.phase) * 0.15;
        const alpha = Math.max(0.08, Math.min(0.7, pulse));

        ctx.beginPath();
        const grad = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, s.radius * 2.6);
        grad.addColorStop(0, `hsla(${s.hue}, 95%, 65%, ${alpha})`);
        grad.addColorStop(0.5, `hsla(${s.hue}, 90%, 55%, ${alpha * 0.4})`);
        grad.addColorStop(1, `hsla(${s.hue}, 90%, 50%, 0)`);
        ctx.fillStyle = grad;
        ctx.arc(s.x, s.y, s.radius * 2.6, 0, Math.PI * 2);
        ctx.fill();
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <div className="jungle-world-scenery" aria-hidden="true">
      {/* 1. SKY DOME: Warm sunny tropical sky with radial sunburst */}
      <div className="sky-dome">
        <div className="sun-core" />
        <div className="sun-radiance" />

        {/* Drifting Hand-Drawn Fluffy Clouds */}
        <div className="clouds-track">
          <div className="storybook-cloud cloud-1" />
          <div className="storybook-cloud cloud-2" />
          <div className="storybook-cloud cloud-3" />
        </div>

        {/* Gliding Bird Silhouettes */}
        <div className="sky-birds">
          <div className="bird-silhouette bird-1">
            <svg viewBox="0 0 32 14" width="28" height="12" fill="none">
              <path d="M0 10 Q 8 0 16 7 Q 24 0 32 10" stroke="#78350f" strokeWidth="2.5" strokeLinecap="round" opacity="0.4" />
            </svg>
          </div>
          <div className="bird-silhouette bird-2">
            <svg viewBox="0 0 32 14" width="22" height="10" fill="none">
              <path d="M0 10 Q 8 0 16 7 Q 24 0 32 10" stroke="#78350f" strokeWidth="2.5" strokeLinecap="round" opacity="0.35" />
            </svg>
          </div>
        </div>
      </div>

      {/* 2. DISTANT JUNGLE RIDGES: Misty mountains & layered canopy silhouette */}
      <div className="distant-canopy-ridge">
        <svg viewBox="0 0 1440 280" preserveAspectRatio="none" style={{ width: "100%", height: "100%" }} fill="none">
          {/* Farthest Mountain Ridge (Pale Sage Misty Green) */}
          <path
            d="M0 160 Q 200 90 400 130 T 800 100 T 1200 120 T 1440 150 L 1440 280 L 0 280 Z"
            fill="#d9f99d"
            opacity="0.6"
          />
          {/* Middle Canopy Ridge (Soft Jade Green) */}
          <path
            d="M0 190 Q 250 140 500 170 T 950 150 T 1440 180 L 1440 280 L 0 280 Z"
            fill="#a3e635"
            opacity="0.75"
          />
          {/* Near Canopy Tree Tops (Lush Jungle Green with bumpy hand-drawn silhouettes) */}
          <path
            d="M0 220 
               C 50 195, 90 200, 130 220 
               C 180 185, 230 190, 280 220 
               C 340 180, 400 185, 460 225 
               C 520 190, 580 195, 640 225 
               C 700 180, 760 185, 820 220 
               C 890 185, 950 190, 1010 225 
               C 1080 180, 1140 185, 1200 220 
               C 1270 190, 1340 195, 1440 225 
               L 1440 280 L 0 280 Z"
            fill="#4ade80"
            opacity="0.85"
          />
        </svg>
      </div>

      {/* 3. LIGHTWEIGHT CANVAS SPORES */}
      <canvas ref={canvasRef} className="spores-layer" />

      {/* 4. FLUTTERING TROPICAL BUTTERFLIES */}
      <div className="jungle-butterflies">
        <div className="tropical-butterfly butterfly-blue">
          <div className="butterfly-wing wing-l" />
          <div className="butterfly-body" />
          <div className="butterfly-wing wing-r" />
        </div>
        <div className="tropical-butterfly butterfly-gold">
          <div className="butterfly-wing wing-l" />
          <div className="butterfly-body" />
          <div className="butterfly-wing wing-r" />
        </div>
      </div>

      {/* 5. FOREGROUND LUSH TROPICAL VEGETATION: Corner Palms & Monsteras */}
      <div className="foreground-foliage-left">
        <svg viewBox="0 0 320 380" fill="none" style={{ width: "100%", height: "100%" }}>
          {/* Main Arched Vine */}
          <path d="M-10 100 C 60 120, 140 220, 180 340" stroke="#78350f" strokeWidth="12" strokeLinecap="round" />
          <path d="M-10 100 C 60 120, 140 220, 180 340" stroke="#a16207" strokeWidth="6" strokeLinecap="round" />
          
          {/* Giant Monstera Leaf */}
          <g transform="translate(80, 80) rotate(24)">
            <path
              d="M0 0 C 60 -40, 150 -25, 180 50 C 140 110, 50 85, 0 0 Z"
              fill="#22c55e"
              stroke="#14532d"
              strokeWidth="4"
              strokeLinejoin="round"
            />
            {/* Cutouts */}
            <path d="M40 8 C 80 -8, 120 20, 45 22" fill="#f7fee7" stroke="#14532d" strokeWidth="3" />
            <path d="M85 30 C 130 20, 155 60, 90 50" fill="#f7fee7" stroke="#14532d" strokeWidth="3" />
            {/* Vein */}
            <path d="M0 0 Q 90 25 175 50" stroke="#15803d" strokeWidth="4" strokeLinecap="round" />
          </g>

          {/* Tropical Palm Frond */}
          <g transform="translate(20, 180) rotate(-10)">
            <path
              d="M0 0 C 70 -50, 180 -30, 210 50 C 130 90, 40 60, 0 0 Z"
              fill="#16a34a"
              stroke="#0f3822"
              strokeWidth="4"
            />
            <path d="M0 0 Q 105 15 205 50" stroke="#14532d" strokeWidth="4" strokeLinecap="round" />
          </g>

          {/* Exotic Tropical Flower */}
          <g transform="translate(160, 240)">
            <ellipse cx="0" cy="10" rx="10" ry="16" fill="#f43f5e" stroke="#881337" strokeWidth="3" />
            <ellipse cx="-10" cy="5" rx="9" ry="14" fill="#fb7185" stroke="#881337" strokeWidth="3" />
            <ellipse cx="10" cy="5" rx="9" ry="14" fill="#fb7185" stroke="#881337" strokeWidth="3" />
            <circle cx="0" cy="5" r="4.5" fill="#facc15" stroke="#a16207" strokeWidth="2" />
          </g>
        </svg>
      </div>

      <div className="foreground-foliage-right">
        <svg viewBox="0 0 340 390" fill="none" style={{ width: "100%", height: "100%" }}>
          {/* Main Arched Vine */}
          <path d="M350 80 C 270 120, 190 230, 140 360" stroke="#78350f" strokeWidth="14" strokeLinecap="round" />
          <path d="M350 80 C 270 120, 190 230, 140 360" stroke="#a16207" strokeWidth="7" strokeLinecap="round" />

          {/* Large Sunlit Banana Leaf */}
          <g transform="translate(100, 60) rotate(-28)">
            <path
              d="M0 0 C 70 -60, 200 -40, 230 55 C 160 115, 60 80, 0 0 Z"
              fill="#84cc16"
              stroke="#14532d"
              strokeWidth="4"
              strokeLinejoin="round"
            />
            <path d="M0 0 Q 110 12 225 52" stroke="#4d7c0f" strokeWidth="4.5" strokeLinecap="round" />
            <path d="M50 5 L 80 -25" stroke="#4d7c0f" strokeWidth="3" />
            <path d="M100 18 L 140 -15" stroke="#4d7c0f" strokeWidth="3" />
            <path d="M150 32 L 190 5" stroke="#4d7c0f" strokeWidth="3" />
          </g>

          {/* Hanging Orchid Bloom */}
          <g transform="translate(160, 220)">
            <ellipse cx="0" cy="12" rx="10" ry="16" fill="#ec4899" stroke="#831843" strokeWidth="3" />
            <ellipse cx="-12" cy="6" rx="9" ry="14" fill="#f472b6" stroke="#831843" strokeWidth="3" />
            <ellipse cx="12" cy="6" rx="9" ry="14" fill="#f472b6" stroke="#831843" strokeWidth="3" />
            <circle cx="0" cy="6" r="4.5" fill="#fef08a" stroke="#ca8a04" strokeWidth="2" />
          </g>
        </svg>
      </div>

      <style>{`
        .jungle-world-scenery {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: 0;
          overflow: hidden;
        }

        /* 1. SKY DOME & SUN */
        .sky-dome {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 55%;
          background: linear-gradient(180deg, #bae6fd 0%, #e0f2fe 50%, #f7fee7 100%);
        }

        .sun-core {
          position: absolute;
          top: 40px;
          right: 120px;
          width: 90px;
          height: 90px;
          border-radius: 50%;
          background: radial-gradient(circle, #ffffff 0%, #fef08a 60%, #f59e0b 100%);
          box-shadow: 0 0 50px rgba(245, 158, 11, 0.6), 0 0 100px rgba(254, 240, 138, 0.45);
          animation: sunPulse 6s ease-in-out infinite alternate;
        }

        .sun-radiance {
          position: absolute;
          top: -80px;
          right: 0px;
          width: 500px;
          height: 500px;
          background: radial-gradient(circle, rgba(254, 240, 138, 0.35) 0%, rgba(254, 240, 138, 0.1) 50%, transparent 75%);
          pointer-events: none;
        }

        @keyframes sunPulse {
          0% { transform: scale(0.96); filter: brightness(1); }
          100% { transform: scale(1.04); filter: brightness(1.1); }
        }

        /* STORYBOOK CLOUDS */
        .clouds-track {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
        }

        .storybook-cloud {
          position: absolute;
          background: #ffffff;
          border-radius: 999px;
          box-shadow: 0 8px 16px rgba(186, 230, 253, 0.4);
          opacity: 0.88;
        }

        .storybook-cloud::before,
        .storybook-cloud::after {
          content: "";
          position: absolute;
          background: inherit;
          border-radius: 50%;
        }

        .cloud-1 {
          top: 60px;
          left: -180px;
          width: 140px;
          height: 45px;
          animation: cloudDrift 55s linear infinite;
        }
        .cloud-1::before {
          width: 55px;
          height: 55px;
          top: -26px;
          left: 20px;
        }
        .cloud-1::after {
          width: 70px;
          height: 70px;
          top: -36px;
          left: 55px;
        }

        .cloud-2 {
          top: 140px;
          left: -240px;
          width: 190px;
          height: 55px;
          animation: cloudDrift 75s linear infinite 18s;
          opacity: 0.75;
        }
        .cloud-2::before {
          width: 75px;
          height: 75px;
          top: -38px;
          left: 30px;
        }
        .cloud-2::after {
          width: 90px;
          height: 90px;
          top: -46px;
          left: 80px;
        }

        .cloud-3 {
          top: 30px;
          left: -200px;
          width: 160px;
          height: 48px;
          animation: cloudDrift 62s linear infinite 35s;
          opacity: 0.65;
        }
        .cloud-3::before {
          width: 60px;
          height: 60px;
          top: -30px;
          left: 25px;
        }
        .cloud-3::after {
          width: 75px;
          height: 75px;
          top: -40px;
          left: 65px;
        }

        @keyframes cloudDrift {
          0% { transform: translateX(0); }
          100% { transform: translateX(calc(100vw + 350px)); }
        }

        /* GLIDING BIRDS */
        .sky-birds {
          position: absolute;
          top: 90px;
          width: 100%;
        }
        .bird-1 {
          position: absolute;
          left: -50px;
          top: 0;
          animation: birdFly 32s linear infinite 5s;
        }
        .bird-2 {
          position: absolute;
          left: -80px;
          top: 35px;
          animation: birdFly 35s linear infinite 14s;
        }

        @keyframes birdFly {
          0% { transform: translate(0, 0); }
          50% { transform: translate(60vw, 25px); }
          100% { transform: translate(calc(100vw + 100px), 0); }
        }

        /* 2. DISTANT RIDGE */
        .distant-canopy-ridge {
          position: absolute;
          bottom: 0;
          left: 0;
          width: 100%;
          height: 280px;
        }

        /* 3. SPORES CANVAS */
        .spores-layer {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
        }

        /* 4. TROPICAL BUTTERFLIES */
        .jungle-butterflies {
          position: absolute;
          width: 100%;
          height: 100%;
        }

        .tropical-butterfly {
          position: absolute;
          display: flex;
          align-items: center;
          gap: 1px;
        }

        .butterfly-blue {
          top: 35%;
          left: 18%;
          animation: butterflyFlutter1 22s ease-in-out infinite;
        }

        .butterfly-gold {
          top: 48%;
          right: 22%;
          animation: butterflyFlutter2 26s ease-in-out infinite 8s;
        }

        .butterfly-body {
          width: 4px;
          height: 14px;
          background: #451a03;
          border-radius: 999px;
        }

        .butterfly-wing {
          width: 13px;
          height: 18px;
          border-radius: 12px 6px 14px 4px;
          animation: wingBeat 0.16s ease-in-out infinite alternate;
        }

        .butterfly-blue .butterfly-wing {
          background: linear-gradient(135deg, #38bdf8 0%, #0284c7 100%);
          border: 1px solid #0369a1;
        }

        .butterfly-gold .butterfly-wing {
          background: linear-gradient(135deg, #facc15 0%, #ea580c 100%);
          border: 1px solid #c2410c;
        }

        .wing-l { transform-origin: right center; }
        .wing-r { transform-origin: left center; transform: scaleX(-1); }

        @keyframes wingBeat {
          0% { transform: scaleX(1); }
          100% { transform: scaleX(0.18); }
        }

        @keyframes butterflyFlutter1 {
          0% { transform: translate(0, 0) rotate(5deg); }
          25% { transform: translate(80px, -45px) rotate(-10deg); }
          50% { transform: translate(160px, 30px) rotate(15deg); }
          75% { transform: translate(90px, 70px) rotate(-5deg); }
          100% { transform: translate(0, 0) rotate(5deg); }
        }

        @keyframes butterflyFlutter2 {
          0% { transform: translate(0, 0) rotate(-8deg); }
          30% { transform: translate(-70px, 50px) rotate(12deg); }
          60% { transform: translate(-140px, -30px) rotate(-15deg); }
          85% { transform: translate(-50px, -60px) rotate(8deg); }
          100% { transform: translate(0, 0) rotate(-8deg); }
        }

        /* 5. FOREGROUND CORNER FOLIAGE */
        .foreground-foliage-left {
          position: fixed;
          bottom: -40px;
          left: -40px;
          width: 320px;
          height: 380px;
          z-index: 30;
          transform-origin: bottom left;
          animation: foliageSwayLeft 7s ease-in-out infinite alternate;
        }

        .foreground-foliage-right {
          position: fixed;
          bottom: -40px;
          right: -40px;
          width: 340px;
          height: 390px;
          z-index: 30;
          transform-origin: bottom right;
          animation: foliageSwayRight 8s ease-in-out infinite alternate;
        }

        @keyframes foliageSwayLeft {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(2.8deg); }
        }

        @keyframes foliageSwayRight {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(-2.5deg); }
        }

        @media (max-width: 768px) {
          .foreground-foliage-left,
          .foreground-foliage-right {
            width: 220px;
            height: 260px;
          }
        }
      `}</style>
    </div>
  );
}
