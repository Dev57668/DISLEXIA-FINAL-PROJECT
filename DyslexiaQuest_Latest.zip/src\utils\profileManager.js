// =========================================================================
// DYSLEXIAQUEST: MULTI-PROFILE PERSISTENT STORAGE MANAGER
// Ensures all student profiles created by users are saved in localStorage
// and remain accessible across all screens and sessions.
// =========================================================================

const PROFILES_STORAGE_KEY = "dyslexia_student_profiles_list";
const ACTIVE_PROFILE_KEY = "dyslexia_student_profile";

export const DEFAULT_PROFILES = [
  {
    id: "profile_liam_parker",
    studentName: "Liam Parker",
    studentAge: "8",
    studentClass: "3",
    schoolName: "St. Jude Academy",
    parentName: "David Parker",
    parentPhone: "9876543210",
    parentEmail: "david.parker@example.com",
    studentPhoto: "",
    audioData: "",
    createdAt: "2026-08-15T10:00:00.000Z",
    riskLevel: "Moderate (Visual Orthography)",
    riskColor: "#f59e0b",
    speed: "+18%",
    spelling: "+12%",
    recognition: "+24%",
    phonological: "+15%",
    streak: "5 Days",
    sessions: "164 Questions Completed",
    hours: "4.8 hrs",
    difficulty: "Mirror letter reversals on b/d and p/q under speed pressure; letter transposition in multisyllabic words.",
    recommendedModule: "Module 01: Visual Perception & Orthography",
    recommendedStageId: 1
  },
  {
    id: "profile_emma_watson",
    studentName: "Emma Watson",
    studentAge: "9",
    studentClass: "4",
    schoolName: "Cambridge Elementary",
    parentName: "Sarah Watson",
    parentPhone: "9812345678",
    parentEmail: "sarah.w@example.com",
    studentPhoto: "",
    audioData: "",
    createdAt: "2026-08-20T11:30:00.000Z",
    riskLevel: "Low Risk (Grade Aligned)",
    riskColor: "#2dd4bf",
    speed: "+22%",
    spelling: "+19%",
    recognition: "+31%",
    phonological: "+26%",
    streak: "7 Days",
    sessions: "210 Questions Completed",
    hours: "6.2 hrs",
    difficulty: "Rapid oral reading fluency pauses during compound complex sentences.",
    recommendedModule: "Module 06: Reading Comprehension & Fluency",
    recommendedStageId: 6
  },
  {
    id: "profile_noah_chen",
    studentName: "Noah Chen",
    studentAge: "7",
    studentClass: "2",
    schoolName: "Horizon Primary",
    parentName: "Michael Chen",
    parentPhone: "9845612378",
    parentEmail: "m.chen@example.com",
    studentPhoto: "",
    audioData: "",
    createdAt: "2026-08-25T09:15:00.000Z",
    riskLevel: "High (Phonemic Awareness)",
    riskColor: "#f43f5e",
    speed: "+14%",
    spelling: "+9%",
    recognition: "+18%",
    phonological: "+11%",
    streak: "3 Days",
    sessions: "98 Questions Completed",
    hours: "3.1 hrs",
    difficulty: "Auditory phoneme segmentation and voice pronunciation matching.",
    recommendedModule: "Module 02: Auditory Processing & Speech",
    recommendedStageId: 2
  },
  {
    id: "profile_sophia_davis",
    studentName: "Sophia Davis",
    studentAge: "10",
    studentClass: "5",
    schoolName: "Oakridge International",
    parentName: "Elena Davis",
    parentPhone: "9832145678",
    parentEmail: "elena.davis@example.com",
    studentPhoto: "",
    audioData: "",
    createdAt: "2026-09-01T14:20:00.000Z",
    riskLevel: "Moderate (Dyscalculia Pattern)",
    riskColor: "#e2b170",
    speed: "+16%",
    spelling: "+14%",
    recognition: "+22%",
    phonological: "+19%",
    streak: "4 Days",
    sessions: "142 Questions Completed",
    hours: "4.0 hrs",
    difficulty: "Symbolic arithmetic operator confusion (+ vs ×) and spatial number alignment.",
    recommendedModule: "Module 04: Mathematical Logic & Dyscalculia",
    recommendedStageId: 4
  }
];

/**
 * Retrieve all profiles saved in localStorage.
 * Automatically seeds defaults and incorporates any legacy single profile.
 */
export function getAllProfiles() {
  try {
    const rawList = localStorage.getItem(PROFILES_STORAGE_KEY);
    let profiles = rawList ? JSON.parse(rawList) : null;

    if (!Array.isArray(profiles) || profiles.length === 0) {
      profiles = [...DEFAULT_PROFILES];

      // Check if user had a single profile stored previously
      const legacyRaw = localStorage.getItem(ACTIVE_PROFILE_KEY);
      if (legacyRaw) {
        try {
          const legacy = JSON.parse(legacyRaw);
          if (legacy && legacy.studentName) {
            const exists = profiles.some(
              (p) => p.studentName.toLowerCase() === legacy.studentName.toLowerCase()
            );
            if (!exists) {
              profiles.unshift({
                id: legacy.id || `profile_${Date.now()}`,
                ...legacy,
                createdAt: legacy.savedAt || new Date().toISOString()
              });
            }
          }
        } catch (e) {
          console.warn("Could not parse legacy single profile:", e);
        }
      }

      localStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(profiles));
    }

    return profiles;
  } catch (err) {
    console.error("Error loading profiles from localStorage:", err);
    return [...DEFAULT_PROFILES];
  }
}

/**
 * Get the currently active profile.
 */
export function getActiveProfile() {
  try {
    const rawActive = localStorage.getItem(ACTIVE_PROFILE_KEY);
    if (rawActive) {
      const parsed = JSON.parse(rawActive);
      if (parsed && parsed.studentName) return parsed;
    }
  } catch (err) {
    console.warn("Could not read active profile:", err);
  }

  const all = getAllProfiles();
  if (all.length > 0) {
    setActiveProfile(all[0].id);
    return all[0];
  }
  return null;
}

/**
 * Save or update a student profile in the persistent multi-profile list.
 * Also sets it as the active profile.
 */
export function saveProfile(profileData) {
  try {
    const profiles = getAllProfiles();
    const id = profileData.id || `profile_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    const now = new Date().toISOString();

    const fullProfile = {
      ...profileData,
      id,
      updatedAt: now,
      createdAt: profileData.createdAt || now,
      // Default telemetry benchmarks if new profile
      speed: profileData.speed || "+12%",
      spelling: profileData.spelling || "+10%",
      recognition: profileData.recognition || "+15%",
      phonological: profileData.phonological || "+8%",
      streak: profileData.streak || "1 Day",
      sessions: profileData.sessions || "Session Initiated",
      hours: profileData.hours || "0.5 hrs",
      riskLevel: profileData.riskLevel || "Assessment in Progress",
      riskColor: profileData.riskColor || "#2dd4bf"
    };

    const existingIndex = profiles.findIndex((p) => p.id === id);
    if (existingIndex >= 0) {
      profiles[existingIndex] = fullProfile;
    } else {
      profiles.unshift(fullProfile);
    }

    localStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(profiles));
    localStorage.setItem(ACTIVE_PROFILE_KEY, JSON.stringify(fullProfile));

    return { active: fullProfile, all: profiles };
  } catch (err) {
    console.error("Error saving profile to persistent store:", err);
    return { active: profileData, all: getAllProfiles() };
  }
}

/**
 * Switch active profile by ID.
 */
export function setActiveProfile(profileId) {
  try {
    const profiles = getAllProfiles();
    const target = profiles.find((p) => p.id === profileId);
    if (target) {
      localStorage.setItem(ACTIVE_PROFILE_KEY, JSON.stringify(target));
      return target;
    }
  } catch (err) {
    console.error("Error setting active profile:", err);
  }
  return null;
}

/**
 * Delete a profile by ID.
 */
export function deleteProfile(profileId) {
  try {
    let profiles = getAllProfiles();
    profiles = profiles.filter((p) => p.id !== profileId);
    if (profiles.length === 0) {
      profiles = [...DEFAULT_PROFILES];
    }
    localStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(profiles));

    const active = getActiveProfile();
    if (active && active.id === profileId) {
      setActiveProfile(profiles[0].id);
    }

    return profiles;
  } catch (err) {
    console.error("Error deleting profile:", err);
    return getAllProfiles();
  }
}
