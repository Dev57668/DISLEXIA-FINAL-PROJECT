import React, { useState } from "react";
import UniversalAppHeader from "./UniversalAppHeader";
import JungleEnvironment from "./jungle/JungleEnvironment";
import JungleMascot from "./jungle/JungleMascot";
import QuestTrailMap from "./jungle/QuestTrailMap";
import {
  IconBrain,
  IconEye,
  IconMic,
  IconEdit,
  IconCalculator,
  IconShapes,
  IconBookOpen,
  IconTarget,
  IconShieldCheck,
  IconStar,
  IconAward
} from "./Icons";
import { playHoverTick, playSynapsePulse } from "../utils/soundEffects";
import { useLanguage } from "../i18n/LanguageContext";

/**
 * HomeScreen - The Lost Canopy of Lexis Flagship Experience
 * An immersive, sunny hand-drawn 2.5D children's adventure game connecting all 6 assessment modules.
 */
export default function HomeScreen({
  onStartProfile,
  onEnterStages,
  onLaunchStage1,
  onLaunchStage2,
  onLaunchStage3,
  onLaunchStage4,
  onLaunchStage5,
  onLaunchStage6,
  onNavigate,
  studentName = "",
  selectedClass = 1,
  savedProgress = {}
}) {
  const { t } = useLanguage();
  const [mascotMood, setMascotMood] = useState("idle");

  const modules = [
    {
      id: "mod-1",
      number: "01",
      name: t("mod1Name", "Eagle Eye Island"),
      title: t("mod1Title", "Visual Perception & Direction"),
      subtitle: t("mod1Subtitle", "Letter Reversals (b vs d) & Symmetry"),
      icon: "🪞",
      color: "#16a34a",
      bgTint: "#dcfce7",
      launch: onLaunchStage1,
      badge: t("mod1Badge", "27 Items • 3 Levels"),
      description: t("mod1Desc", "Spot mirror reversals and find the hidden directional glyphs in the sacred canopy grove."),
      actionLabel: "Explore Island →"
    },
    {
      id: "mod-2",
      number: "02",
      name: t("mod2Name", "Echo Sanctuary"),
      title: t("mod2Title", "Auditory Processing & Speech"),
      subtitle: t("mod2Subtitle", "Phonemic Awareness & Oral Voice Fluency"),
      icon: "🦜",
      color: "#ea580c",
      bgTint: "#ffedd5",
      launch: onLaunchStage2,
      badge: t("mod2Badge", "Microphone Active"),
      description: t("mod2Desc", "Speak the secret jungle words aloud into the parrot's crystal to evaluate oral phoneme timing."),
      actionLabel: "Enter Sanctuary →"
    },
    {
      id: "mod-3",
      number: "03",
      name: t("mod3Name", "Vine Weaver's Treehouse"),
      title: t("mod3Title", "Written Expression & Memory"),
      subtitle: t("mod3Subtitle", "Orthographic Anagram Reconstruction"),
      icon: "🐒",
      color: "#9333ea",
      bgTint: "#f3e8ff",
      launch: onLaunchStage3,
      badge: t("mod3Badge", "Tactile Anagrams"),
      description: t("mod3Desc", "Untangle scrambled letter vines to form magical words and exercise visual working memory."),
      actionLabel: "Enter Treehouse →"
    },
    {
      id: "mod-4",
      number: "04",
      name: t("mod4Name", "Maths Jutsu Temple"),
      title: t("mod4Title", "Mathematical Logic & Reasoning"),
      subtitle: t("mod4Subtitle", "Dyscalculia Screening & Arithmetic"),
      icon: "🥋",
      color: "#d97706",
      bgTint: "#fef3c7",
      launch: onLaunchStage4,
      badge: t("mod4Badge", "Quantitative Logic"),
      description: t("mod4Desc", "Master bamboo counting rods, number sense, and multi-tier mental arithmetic challenges."),
      actionLabel: "Enter Temple →"
    },
    {
      id: "mod-5",
      number: "05",
      name: t("mod5Name", "Sunstone Altar"),
      title: t("mod5Title", "Spatial Geometry & 3D Solids"),
      subtitle: t("mod5Subtitle", "3D Form Rotation & Structural Reasoning"),
      icon: "🏛️",
      color: "#0284c7",
      bgTint: "#e0f2fe",
      launch: onLaunchStage5,
      badge: t("mod5Badge", "Tactile 3D Altar"),
      description: t("mod5Desc", "Spin ancient sunlit solid crystals (cubes, prisms, pyramids) to decode geometric alignments."),
      actionLabel: "Enter Altar →"
    },
    {
      id: "mod-6",
      number: "06",
      name: t("mod6Name", "Storyteller's Lagoon"),
      title: t("mod6Title", "Reading Comprehension"),
      subtitle: t("mod6Subtitle", "Passage Fluency & Semantic Recall"),
      icon: "🌺",
      color: "#e11d48",
      bgTint: "#ffe4e6",
      launch: onLaunchStage6,
      badge: `${t("classLabel", "Class")} ${selectedClass || 1} ${t("calibratedFor", "Calibrated")}`,
      description: t("mod6Desc", "Dive into enchanted jungle stories, pace your oral reading speed, and answer comprehension quests."),
      actionLabel: "Enter Lagoon →"
    }
  ];

  return (
    <div className="jungle-app-wrapper">
      {/* Hand-Drawn Layered Daytime Jungle Scenery: Sky, Clouds, Birds, Ridges, Butterflies & Palms */}
      <JungleEnvironment />

      {/* Canopy Navigation Header with Compass, Font Switcher & Student Passport */}
      <UniversalAppHeader
        currentScreen="home"
        onNavigate={onNavigate}
        studentName={studentName}
        selectedClass={selectedClass}
      />

      <main className="quest-trail-container">
        {/* ========================================================
            HERO EXPEDITION CANOPY BOARD
           ======================================================== */}
        <section className="jungle-hero-board">
          <div className="hero-board-left">
            <div className="hero-pill-tag">
              <span className="pill-leaf">🍃</span>
              <span>{t("heroTag", "THE LOST CANOPY OF LEXIS • COGNITIVE ADVENTURE")}</span>
            </div>

            <h1 className="hero-title">
              {t("heroTitlePrefix", "Ready for the")}{" "}
              <span className="highlight-text">{t("heroTitleHighlight", "Jungle Quest?")}</span>
            </h1>

            <p className="hero-lead">
              {t("heroLead", "Step into a magical hand-drawn storybook canopy where fun adventure games evaluate and strengthen reading fluency, letter orientation (b vs d), phonological speech, and 3D spatial reasoning!")}
            </p>

            {/* Chunky Action Buttons */}
            <div className="hero-btn-row">
              <button
                className="btn-jungle-cta"
                onClick={() => {
                  playSynapsePulse();
                  setMascotMood("celebrate");
                  if (onLaunchStage1) onLaunchStage1();
                }}
              >
                <span>🗺️</span>
                <span>{t("btnStartExpedition", "Begin Module 01 Expedition")}</span>
              </button>

              <button
                className="btn-jungle-secondary"
                onClick={() => {
                  playHoverTick();
                  setMascotMood("happy");
                  if (onEnterStages) onEnterStages();
                }}
              >
                <span>🎮</span>
                <span>{t("btnExploreGlades", "Explore All 6 Glades")}</span>
              </button>
            </div>

            {/* Explorer Passport Chest */}
            <div className="explorer-chest-bar">
              <div className="chest-icon">🎒</div>
              <div className="chest-details">
                <span className="chest-label">{t("currentExplorerLabel", "CURRENT EXPLORER:")}</span>
                <strong className="chest-student-name">
                  {studentName || t("guestExplorer", "Junior Explorer (Guest)")}
                </strong>
                <span className="chest-grade-tag">
                  {t("calibratedFor", "Calibrated for")} <strong>{t("classLabel", "Class")} {selectedClass || 1}</strong>
                </span>
              </div>
              <button
                className="btn-jungle-wood"
                onClick={() => {
                  playHoverTick();
                  onNavigate("profile");
                }}
              >
                <span>{t("btnEditPassport", "Edit Passport ✎")}</span>
              </button>
            </div>
          </div>

          {/* Hero Board Right: Interactive Ollie Mascot Rig */}
          <div className="hero-board-right">
            <div className="companion-nest-card">
              <div className="nest-header">
                <span className="nest-status-dot" />
                <span className="nest-title">{t("mascotTitle", "OLLIE THE EXPEDITION GUIDE")}</span>
              </div>

              <div className="nest-mascot-stage">
                <JungleMascot
                  mood={mascotMood}
                  speechText={
                    mascotMood === "celebrate"
                      ? t("mascotCelebrate", "Hooray! Adventure awaits!")
                      : mascotMood === "happy"
                      ? t("mascotHappy", "You've got this, Explorer!")
                      : t("mascotIdle", "I follow your cursor! Click me!")
                  }
                  onMascotClick={() => {
                    playHoverTick();
                    setMascotMood((prev) => (prev === "idle" ? "happy" : prev === "happy" ? "celebrate" : "idle"));
                  }}
                  size="large"
                />
              </div>

              <div className="nest-footer">
                <p>
                  🦉 <strong>{t("mascotTitle", "OLLIE THE EXPEDITION GUIDE")}:</strong> {t("mascotNote", "Move your mouse around! My eyes follow your cursor. Click me anytime for cheerful encouragement!")}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ========================================================
            THE WINDING CANOPY QUEST TRAIL MAP
           ======================================================== */}
        <QuestTrailMap
          modules={modules}
          onLaunchModule={(mod) => {
            if (mod.launch) mod.launch();
          }}
          savedProgress={savedProgress}
        />

        {/* ========================================================
            CLINICAL DIAGNOSTIC METHODOLOGY TABLET
           ======================================================== */}
        <section className="jungle-methodology-tablet">
          <div className="tablet-left">
            <div className="tablet-badge">
              <IconShieldCheck size={20} />
              <span>{t("clinicalEngine", "CLINICAL DIAGNOSTIC ENGINE")}</span>
            </div>
            <h2>{t("evidenceBasedTitle", "Evidence-Based Cognitive Assessment")}</h2>
            <p>
              {t("evidenceBasedDesc", "As your child explores the jungle glades, DyslexiaQuest captures multi-factor clinical telemetry: orthographic mirror confusion rates (b vs d), speech recognition confidence, 3D rotational spatial accuracy, and arithmetic timing.")}
            </p>
            <div className="tablet-features-list">
              <div className="tablet-feature-item">
                <span className="feature-check">✓</span>
                <span>{t("feat1", "Standardized mirror letter reversal error index (b/d/p/q)")}</span>
              </div>
              <div className="tablet-feature-item">
                <span className="feature-check">✓</span>
                <span>{t("feat2", "Real-time voice phoneme analysis via Web Speech API")}</span>
              </div>
              <div className="tablet-feature-item">
                <span className="feature-check">✓</span>
                <span>{t("feat3", "Printable diagnostic summaries calibrated for schools & clinicians")}</span>
              </div>
            </div>
            <button
              className="btn-jungle-wood"
              onClick={() => {
                playHoverTick();
                onNavigate("analysis");
              }}
              style={{ marginTop: "20px" }}
            >
              <IconTarget size={18} />
              <span>{t("btnOpenDiagnostic", "Open Student Diagnostic Dashboard →")}</span>
            </button>
          </div>

          <div className="tablet-right">
            <div className="wood-report-card">
              <div className="wood-report-header">
                <IconAward size={22} />
                <span>{t("metricsPreview", "EXPEDITION METRICS PREVIEW")}</span>
              </div>
              <div className="wood-report-row">
                <span>{t("visualOrthography", "Visual Orthography:")}</span>
                <strong style={{ color: "#16a34a" }}>94% Accuracy</strong>
              </div>
              <div className="wood-report-row">
                <span>{t("phoneticSpeech", "Phonetic Speech:")}</span>
                <strong style={{ color: "#ea580c" }}>{t("gradeAligned", "Grade Aligned")}</strong>
              </div>
              <div className="wood-report-row">
                <span>{t("spatialSolids", "Spatial 3D Solids:")}</span>
                <strong style={{ color: "#0284c7" }}>{t("advanced", "Advanced")}</strong>
              </div>
              <div className="wood-report-row">
                <span>{t("dyscalculiaRisk", "Dyscalculia Risk:")}</span>
                <strong style={{ color: "#d97706" }}>{t("lowNormal", "Low / Normal")}</strong>
              </div>
              <div className="wood-report-status">
                {t("allReady", "🌿 ALL 6 EXPEDITIONS READY")}
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Storybook Jungle Footer */}
      <footer className="jungle-site-footer">
        <div className="footer-content">
          <div className="footer-brand-lockup">
            <span className="footer-emoji">🧭</span>
            <span>{t("footerTitle", "DyslexiaQuest • The Lost Canopy of Lexis")}</span>
          </div>
          <p className="footer-tagline">
            {t("footerTagline", "Engineered with love for dyslexic minds, visual-orthographic reinforcement, and inclusive learning.")}
          </p>
        </div>
      </footer>

      <style>{`
        .jungle-hero-board {
          display: grid;
          grid-template-columns: 1.2fr 0.9fr;
          gap: 32px;
          align-items: center;
          background: #fffdf2;
          border: 3.5px solid #78350f;
          border-radius: var(--radius-hand-card);
          box-shadow: var(--shadow-jungle-card);
          padding: 40px;
          margin-bottom: 48px;
          position: relative;
        }

        .hero-pill-tag {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 5px 14px;
          background: #ecfccb;
          border: 2px solid #65a30d;
          border-radius: 999px;
          font-family: var(--font-display);
          font-size: 0.86rem;
          font-weight: 700;
          color: #365314;
          margin-bottom: 16px;
        }

        .hero-title {
          font-family: var(--font-display);
          font-size: var(--text-hero);
          color: #451a03;
          margin-bottom: 16px;
          line-height: 1.15;
        }

        .highlight-text {
          color: #ea580c;
          text-decoration: underline wavy #facc15 3px;
        }

        .hero-lead {
          font-size: var(--text-body-large);
          color: #78350f;
          margin-bottom: 24px;
          max-width: 58ch;
        }

        .hero-btn-row {
          display: flex;
          flex-wrap: wrap;
          gap: 16px;
          margin-bottom: 28px;
        }

        .explorer-chest-bar {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 14px 20px;
          background: #fefae0;
          border: 2.5px dashed #b45309;
          border-radius: 20px;
        }

        .chest-icon {
          font-size: 32px;
        }

        .chest-details {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        .chest-label {
          font-size: 0.72rem;
          font-weight: 800;
          color: #b45309;
          letter-spacing: 0.05em;
        }

        .chest-student-name {
          font-family: var(--font-display);
          font-size: 1.15rem;
          color: #451a03;
        }

        .chest-grade-tag {
          font-size: 0.82rem;
          color: #78350f;
        }

        .companion-nest-card {
          background: #fefae0;
          border: 3px solid #78350f;
          border-radius: 24px;
          padding: 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
          box-shadow: 0 6px 0 #78350f;
        }

        .nest-header {
          display: flex;
          align-items: center;
          gap: 8px;
          font-family: var(--font-display);
          font-size: 0.84rem;
          font-weight: 700;
          color: #78350f;
          margin-bottom: 12px;
        }

        .nest-status-dot {
          width: 8px;
          height: 8px;
          background: #22c55e;
          border-radius: 50%;
          box-shadow: 0 0 8px #22c55e;
        }

        .nest-mascot-stage {
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 10px 0;
        }

        .nest-footer p {
          font-size: 0.85rem;
          color: #78350f;
          text-align: center;
          line-height: 1.4;
          margin-top: 8px;
        }

        .jungle-methodology-tablet {
          display: grid;
          grid-template-columns: 1.3fr 0.9fr;
          gap: 32px;
          background: #fffdf2;
          border: 3.5px solid #78350f;
          border-radius: var(--radius-hand-card);
          box-shadow: var(--shadow-jungle-card);
          padding: 36px;
          margin-bottom: 56px;
        }

        .tablet-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-family: var(--font-display);
          font-size: 0.82rem;
          font-weight: 800;
          color: #15803d;
          background: #dcfce7;
          padding: 4px 12px;
          border-radius: 999px;
          border: 2px solid #16a34a;
          margin-bottom: 12px;
        }

        .tablet-left h2 {
          font-size: var(--text-h2);
          color: #451a03;
          margin-bottom: 12px;
        }

        .tablet-left p {
          color: #78350f;
          font-size: 1.02rem;
          margin-bottom: 16px;
        }

        .tablet-features-list {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .tablet-feature-item {
          display: flex;
          align-items: center;
          gap: 10px;
          font-weight: 600;
          color: #451a03;
        }

        .feature-check {
          color: #16a34a;
          font-weight: 900;
        }

        .wood-report-card {
          background: #fefae0;
          border: 3px solid #78350f;
          border-radius: 20px;
          padding: 24px;
          display: flex;
          flex-direction: column;
          gap: 12px;
          box-shadow: 0 4px 0 #78350f;
        }

        .wood-report-header {
          display: flex;
          align-items: center;
          gap: 8px;
          font-family: var(--font-display);
          font-size: 0.95rem;
          font-weight: 800;
          color: #78350f;
          border-bottom: 1.5px dashed #d97706;
          padding-bottom: 8px;
        }

        .wood-report-row {
          display: flex;
          justify-content: space-between;
          font-size: 0.92rem;
          color: #451a03;
        }

        .wood-report-status {
          margin-top: 8px;
          padding: 8px;
          text-align: center;
          background: #dcfce7;
          border: 2px solid #16a34a;
          border-radius: 10px;
          font-family: var(--font-display);
          font-size: 0.85rem;
          font-weight: 800;
          color: #15803d;
        }

        .jungle-site-footer {
          padding: 30px 20px;
          text-align: center;
          border-top: 3px dashed #78350f;
          background: #fefae0;
          margin-top: auto;
        }

        .footer-brand-lockup {
          font-family: var(--font-display);
          font-size: 1.15rem;
          font-weight: 800;
          color: #451a03;
          margin-bottom: 6px;
        }

        .footer-tagline {
          font-size: 0.88rem;
          color: #78350f;
        }

        @media (max-width: 960px) {
          .jungle-hero-board {
            grid-template-columns: 1fr;
          }
          .jungle-methodology-tablet {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
}
