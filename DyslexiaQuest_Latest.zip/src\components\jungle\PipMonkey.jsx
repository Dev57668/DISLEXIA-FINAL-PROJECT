import React, { useState } from "react";
import { playHoverTick, playSynapsePulse } from "../../utils/soundEffects";

/**
 * PipMonkey - Secondary Companion Mascot
 * "Pip the Vine Monkey" - Hand-drawn storybook character with a big head, small body,
 * holding a golden tropical fruit, hanging from a vine.
 */
export default function PipMonkey({ size = "small", onPipClick = null }) {
  const [isWaving, setIsWaving] = useState(false);

  const handleClick = () => {
    playSynapsePulse();
    setIsWaving(true);
    setTimeout(() => setIsWaving(false), 900);
    if (onPipClick) onPipClick();
  };

  const scale = size === "large" ? "160px" : size === "medium" ? "120px" : "90px";

  return (
    <div
      className={`pip-monkey-rig ${isWaving ? "waving" : ""}`}
      style={{
        position: "relative",
        width: scale,
        height: `calc(${scale} * 1.35)`,
        cursor: "pointer",
        userSelect: "none"
      }}
      onClick={handleClick}
      title="Pip the Vine Monkey (Click to Wave!)"
    >
      <svg
        viewBox="0 0 140 190"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        style={{ width: "100%", height: "100%", overflow: "visible" }}
      >
        {/* Hanging Jungle Vine */}
        <path d="M70 0 Q 75 40 70 80 Q 65 120 70 160" stroke="#15803d" strokeWidth="5" strokeLinecap="round" />
        <ellipse cx="66" cy="35" rx="10" ry="5" fill="#22c55e" stroke="#14532d" strokeWidth="1.5" transform="rotate(-30 66 35)" />
        <ellipse cx="74" cy="70" rx="9" ry="4" fill="#22c55e" stroke="#14532d" strokeWidth="1.5" transform="rotate(30 74 70)" />

        {/* Curly Tail Wrapping the Vine */}
        <path
          d="M70 140 C 95 145, 105 120, 85 105 C 65 90, 68 60, 72 40"
          stroke="#78350f"
          strokeWidth="6"
          strokeLinecap="round"
          fill="none"
        />

        {/* Small Teardrop Monkey Body */}
        <ellipse cx="70" cy="142" rx="20" ry="24" fill="#92400e" stroke="#451a03" strokeWidth="3" />
        <ellipse cx="70" cy="144" rx="13" ry="17" fill="#fefae0" />

        {/* Small Arms holding Banana */}
        <g id="arms">
          <path d="M55 136 C 50 145, 60 155, 65 150" stroke="#78350f" strokeWidth="4" strokeLinecap="round" />
          <path d="M85 136 C 90 145, 80 155, 75 150" stroke="#78350f" strokeWidth="4" strokeLinecap="round" />
          {/* Golden Banana */}
          <path d="M60 152 Q 70 160 80 152 Q 70 156 60 152" fill="#facc15" stroke="#a16207" strokeWidth="2.5" />
        </g>

        {/* NOTICEABLY BIG MONKEY HEAD */}
        <g id="pip-head" className="pip-head-group">
          {/* Big Round Ears */}
          <circle cx="28" cy="85" r="16" fill="#92400e" stroke="#451a03" strokeWidth="3" />
          <circle cx="28" cy="85" r="10" fill="#fefae0" />
          <circle cx="112" cy="85" r="16" fill="#92400e" stroke="#451a03" strokeWidth="3" />
          <circle cx="112" cy="85" r="10" fill="#fefae0" />

          {/* Head Base */}
          <ellipse cx="70" cy="85" rx="38" ry="34" fill="#92400e" stroke="#451a03" strokeWidth="3.5" />

          {/* Heart-Shaped Light Face */}
          <path
            d="M52 68 C 40 68, 42 88, 70 106 C 98 88, 100 68, 88 68 C 78 68, 72 75, 70 78 C 68 75, 62 68, 52 68 Z"
            fill="#fefae0"
            stroke="#451a03"
            strokeWidth="2.5"
          />

          {/* Big Cartoon Eyes */}
          <ellipse cx="56" cy="80" rx="8" ry="11" fill="#451a03" />
          <circle cx="54" cy="77" r="3.5" fill="#ffffff" />
          <ellipse cx="84" cy="80" rx="8" ry="11" fill="#451a03" />
          <circle cx="82" cy="77" r="3.5" fill="#ffffff" />

          {/* Rosy Cheeks */}
          <circle cx="48" cy="92" r="4.5" fill="#fb7185" opacity="0.6" />
          <circle cx="92" cy="92" r="4.5" fill="#fb7185" opacity="0.6" />

          {/* Cute Nostrils & Smile */}
          <ellipse cx="67" cy="92" rx="1.5" ry="1" fill="#451a03" />
          <ellipse cx="73" cy="92" rx="1.5" ry="1" fill="#451a03" />
          <path d="M62 98 Q 70 105 78 98" stroke="#451a03" strokeWidth="2.5" strokeLinecap="round" fill="none" />

          {/* Jungle Explorer Leaf Hat */}
          <path d="M52 56 Q 70 42 88 56 Q 70 52 52 56" fill="#16a34a" stroke="#0f3822" strokeWidth="2.5" />
          <circle cx="70" cy="48" r="3" fill="#f43f5e" />
        </g>
      </svg>

      <style>{`
        .pip-monkey-rig {
          transform-origin: top center;
          animation: vineSway 5s ease-in-out infinite alternate;
        }

        .pip-head-group {
          transform-origin: 70px 110px;
          animation: pipBlinkAndBob 3.5s ease-in-out infinite;
        }

        .pip-monkey-rig.waving {
          animation: pipJoy 0.8s ease-in-out;
        }

        @keyframes vineSway {
          0% { transform: rotate(-3deg); }
          100% { transform: rotate(3deg); }
        }

        @keyframes pipBlinkAndBob {
          0%, 100% { transform: translateY(0) rotate(0deg); }
          50% { transform: translateY(-2px) rotate(2deg); }
        }

        @keyframes pipJoy {
          0%, 100% { transform: scale(1); }
          30% { transform: translateY(-12px) rotate(8deg) scale(1.1); }
          60% { transform: translateY(-4px) rotate(-6deg) scale(1.05); }
        }
      `}</style>
    </div>
  );
}
