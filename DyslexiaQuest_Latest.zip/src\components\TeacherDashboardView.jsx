import React, { useState } from "react";
import {
  IconBrain,
  IconEye,
  IconMic,
  IconEdit,
  IconCalculator,
  IconShapes,
  IconBookOpen,
  IconTarget,
  IconUser,
  IconCheck,
  IconPrinter,
  IconShieldCheck,
  IconAward,
  IconLayers
} from "./Icons";
import { playHoverTick, playSynapsePulse } from "../utils/soundEffects";

/**
 * TeacherDashboardView - The Naturalist's Study
 * Clinical & Educator Assessment Terminal styled as a warm, organized explorer study.
 * Preserves 100% of student diagnostic tracking, cognitive telemetry, and print capabilities.
 */
export default function TeacherDashboardView({
  onLaunchStage = () => {},
  onReturnHome = () => {},
  profiles = [],
  onSelectProfile = () => {}
}) {
  const defaultStudents = [
    {
      id: "std-1",
      name: "Liam Parker",
      grade: "Class 3",
      age: 8,
      riskLevel: "Moderate (Visual Orthography)",
      riskColor: "#d97706",
      speed: "+18%",
      spelling: "+12%",
      recognition: "+24%",
      phonological: "+15%",
      streak: "5 Days",
      sessions: "164 Questions Completed",
      hours: "4.8 hrs",
      difficulty: "Mirror letter reversals on b/d and p/q under speed pressure; letter transposition in multisyllabic words.",
      recommendedModule: "Module 01: Visual Perception & Orthography",
      recommendedStageId: 1
    },
    {
      id: "std-2",
      name: "Emma Watson",
      grade: "Class 4",
      age: 9,
      riskLevel: "Low Risk (Grade Aligned)",
      riskColor: "#16a34a",
      speed: "+22%",
      spelling: "+19%",
      recognition: "+31%",
      phonological: "+26%",
      streak: "7 Days",
      sessions: "210 Questions Completed",
      hours: "6.2 hrs",
      difficulty: "Rapid oral reading fluency pauses during compound complex sentences.",
      recommendedModule: "Module 06: Reading Comprehension & Fluency",
      recommendedStageId: 6
    },
    {
      id: "std-3",
      name: "Noah Chen",
      grade: "Class 2",
      age: 7,
      riskLevel: "High (Phonemic Awareness)",
      riskColor: "#dc2626",
      speed: "+14%",
      spelling: "+9%",
      recognition: "+18%",
      phonological: "+11%",
      streak: "3 Days",
      sessions: "98 Questions Completed",
      hours: "3.1 hrs",
      difficulty: "Auditory phoneme segmentation and voice pronunciation matching.",
      recommendedModule: "Module 02: Auditory Processing & Speech",
      recommendedStageId: 2
    },
    {
      id: "std-4",
      name: "Sophia Davis",
      grade: "Class 5",
      age: 10,
      riskLevel: "Moderate (Dyscalculia Pattern)",
      riskColor: "#d97706",
      speed: "+16%",
      spelling: "+14%",
      recognition: "+22%",
      phonological: "+19%",
      streak: "4 Days",
      sessions: "142 Questions Completed",
      hours: "4.0 hrs",
      difficulty: "Symbolic arithmetic operator confusion (+ vs ×) and spatial number alignment.",
      recommendedModule: "Module 04: Mathematical Logic & Dyscalculia",
      recommendedStageId: 4
    }
  ];

  const students = (profiles && profiles.length > 0)
    ? profiles.map((p, idx) => ({
        id: p.id || `std-${idx + 1}`,
        name: p.studentName,
        grade: `Class ${p.studentClass || 1}`,
        age: Number(p.studentAge) || 8,
        riskLevel: p.riskLevel || "Moderate (Visual Orthography)",
        riskColor: p.riskColor || (idx % 3 === 0 ? "#d97706" : idx % 2 === 0 ? "#16a34a" : "#0284c7"),
        speed: p.speed || "+18%",
        spelling: p.spelling || "+12%",
        recognition: p.recognition || "+24%",
        phonological: p.phonological || "+15%",
        streak: p.streak || "5 Days",
        sessions: p.sessions || "164 Questions Completed",
        hours: p.hours || "4.8 hrs",
        difficulty: p.difficulty || "Mirror letter reversals on b/d and p/q under speed pressure; letter transposition in multisyllabic words.",
        recommendedModule: p.recommendedModule || "Module 01: Visual Perception & Orthography",
        recommendedStageId: p.recommendedStageId || 1
      }))
    : defaultStudents;

  const [selectedStudentId, setSelectedStudentId] = useState(students[0]?.id || "std-1");
  const student = students.find((s) => s.id === selectedStudentId) || students[0];

  return (
    <div className="naturalist-study-container">
      {/* Top Console Bar */}
      <header className="study-header-bar">
        <div className="study-header-left">
          <div className="study-badge">
            <IconShieldCheck size={18} />
            <span>THE NATURALIST'S STUDY • EDUCATOR TERMINAL</span>
          </div>
          <h1 className="study-main-title">Diagnostic Journal & Cognitive Progress</h1>
          <p className="study-sub-desc">
            Evidence-based student telemetry, phonemic error distributions, and adaptive module recommendations.
          </p>
        </div>

        <div className="study-header-actions">
          <button
            className="btn-study-print"
            onClick={() => {
              playHoverTick();
              window.print();
            }}
            title="Print or Export Clinical PDF Summary"
          >
            <IconPrinter size={18} />
            <span>Print Report (PDF)</span>
          </button>
          <button
            className="btn-study-return"
            onClick={() => {
              playHoverTick();
              onReturnHome();
            }}
          >
            <span>← Return to Canopy Map</span>
          </button>
        </div>
      </header>

      {/* Main 2-Column Study Layout */}
      <div className="study-layout-grid">
        {/* Left Column: Explorer Roster */}
        <aside className="study-roster-card">
          <div className="roster-top-bar">
            <h3>Explorer Cohort ({students.length})</h3>
            <span className="roster-pill">Active Group</span>
          </div>

          <div className="roster-students-list">
            {students.map((s) => {
              const isSelected = s.id === selectedStudentId;
              return (
                <div
                  key={s.id}
                  className={`roster-student-item ${isSelected ? "selected" : ""}`}
                  onClick={() => {
                    playSynapsePulse();
                    setSelectedStudentId(s.id);
                    const matched = profiles.find((p) => p.id === s.id);
                    if (matched && onSelectProfile) onSelectProfile(matched);
                  }}
                  role="button"
                  tabIndex={0}
                >
                  <div className="student-badge-avatar">
                    <IconUser size={18} />
                  </div>
                  <div className="student-roster-info">
                    <strong className="roster-name">{s.name}</strong>
                    <span className="roster-meta">{s.grade} • Age {s.age}</span>
                  </div>
                  <span
                    className="roster-risk-dot"
                    style={{ backgroundColor: s.riskColor }}
                    title={s.riskLevel}
                  />
                </div>
              );
            })}
          </div>

          <div className="roster-cohort-summary">
            <div className="cohort-stat-row">
              <span>Cohort Average Gains:</span>
              <strong style={{ color: "#15803d" }}>↑ 18.2%</strong>
            </div>
            <div className="cohort-stat-row">
              <span>Grade Curriculum:</span>
              <span>Classes 1–5 Aligned</span>
            </div>
          </div>
        </aside>

        {/* Right Column: Detailed Clinical Telemetry for Selected Student */}
        <main className="study-analytics-main">
          {/* Active Student Card */}
          <div className="student-profile-banner">
            <div className="profile-banner-left">
              <div className="banner-avatar-orb">
                <IconUser size={34} />
              </div>
              <div>
                <h2 className="banner-student-name">{student.name}</h2>
                <p className="banner-student-sub">
                  {student.grade} • Age {student.age} • Standardized Assessment Record
                </p>
              </div>
            </div>
            <div className="profile-banner-right">
              <span className="banner-risk-chip" style={{ borderColor: student.riskColor, color: student.riskColor }}>
                {student.riskLevel}
              </span>
            </div>
          </div>

          {/* Core Telemetry Cards */}
          <div className="telemetry-cards-grid">
            {/* 1. Reading Speed */}
            <div className="telemetry-card">
              <div className="telemetry-card-top">
                <span className="telemetry-icon-orb green"><IconBookOpen size={20} /></span>
                <span className="telemetry-tag">READING FLUENCY</span>
              </div>
              <div className="telemetry-val-row">
                <h3>Reading Speed</h3>
                <span className="telemetry-gain green">↑ {student.speed.replace("+", "")}</span>
              </div>
              <div className="telemetry-bar-track">
                <div className="telemetry-bar-fill green" style={{ width: "78%" }} />
              </div>
              <p className="telemetry-note">Grade-calibrated oral WPM tracking and comprehension pacing.</p>
            </div>

            {/* 2. Spelling & Orthography */}
            <div className="telemetry-card">
              <div className="telemetry-card-top">
                <span className="telemetry-icon-orb amber"><IconEdit size={20} /></span>
                <span className="telemetry-tag">ORTHOGRAPHY</span>
              </div>
              <div className="telemetry-val-row">
                <h3>Spelling Accuracy</h3>
                <span className="telemetry-gain amber">↑ {student.spelling.replace("+", "")}</span>
              </div>
              <div className="telemetry-bar-track">
                <div className="telemetry-bar-fill amber" style={{ width: "68%" }} />
              </div>
              <p className="telemetry-note">Sequential letter placement in orthographic anagram exercises.</p>
            </div>

            {/* 3. Letter / Word Recognition */}
            <div className="telemetry-card">
              <div className="telemetry-card-top">
                <span className="telemetry-icon-orb blue"><IconEye size={20} /></span>
                <span className="telemetry-tag">MIRROR DISCRIMINATION</span>
              </div>
              <div className="telemetry-val-row">
                <h3>Mirror Recognition</h3>
                <span className="telemetry-gain blue">↑ {student.recognition.replace("+", "")}</span>
              </div>
              <div className="telemetry-bar-track">
                <div className="telemetry-bar-fill blue" style={{ width: "86%" }} />
              </div>
              <p className="telemetry-note">Standardized discrimination of mirror pairs (b vs d, p vs q).</p>
            </div>

            {/* 4. Phonological Speech */}
            <div className="telemetry-card">
              <div className="telemetry-card-top">
                <span className="telemetry-icon-orb coral"><IconMic size={20} /></span>
                <span className="telemetry-tag">ORAL PHONOLOGY</span>
              </div>
              <div className="telemetry-val-row">
                <h3>Phonemic Awareness</h3>
                <span className="telemetry-gain coral">↑ {student.phonological.replace("+", "")}</span>
              </div>
              <div className="telemetry-bar-track">
                <div className="telemetry-bar-fill coral" style={{ width: "72%" }} />
              </div>
              <p className="telemetry-note">Web Speech API phoneme confidence and oral response matching.</p>
            </div>
          </div>

          {/* Learning Sessions & Habit Summary */}
          <div className="study-sessions-ribbon">
            <div className="session-stat-box">
              <span className="session-label">WEEKLY STREAK</span>
              <strong className="session-val">🔥 {student.streak}</strong>
            </div>
            <div className="session-stat-box">
              <span className="session-label">ITEMS COMPLETED</span>
              <strong className="session-val">📝 {student.sessions}</strong>
            </div>
            <div className="session-stat-box">
              <span className="session-label">ENGAGEMENT TIME</span>
              <strong className="session-val">⏱️ {student.hours}</strong>
            </div>
          </div>

          {/* Specific Diagnostic Difficulty & Intervention Action */}
          <div className="study-intervention-card">
            <div className="intervention-left">
              <span className="intervention-badge">TARGETED INTERVENTION PLAN</span>
              <h3>Primary Cognitive Challenge Area</h3>
              <p className="difficulty-text">{student.difficulty}</p>
              <div className="recommendation-callout">
                <span>Recommended Adaptive Glade:</span>
                <strong>{student.recommendedModule}</strong>
              </div>
            </div>
            <button
              className="btn-jungle-cta"
              onClick={() => {
                playSynapsePulse();
                if (onLaunchStage) onLaunchStage(student.recommendedStageId);
              }}
            >
              <span>🚀</span>
              <span>Launch Assigned Module</span>
            </button>
          </div>
        </main>
      </div>

      <style>{`
        .naturalist-study-container {
          position: relative;
          width: 100%;
          max-width: 1350px;
          margin: 0 auto;
          padding: 24px 20px 80px;
          z-index: var(--z-content);
        }

        .study-header-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: #fffdf2;
          border: 3.5px solid #78350f;
          border-radius: var(--radius-hand-card);
          box-shadow: var(--shadow-jungle-card);
          padding: 28px 36px;
          margin-bottom: 28px;
        }

        .study-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 4px 14px;
          background: #dcfce7;
          border: 2px solid #16a34a;
          border-radius: 999px;
          font-family: var(--font-display);
          font-size: 0.82rem;
          font-weight: 800;
          color: #14532d;
          margin-bottom: 8px;
        }

        .study-main-title {
          font-size: clamp(1.6rem, 2.6vw, 2.2rem);
          color: #451a03;
          margin-bottom: 6px;
        }

        .study-sub-desc {
          font-size: 0.98rem;
          color: #78350f;
          max-width: 65ch;
        }

        .study-header-actions {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .btn-study-print {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 12px 22px;
          background: #fefae0;
          border: 2.5px solid #78350f;
          border-radius: 999px;
          font-family: var(--font-display);
          font-size: 0.98rem;
          font-weight: 700;
          color: #78350f;
          cursor: pointer;
          box-shadow: 0 4px 0 #78350f;
          transition: transform 0.15s ease;
        }

        .btn-study-print:hover {
          transform: translateY(-2px);
          background: #fef08a;
        }

        .btn-study-return {
          padding: 12px 22px;
          background: #1b7340;
          border: 2.5px solid #0f3822;
          border-radius: 999px;
          font-family: var(--font-display);
          font-size: 0.98rem;
          font-weight: 700;
          color: #ffffff;
          cursor: pointer;
          box-shadow: 0 4px 0 #0f3822;
          transition: transform 0.15s ease;
        }

        .btn-study-return:hover {
          transform: translateY(-2px);
        }

        .study-layout-grid {
          display: grid;
          grid-template-columns: 320px 1fr;
          gap: 28px;
        }

        .study-roster-card {
          background: #fffdf2;
          border: 3.5px solid #78350f;
          border-radius: var(--radius-hand-card);
          box-shadow: var(--shadow-jungle-card);
          padding: 24px;
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .roster-top-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          border-bottom: 2px dashed #d97706;
          padding-bottom: 12px;
        }

        .roster-top-bar h3 {
          font-size: 1.15rem;
          color: #451a03;
        }

        .roster-pill {
          font-family: var(--font-display);
          font-size: 0.76rem;
          font-weight: 800;
          background: #ecfccb;
          border: 1.5px solid #65a30d;
          color: #365314;
          padding: 2px 10px;
          border-radius: 999px;
        }

        .roster-students-list {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .roster-student-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 10px 14px;
          background: #fefae0;
          border: 2px solid transparent;
          border-radius: 16px;
          cursor: pointer;
          transition: all 0.15s ease;
        }

        .roster-student-item:hover {
          background: #fef08a;
          border-color: #d97706;
        }

        .roster-student-item.selected {
          background: #fef08a;
          border-color: #78350f;
          box-shadow: 0 3px 0 #78350f;
        }

        .student-badge-avatar {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background: #fffdf2;
          border: 2px solid #78350f;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #78350f;
        }

        .student-roster-info {
          display: flex;
          flex-direction: column;
          flex-grow: 1;
        }

        .roster-name {
          font-size: 0.96rem;
          color: #451a03;
        }

        .roster-meta {
          font-size: 0.8rem;
          color: #78350f;
        }

        .roster-risk-dot {
          width: 12px;
          height: 12px;
          border-radius: 50%;
          border: 1.5px solid #fff;
          box-shadow: 0 0 4px rgba(0, 0, 0, 0.2);
        }

        .roster-cohort-summary {
          margin-top: auto;
          padding-top: 14px;
          border-top: 2px dashed #d97706;
          display: flex;
          flex-direction: column;
          gap: 6px;
          font-size: 0.88rem;
          color: #78350f;
        }

        .cohort-stat-row {
          display: flex;
          justify-content: space-between;
        }

        .study-analytics-main {
          display: flex;
          flex-direction: column;
          gap: 24px;
        }

        .student-profile-banner {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: #fffdf2;
          border: 3.5px solid #78350f;
          border-radius: var(--radius-hand-card);
          box-shadow: var(--shadow-jungle-card);
          padding: 24px 30px;
        }

        .profile-banner-left {
          display: flex;
          align-items: center;
          gap: 16px;
        }

        .banner-avatar-orb {
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: #fefae0;
          border: 3px solid #78350f;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #78350f;
          box-shadow: 0 4px 0 #78350f;
        }

        .banner-student-name {
          font-size: 1.6rem;
          color: #451a03;
        }

        .banner-student-sub {
          font-size: 0.95rem;
          color: #78350f;
        }

        .banner-risk-chip {
          padding: 6px 16px;
          border: 2px solid;
          border-radius: 999px;
          font-family: var(--font-display);
          font-size: 0.88rem;
          font-weight: 800;
          background: #fffdf2;
        }

        .telemetry-cards-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
          gap: 20px;
        }

        .telemetry-card {
          background: #fffdf2;
          border: 3px solid #78350f;
          border-radius: 20px;
          box-shadow: var(--shadow-jungle-card);
          padding: 20px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .telemetry-card-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .telemetry-icon-orb {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 2px solid;
        }

        .telemetry-icon-orb.green { background: #dcfce7; border-color: #16a34a; color: #16a34a; }
        .telemetry-icon-orb.amber { background: #fef3c7; border-color: #d97706; color: #d97706; }
        .telemetry-icon-orb.blue { background: #e0f2fe; border-color: #0284c7; color: #0284c7; }
        .telemetry-icon-orb.coral { background: #ffe4e6; border-color: #e11d48; color: #e11d48; }

        .telemetry-tag {
          font-family: var(--font-display);
          font-size: 0.72rem;
          font-weight: 800;
          color: #78350f;
          letter-spacing: 0.05em;
        }

        .telemetry-val-row {
          display: flex;
          align-items: baseline;
          justify-content: space-between;
        }

        .telemetry-val-row h3 {
          font-size: 1.05rem;
          color: #451a03;
        }

        .telemetry-gain {
          font-family: var(--font-display);
          font-size: 1.15rem;
          font-weight: 800;
        }
        .telemetry-gain.green { color: #15803d; }
        .telemetry-gain.amber { color: #b45309; }
        .telemetry-gain.blue { color: #0369a1; }
        .telemetry-gain.coral { color: #be123c; }

        .telemetry-bar-track {
          width: 100%;
          height: 12px;
          background: #fefae0;
          border: 2px solid #78350f;
          border-radius: 999px;
          overflow: hidden;
        }

        .telemetry-bar-fill {
          height: 100%;
          border-radius: 999px;
        }
        .telemetry-bar-fill.green { background: #22c55e; }
        .telemetry-bar-fill.amber { background: #f59e0b; }
        .telemetry-bar-fill.blue { background: #38bdf8; }
        .telemetry-bar-fill.coral { background: #f43f5e; }

        .telemetry-note {
          font-size: 0.84rem;
          color: #78350f;
          line-height: 1.4;
        }

        .study-sessions-ribbon {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
          gap: 16px;
        }

        .session-stat-box {
          background: #fffdf2;
          border: 3px solid #78350f;
          border-radius: 16px;
          padding: 16px 20px;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .session-label {
          font-size: 0.74rem;
          font-weight: 800;
          color: #b45309;
          letter-spacing: 0.05em;
        }

        .session-val {
          font-family: var(--font-display);
          font-size: 1.25rem;
          color: #451a03;
        }

        .study-intervention-card {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: #fefae0;
          border: 3.5px solid #78350f;
          border-radius: var(--radius-hand-card);
          padding: 28px 32px;
          gap: 24px;
        }

        .intervention-badge {
          display: inline-block;
          font-family: var(--font-display);
          font-size: 0.78rem;
          font-weight: 800;
          color: #b45309;
          letter-spacing: 0.05em;
          margin-bottom: 6px;
        }

        .intervention-left h3 {
          font-size: 1.3rem;
          color: #451a03;
          margin-bottom: 8px;
        }

        .difficulty-text {
          font-size: 0.98rem;
          color: #78350f;
          margin-bottom: 12px;
          max-width: 60ch;
        }

        .recommendation-callout {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 0.94rem;
          color: #451a03;
        }

        .recommendation-callout strong {
          color: #ea580c;
        }

        @media print {
          .study-header-actions,
          .study-roster-card,
          .btn-jungle-cta {
            display: none !important;
          }
          .study-layout-grid {
            grid-template-columns: 1fr !important;
          }
          .naturalist-study-container {
            padding: 0 !important;
          }
        }

        @media (max-width: 960px) {
          .study-layout-grid {
            grid-template-columns: 1fr;
          }
          .study-intervention-card {
            flex-direction: column;
            align-items: flex-start;
          }
        }
      `}</style>
    </div>
  );
}
