import React from "react";
import PipMonkey from "./PipMonkey";
import { IconChevronRight, IconStar } from "../Icons";
import { playHoverTick, playSynapsePulse } from "../../utils/soundEffects";
import { useLanguage } from "../../i18n/LanguageContext";

/**
 * QuestTrailMap - Winding Illustrated Canopy Adventure Trail
 * Renders the 6 Expedition Glades connected by an illustrated winding trail.
 */
export default function QuestTrailMap({
  modules = [],
  onLaunchModule = () => {},
  savedProgress = {}
}) {
  const { t } = useLanguage();

  return (
    <div className="quest-trail-map-wrapper">
      {/* Trail Section Header */}
      <div className="trail-section-header">
        <div className="trail-badge-tag">
          <span>🗺️</span>
          <span>{t("trailMapTitle", "THE CANOPY EXPEDITION TRAIL")}</span>
        </div>
        <h2 className="trail-headline">{t("heroTitleHighlight", "The 6 Sacred Glades of Lexis")}</h2>
        <p className="trail-sub-text">
          {t("trailMapSubtitle", "Follow the winding jungle trail to strengthen reading fluency, untangle mirror letters, speak secret phonemes, and solve 3D geometry mysteries.")}
        </p>
      </div>

      {/* Interactive Trail Map Grid */}
      <div className="trail-stations-layout">
        {modules.map((mod, index) => {
          // Calculate progress if available
          const isEven = index % 2 === 1;
          const starsEarned = index === 0 ? 3 : index === 1 ? 2 : 1;

          return (
            <div
              key={mod.id}
              className={`trail-node-card ${isEven ? "align-alt" : ""}`}
              style={{ borderColor: mod.color }}
              onClick={() => {
                playSynapsePulse();
                if (mod.launch) mod.launch();
              }}
              role="button"
              tabIndex={0}
            >
              {/* Supporting Monkey Mascot hanging at Glade 3 */}
              {index === 2 && (
                <div className="trail-companion-hanger">
                  <PipMonkey size="small" />
                </div>
              )}

              {/* Station Plaque Top Bar */}
              <div className="node-plaque-header">
                <div
                  className="node-icon-crest"
                  style={{ backgroundColor: mod.bgTint, borderColor: mod.color, color: mod.color }}
                >
                  <span className="crest-symbol">{mod.icon}</span>
                </div>
                <div className="node-indexing">
                  <span className="station-pill" style={{ color: mod.color, borderColor: mod.color }}>
                    GLADE {mod.number}
                  </span>
                  <div className="station-stars">
                    {Array.from({ length: 3 }).map((_, sIdx) => (
                      <span
                        key={sIdx}
                        className={`star-icon ${sIdx < starsEarned ? "earned" : "locked"}`}
                      >
                        ⭐
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Station Title & Subtitle */}
              <h3 className="node-station-name">{mod.name}</h3>
              <h4 className="node-station-subtitle" style={{ color: mod.color }}>
                {mod.title}
              </h4>
              <p className="node-station-detail">{mod.subtitle}</p>
              <p className="node-station-desc">{mod.description}</p>

              {/* Station Action Footer */}
              <div className="node-plaque-footer">
                <span className="node-badge-tag">{mod.badge}</span>
                <button
                  className="btn-node-enter"
                  style={{ background: mod.color, borderColor: "#451a03" }}
                  title={
                    mod.actionLabel ||
                    (mod.number === "01" || mod.id === "mod-1" ? "Explore Island →" :
                     mod.number === "02" || mod.id === "mod-2" ? "Enter Sanctuary →" :
                     mod.number === "03" || mod.id === "mod-3" ? "Enter Treehouse →" :
                     mod.number === "04" || mod.id === "mod-4" ? "Enter Temple →" :
                     mod.number === "05" || mod.id === "mod-5" ? "Enter Altar →" :
                     mod.number === "06" || mod.id === "mod-6" ? "Enter Lagoon →" : "Enter Glade →")
                  }
                >
                  <span>
                    {mod.actionLabel ||
                      (mod.number === "01" || mod.id === "mod-1" ? "Explore Island →" :
                       mod.number === "02" || mod.id === "mod-2" ? "Enter Sanctuary →" :
                       mod.number === "03" || mod.id === "mod-3" ? "Enter Treehouse →" :
                       mod.number === "04" || mod.id === "mod-4" ? "Enter Temple →" :
                       mod.number === "05" || mod.id === "mod-5" ? "Enter Altar →" :
                       mod.number === "06" || mod.id === "mod-6" ? "Enter Lagoon →" : "Enter Glade →")}
                  </span>
                </button>
              </div>

              {/* Storybook Wood Plaque Screws / Brass Pins */}
              <div className="pin pin-tl" />
              <div className="pin pin-tr" />
              <div className="pin pin-bl" />
              <div className="pin pin-br" />
            </div>
          );
        })}
      </div>

      <style>{`
        .quest-trail-map-wrapper {
          position: relative;
          width: 100%;
          margin: 40px 0 60px;
        }

        .trail-section-header {
          text-align: center;
          margin-bottom: 38px;
        }

        .trail-badge-tag {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 5px 16px;
          background: #dcfce7;
          border: 2px solid #16a34a;
          border-radius: 999px;
          font-family: var(--font-display);
          font-size: 0.86rem;
          font-weight: 800;
          color: #14532d;
          margin-bottom: 12px;
          box-shadow: 0 3px 0 #16a34a;
        }

        .trail-headline {
          font-family: var(--font-display);
          font-size: clamp(1.8rem, 3.2vw, 2.8rem);
          color: #451a03;
          margin-bottom: 10px;
        }

        .trail-sub-text {
          font-size: clamp(1.02rem, 1.3vw, 1.15rem);
          color: #78350f;
          max-width: 65ch;
          margin: 0 auto;
          line-height: 1.6;
        }

        .trail-stations-layout {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
          gap: 28px;
          position: relative;
        }

        .trail-node-card {
          position: relative;
          background: #fffdf2;
          border: 3.5px solid #78350f;
          border-radius: 28px 18px 26px 20px / 20px 26px 18px 28px;
          box-shadow: 0 8px 0 #78350f, 0 14px 24px rgba(69, 26, 3, 0.14);
          padding: 28px 26px;
          display: flex;
          flex-direction: column;
          gap: 12px;
          cursor: pointer;
          user-select: none;
          transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.2s ease, border-color 0.2s ease;
          overflow: visible;
        }

        .trail-node-card:hover {
          transform: translateY(-8px) scale(1.02);
          box-shadow: 0 14px 0 #78350f, 0 20px 32px rgba(69, 26, 3, 0.22);
        }

        .trail-companion-hanger {
          position: absolute;
          top: -65px;
          right: 20px;
          z-index: 10;
          pointer-events: auto;
        }

        .node-plaque-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .node-icon-crest {
          width: 58px;
          height: 58px;
          border-radius: 50%;
          border: 3px solid;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 28px;
          box-shadow: 0 4px 0 rgba(69, 26, 3, 0.15);
          transition: transform 0.2s ease;
        }

        .trail-node-card:hover .node-icon-crest {
          transform: scale(1.12) rotate(6deg);
        }

        .node-indexing {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 4px;
        }

        .station-pill {
          font-family: var(--font-display);
          font-size: 0.8rem;
          font-weight: 800;
          background: #fefae0;
          border: 2px solid;
          border-radius: 999px;
          padding: 3px 12px;
          box-shadow: 0 2px 0 rgba(0, 0, 0, 0.08);
        }

        .station-stars {
          display: flex;
          gap: 2px;
        }

        .star-icon {
          font-size: 14px;
        }

        .star-icon.locked {
          opacity: 0.3;
          filter: grayscale(1);
        }

        .node-station-name {
          font-family: var(--font-display);
          font-size: 1.45rem;
          color: #451a03;
          line-height: 1.2;
          margin-top: 4px;
        }

        .node-station-subtitle {
          font-family: var(--font-display);
          font-size: 0.98rem;
          font-weight: 700;
          line-height: 1.3;
        }

        .node-station-detail {
          font-size: 0.92rem;
          font-weight: 700;
          color: #78350f;
        }

        .node-station-desc {
          font-size: 0.92rem;
          color: #78350f;
          line-height: 1.5;
          flex-grow: 1;
        }

        .node-plaque-footer {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-top: 14px;
          border-top: 2px dashed #fed7aa;
          margin-top: 6px;
        }

        .node-badge-tag {
          font-family: var(--font-display);
          font-size: 0.82rem;
          font-weight: 700;
          color: #78350f;
          background: #fefae0;
          border: 1.5px solid #d97706;
          border-radius: 8px;
          padding: 4px 10px;
        }

        .btn-node-enter {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 8px 16px;
          color: #ffffff;
          border: 2.5px solid #451a03;
          border-radius: 999px;
          font-family: var(--font-display);
          font-size: 0.94rem;
          font-weight: 700;
          cursor: pointer;
          box-shadow: 0 3px 0 #451a03;
          transition: transform 0.15s ease, box-shadow 0.15s ease;
        }

        .btn-node-enter:hover {
          transform: scale(1.06);
        }

        /* Brass Screws / Pins */
        .pin {
          position: absolute;
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #d97706;
          border: 1.5px solid #78350f;
          box-shadow: inset 0 1px 1px #fef08a;
        }
        .pin-tl { top: 8px; left: 8px; }
        .pin-tr { top: 8px; right: 8px; }
        .pin-bl { bottom: 8px; left: 8px; }
        .pin-br { bottom: 8px; right: 8px; }
      `}</style>
    </div>
  );
}
