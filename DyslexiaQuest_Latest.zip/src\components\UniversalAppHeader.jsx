import React, { useState, useRef, useEffect } from "react";
import {
  IconBrain,
  IconUser,
  IconVolume,
  IconVolumeOff,
  IconCheck,
  IconChevronRight
} from "./Icons";
import {
  toggleSound,
  isSoundEnabled,
  playHoverTick,
  playSynapsePulse
} from "../utils/soundEffects";
import LanguageSelector from "./LanguageSelector";
import { useLanguage } from "../i18n/LanguageContext";

/**
 * UniversalAppHeader - Canopy Expedition Navigation Bar
 * Hand-drawn bamboo & warm wood aesthetic with brass pins and tactile buttons.
 */
export default function UniversalAppHeader({
  currentScreen = "home",
  onNavigate = () => {},
  studentName = "",
  selectedClass = 1,
  profiles = [],
  onSelectProfile = () => {}
}) {
  const { t } = useLanguage();
  const [soundOn, setSoundOn] = useState(isSoundEnabled());
  const [dyslexicFont, setDyslexicFont] = useState(true);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setProfileDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSoundToggle = () => {
    const next = toggleSound();
    setSoundOn(next);
    if (next) playSynapsePulse();
  };

  const handleFontToggle = () => {
    playHoverTick();
    setDyslexicFont((prev) => !prev);
    if (!dyslexicFont) {
      document.body.classList.add("dyslexic-font-active");
      document.documentElement.style.setProperty("--font-body", "'OpenDyslexic', 'Lexend', sans-serif");
      document.documentElement.style.setProperty("--sans", "'OpenDyslexic', 'Lexend', sans-serif");
    } else {
      document.body.classList.remove("dyslexic-font-active");
      document.documentElement.style.setProperty("--font-body", "'Lexend', 'Nunito', sans-serif");
      document.documentElement.style.setProperty("--sans", "'Lexend', 'Nunito', sans-serif");
    }
  };

  const navItems = [
    { id: "home", label: t("navCamp", "Camp & Map"), icon: "🏕️" },
    { id: "stages", label: t("navExpeditions", "6 Expeditions"), icon: "🗺️" },
    { id: "profile", label: t("navPassport", "Explorer Passport"), icon: "🎒" },
    { id: "teacher", label: t("navJournal", "Guide Journal"), icon: "🦉" }
  ];

  return (
    <header className="jungle-canopy-header">
      {/* Brand Compass Logo */}
      <div
        className="jungle-header-brand"
        onClick={() => {
          playSynapsePulse();
          onNavigate("home");
        }}
        role="button"
        tabIndex={0}
        title="Return to Canopy Expedition Map"
      >
        <div className="jungle-brand-orb">
          <span className="brand-emoji">🧭</span>
        </div>
        <div className="jungle-brand-text">
          <span className="jungle-brand-title">{t("brandTitle", "DyslexiaQuest")}</span>
          <span className="jungle-brand-sub">{t("brandSub", "Canopy Adventure & Learning")}</span>
        </div>
      </div>

      {/* Center Navigation Pills */}
      <nav className="jungle-nav-pills" aria-label="Main Navigation">
        {navItems.map((item) => {
          const isActive = currentScreen === item.id;
          return (
            <button
              key={item.id}
              className={`jungle-nav-pill ${isActive ? "active" : ""}`}
              onClick={() => {
                playHoverTick();
                onNavigate(item.id);
              }}
            >
              <span className="pill-icon">{item.icon}</span>
              <span className="pill-label">{item.label}</span>
              {isActive && <span className="pill-active-leaf" />}
            </button>
          );
        })}
      </nav>

      {/* Right Controls & Passport Pill */}
      <div className="jungle-header-actions">
        {/* Student Passport Pill & Dropdown */}
        <div className="jungle-profile-dropdown-container" ref={dropdownRef}>
          <div
            className={`jungle-passport-pill ${profileDropdownOpen ? "open" : ""}`}
            onClick={() => {
              playHoverTick();
              setProfileDropdownOpen((prev) => !prev);
            }}
            title="Click to view and switch explorer passports"
          >
            <span className="passport-avatar">🎒</span>
            <div className="passport-info">
              <strong className="passport-name">
                {studentName || t("juniorExplorer", "Junior Explorer")}
              </strong>
              <span className="passport-grade">{t("classLabel", "Class")} {selectedClass || 1} ▾</span>
            </div>
          </div>

          {profileDropdownOpen && (
            <div className="jungle-passport-menu">
              <div className="passport-menu-header">
                <span>{t("passportsTitle", "EXPLORER PASSPORTS")} ({profiles.length})</span>
                <button
                  className="passport-btn-add"
                  onClick={() => {
                    playSynapsePulse();
                    setProfileDropdownOpen(false);
                    onNavigate("profile");
                  }}
                >
                  {t("newPassport", "+ New")}
                </button>
              </div>

              <div className="passport-profiles-list">
                {profiles.map((p) => {
                  const isCurrent = p.studentName === studentName;
                  return (
                    <div
                      key={p.id}
                      className={`passport-profile-item ${isCurrent ? "active" : ""}`}
                      onClick={() => {
                        playSynapsePulse();
                        onSelectProfile(p);
                        setProfileDropdownOpen(false);
                      }}
                    >
                      <div className="passport-item-avatar">
                        <IconUser size={16} />
                      </div>
                      <div className="passport-item-info">
                        <strong>{p.studentName}</strong>
                        <small>Class {p.studentClass || 1} • Age {p.studentAge || "—"}</small>
                      </div>
                      {isCurrent && (
                        <span className="passport-check-mark">
                          <IconCheck size={16} />
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="passport-menu-footer">
                <button
                  className="passport-all-btn"
                  onClick={() => {
                    setProfileDropdownOpen(false);
                    onNavigate("profile");
                  }}
                >
                  <span>{t("managePassports", "Manage All Passports")}</span>
                  <IconChevronRight size={14} />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* 10-Language Selector Dropdown */}
        <LanguageSelector />

        {/* Dyslexic Font Switcher Button */}
        <button
          className={`jungle-utility-btn ${dyslexicFont ? "active-dyslexic" : ""}`}
          onClick={handleFontToggle}
          title={dyslexicFont ? "Font: OpenDyslexic (Active)" : "Font: Lexend Reading Font"}
          aria-label="Toggle Dyslexia-Optimized Font"
        >
          <span className="util-icon">Aa</span>
          <span className="util-text">{dyslexicFont ? t("fontDyslexic", "Dyslexic") : t("fontStandard", "Standard")}</span>
        </button>

        {/* Jungle Audio FX Toggle */}
        <button
          className={`jungle-utility-btn sound-btn ${soundOn ? "active-sound" : ""}`}
          onClick={handleSoundToggle}
          title={soundOn ? "Mute jungle audio chimes" : "Enable jungle audio chimes"}
          aria-label="Toggle Sound Effects"
        >
          {soundOn ? <IconVolume size={20} /> : <IconVolumeOff size={20} />}
        </button>
      </div>

      <style>{`
        .jungle-canopy-header {
          position: sticky;
          top: 14px;
          margin: 0 16px 20px;
          z-index: 60;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 20px;
          background: #fffdf2;
          border: 3.5px solid #78350f;
          border-radius: 255px 15px 225px 15px/15px 225px 15px 255px;
          box-shadow: 0 6px 0 #78350f, 0 12px 24px rgba(69, 26, 3, 0.15);
          backdrop-filter: blur(8px);
        }

        .jungle-header-brand {
          display: flex;
          align-items: center;
          gap: 12px;
          cursor: pointer;
          user-select: none;
        }

        .jungle-brand-orb {
          width: 44px;
          height: 44px;
          border-radius: 50%;
          background: linear-gradient(145deg, #fef08a 0%, #f59e0b 100%);
          border: 2.5px solid #78350f;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 22px;
          box-shadow: 0 3px 0 #78350f;
          transition: transform 0.2s ease;
        }

        .jungle-header-brand:hover .jungle-brand-orb {
          transform: rotate(18deg) scale(1.08);
        }

        .jungle-brand-text {
          display: flex;
          flex-direction: column;
        }

        .jungle-brand-title {
          font-family: var(--font-display);
          font-size: 1.45rem;
          font-weight: 800;
          color: #451a03;
          line-height: 1.1;
        }

        .brand-highlight {
          color: #ea580c;
        }

        .jungle-brand-sub {
          font-size: 0.78rem;
          font-weight: 700;
          color: #1b7340;
          letter-spacing: 0.02em;
        }

        .jungle-nav-pills {
          display: flex;
          align-items: center;
          gap: 8px;
          background: #f7fee7;
          padding: 5px 8px;
          border: 2px solid #a3e635;
          border-radius: 999px;
        }

        .jungle-nav-pill {
          position: relative;
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 16px;
          background: transparent;
          border: none;
          border-radius: 999px;
          font-family: var(--font-display);
          font-size: 0.98rem;
          font-weight: 700;
          color: #78350f;
          cursor: pointer;
          transition: all 0.15s ease;
        }

        .jungle-nav-pill:hover {
          background: rgba(254, 240, 138, 0.5);
          color: #451a03;
        }

        .jungle-nav-pill.active {
          background: #1b7340;
          color: #ffffff;
          box-shadow: 0 3px 0 #0f3822;
        }

        .jungle-nav-pill.active .pill-active-leaf {
          position: absolute;
          bottom: -4px;
          left: 50%;
          transform: translateX(-50%);
          width: 8px;
          height: 8px;
          background: #84cc16;
          border-radius: 50%;
        }

        .jungle-header-actions {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .jungle-passport-pill {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 6px 14px;
          background: #fefae0;
          border: 2.5px solid #78350f;
          border-radius: 999px;
          cursor: pointer;
          box-shadow: 0 3px 0 #78350f;
          transition: transform 0.15s ease;
        }

        .jungle-passport-pill:hover {
          transform: translateY(-2px);
          background: #fef08a;
        }

        .passport-avatar {
          font-size: 18px;
        }

        .passport-info {
          display: flex;
          flex-direction: column;
          line-height: 1.1;
        }

        .passport-name {
          font-family: var(--font-display);
          font-size: 0.92rem;
          font-weight: 700;
          color: #451a03;
        }

        .passport-grade {
          font-size: 0.74rem;
          font-weight: 700;
          color: #b45309;
        }

        .jungle-passport-menu {
          position: absolute;
          top: calc(100% + 10px);
          right: 0;
          width: 280px;
          background: #fffdf2;
          border: 3px solid #78350f;
          border-radius: 20px;
          box-shadow: 0 10px 25px rgba(69, 26, 3, 0.25);
          padding: 14px;
          z-index: 100;
        }

        .passport-menu-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-family: var(--font-display);
          font-size: 0.82rem;
          font-weight: 700;
          color: #78350f;
          margin-bottom: 10px;
          padding-bottom: 6px;
          border-bottom: 1.5px dashed #d97706;
        }

        .passport-btn-add {
          padding: 2px 10px;
          background: #22c55e;
          color: #fff;
          border: 2px solid #15803d;
          border-radius: 999px;
          font-weight: 700;
          font-size: 0.82rem;
          cursor: pointer;
        }

        .passport-profiles-list {
          display: flex;
          flex-direction: column;
          gap: 6px;
          max-height: 200px;
          overflow-y: auto;
        }

        .passport-profile-item {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 8px 10px;
          border-radius: 12px;
          cursor: pointer;
          transition: background 0.15s ease;
        }

        .passport-profile-item:hover {
          background: #fef08a;
        }

        .passport-profile-item.active {
          background: #fefae0;
          border: 1.5px solid #d97706;
        }

        .passport-item-info strong {
          display: block;
          font-size: 0.92rem;
          color: #451a03;
        }

        .passport-item-info small {
          color: #78350f;
          font-size: 0.76rem;
        }

        .passport-check-mark {
          margin-left: auto;
          color: #16a34a;
        }

        .passport-menu-footer {
          margin-top: 10px;
          padding-top: 8px;
          border-top: 1px solid #fed7aa;
        }

        .passport-all-btn {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 6px 8px;
          background: none;
          border: none;
          font-family: var(--font-display);
          font-size: 0.86rem;
          font-weight: 700;
          color: #ea580c;
          cursor: pointer;
        }

        .jungle-utility-btn {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 7px 14px;
          background: #fefae0;
          border: 2.5px solid #78350f;
          border-radius: 999px;
          font-family: var(--font-display);
          font-size: 0.88rem;
          font-weight: 700;
          color: #78350f;
          cursor: pointer;
          box-shadow: 0 3px 0 #78350f;
          transition: transform 0.15s ease, background 0.15s ease;
        }

        .jungle-utility-btn:hover {
          transform: translateY(-2px);
          background: #fef08a;
        }

        .jungle-utility-btn.active-dyslexic {
          background: #f59e0b;
          color: #ffffff;
          border-color: #92400e;
        }

        .jungle-utility-btn.sound-btn {
          padding: 7px 10px;
        }

        .jungle-utility-btn.active-sound {
          color: #15803d;
        }

        @media (max-width: 900px) {
          .jungle-canopy-header {
            flex-wrap: wrap;
            gap: 10px;
            padding: 8px 14px;
          }
          .jungle-nav-pills {
            order: 3;
            width: 100%;
            justify-content: center;
          }
          .pill-label {
            font-size: 0.84rem;
          }
        }
      `}</style>
    </header>
  );
}
