import { getComprehensionLevelsForClass } from "./data/comprehensionBank";
import React, { useEffect, useRef, useState } from "react";
import "./App.css";
import "./3d-website.css";
import "./jungle-theme.css";
import HomeScreen from "./components/HomeScreen";
import FreshWelcomePage from "./components/FreshWelcomePage";
import TeacherDashboardView from "./components/TeacherDashboardView";
import {
  getAllProfiles,
  getActiveProfile,
  saveProfile as saveProfileToStore,
  setActiveProfile as setActiveProfileInStore,
  deleteProfile as deleteProfileFromStore
} from "./utils/profileManager";
import UniversalAppHeader from "./components/UniversalAppHeader";
import { useLanguage } from "./i18n/LanguageContext";
import SpatialBackground3D from "./components/3d/SpatialBackground3D";
import ShapeViewer3D from "./components/3d/ShapeViewer3D";
import ParticleFX from "./components/3d/ParticleFX";
import { playSuccessChime, playLetterFlip } from "./utils/soundEffects";
import {
  IconBrain,
  IconEye,
  IconMic,
  IconEdit,
  IconCalculator,
  IconShapes,
  IconVolume,
  IconVolumeOff,
  IconPrinter,
  IconLightbulb,
  IconCheck,
  IconCross,
  IconChevronLeft,
  IconChevronRight,
  IconArrowRight,
  IconStar,
  IconAward,
  IconShieldCheck,
  IconTarget,
  IconBookOpen,
  IconPlay,
  IconRefresh,
  IconUser,
  IconLayers,
  IconGraduationCap
} from "./components/Icons";

function renderCategoryIcon(key, size = 20) {
  switch (key) {
    case "eye":
    case "visual_dyslexia":
      return <IconEye size={size} />;
    case "mic":
    case "phonological_dyslexia":
      return <IconMic size={size} />;
    case "edit":
      return <IconEdit size={size} />;
    case "calculator":
    case "dyscalculia":
      return <IconCalculator size={size} />;
    case "shapes":
    case "spatial_geometry":
      return <IconShapes size={size} />;
    case "star":
    case "emergent_mastery":
      return <IconStar size={size} />;
    case "brain":
      return <IconBrain size={size} />;
    case "book":
      return <IconBookOpen size={size} />;
    case "target":
      return <IconTarget size={size} />;
    case "layers":
      return <IconLayers size={size} />;
    case "award":
      return <IconAward size={size} />;
    default:
      return <IconAward size={size} />;
  }
}

// ==================== MATHS QUESTION BANK ====================

const mathQuestionBanks = {
  1: {
    1: [
      { question: "What comes after 7?", options: ["6", "8", "9", "5"], answer: "8" },
      { question: "What comes before 10?", options: ["8", "11", "9", "7"], answer: "9" },
      { question: "What is 5 + 3?", options: ["7", "9", "6", "8"], answer: "8" },
      { question: "What is 9 - 4?", options: ["5", "4", "6", "3"], answer: "5" },
      { question: "Which number is greater?", options: ["3", "4", "6", "2"], answer: "6" },
      { question: "How many sides does a triangle have?", options: ["2", "4", "5", "3"], answer: "3" },
      { question: "What is 7 + 2?", options: ["9", "8", "10", "7"], answer: "9" },
      { question: "What is 10 - 3?", options: ["6", "7", "8", "5"], answer: "7" },
      { question: "Which number is smaller?", options: ["9", "7", "8", "5"], answer: "5" },
      { question: "Complete: 2, 4, 6, __", options: ["8", "7", "9", "10"], answer: "8" }
    ],

    2: [
      { question: "What is 6 + 7?", options: ["12", "13", "14", "11"], answer: "13" },
      { question: "What is 15 - 6?", options: ["8", "10", "9", "7"], answer: "9" },
      { question: "What is 3 + 9?", options: ["12", "11", "13", "10"], answer: "12" },
      { question: "What is 8 - 5?", options: ["2", "3", "4", "5"], answer: "3" },
      { question: "Which number is greater?", options: ["9", "7", "12", "10"], answer: "12" },
      { question: "How many sides does a square have?", options: ["3", "5", "6", "4"], answer: "4" },
      { question: "What is 4 + 8?", options: ["10", "12", "11", "13"], answer: "12" },
      { question: "What is 14 - 7?", options: ["6", "8", "7", "9"], answer: "7" },
      { question: "Complete: 5, 10, 15, __", options: ["18", "25", "30", "20"], answer: "20" },
      { question: "How many sides does a rectangle have?", options: ["4", "3", "5", "6"], answer: "4" }
    ],

    3: [
      { question: "What is 20 + 15?", options: ["25", "30", "35", "40"], answer: "35" },
      { question: "What is 30 - 12?", options: ["16", "20", "22", "18"], answer: "18" },
      { question: "What is 5 × 2?", options: ["10", "7", "12", "15"], answer: "10" },
      { question: "What is 12 ÷ 3?", options: ["3", "4", "5", "6"], answer: "4" },
      { question: "What is 25 + 10?", options: ["30", "40", "45", "35"], answer: "35" },
      { question: "What is 40 - 15?", options: ["25", "20", "30", "35"], answer: "25" },
      { question: "What is 3 × 4?", options: ["7", "12", "10", "14"], answer: "12" },
      { question: "What is 16 ÷ 4?", options: ["2", "3", "4", "5"], answer: "4" },
      { question: "Which is greater?", options: ["42", "24", "34", "14"], answer: "42" },
      { question: "How many minutes are in 1 hour?", options: ["30", "60", "45", "90"], answer: "60" }
    ]
  },

  2: {
    1: [
      { question: "What is 24 + 15?", options: ["38", "40", "39", "37"], answer: "39" },
      { question: "What is 56 - 23?", options: ["31", "32", "34", "33"], answer: "33" },
      { question: "What is 5 × 2?", options: ["7", "10", "12", "8"], answer: "10" },
      { question: "What is 12 ÷ 3?", options: ["3", "5", "4", "6"], answer: "4" },
      { question: "What is the place value of 5 in 57?", options: ["5", "7", "500", "50"], answer: "50" },
      { question: "What comes next? 5, 10, 15, __", options: ["20", "18", "19", "25"], answer: "20" },
      { question: "How many minutes are in 1 hour?", options: ["30", "45", "60", "100"], answer: "60" },
      { question: "Which shape has 4 equal sides?", options: ["Triangle", "Circle", "Oval", "Square"], answer: "Square" },
      { question: "You have ₹20 and spend ₹7. How much is left?", options: ["₹13", "₹12", "₹14", "₹15"], answer: "₹13" },
      { question: "What is 9 × 3?", options: ["18", "27", "21", "24"], answer: "27" }
    ],

    2: [
      { question: "What is 35 + 27?", options: ["52", "72", "60", "62"], answer: "62" },
      { question: "What is 80 - 35?", options: ["45", "35", "40", "50"], answer: "45" },
      { question: "What is 6 × 4?", options: ["20", "24", "28", "30"], answer: "24" },
      { question: "What is 20 ÷ 5?", options: ["3", "5", "4", "6"], answer: "4" },
      { question: "What is the place value of 7 in 72?", options: ["70", "7", "2", "700"], answer: "70" },
      { question: "Complete: 10, 20, 30, __", options: ["35", "40", "45", "50"], answer: "40" },
      { question: "What is ₹50 - ₹18?", options: ["₹30", "₹34", "₹32", "₹38"], answer: "₹32" },
      { question: "How many hours are in one day?", options: ["12", "20", "30", "24"], answer: "24" },
      { question: "What is 7 × 5?", options: ["30", "35", "40", "45"], answer: "35" },
      { question: "What is 18 ÷ 2?", options: ["7", "8", "9", "10"], answer: "9" }
    ],

    3: [
      { question: "What is 125 + 75?", options: ["190", "210", "220", "200"], answer: "200" },
      { question: "What is 300 - 125?", options: ["175", "165", "185", "195"], answer: "175" },
      { question: "What is 8 × 7?", options: ["54", "58", "56", "64"], answer: "56" },
      { question: "What is 36 ÷ 6?", options: ["5", "7", "8", "6"], answer: "6" },
      { question: "What is half of 20?", options: ["10", "5", "15", "20"], answer: "10" },
      { question: "What is double 15?", options: ["20", "30", "25", "35"], answer: "30" },
      { question: "How many centimetres are in 1 metre?", options: ["10", "50", "1000", "100"], answer: "100" },
      { question: "A pencil costs ₹8. How much do 4 pencils cost?", options: ["₹32", "₹24", "₹28", "₹36"], answer: "₹32" },
      { question: "What is the perimeter of a square with 5 cm sides?", options: ["10 cm", "20 cm", "15 cm", "25 cm"], answer: "20 cm" },
      { question: "Which fraction means one half?", options: ["1/3", "1/4", "1/2", "2/3"], answer: "1/2" }
    ]
  },

  3: {
    1: [
      { question: "What is 245 + 132?", options: ["377", "367", "387", "357"], answer: "377" },
      { question: "What is 500 - 275?", options: ["215", "225", "235", "250"], answer: "225" },
      { question: "What is 7 × 8?", options: ["54", "64", "56", "48"], answer: "56" },
      { question: "What is 36 ÷ 6?", options: ["5", "7", "8", "6"], answer: "6" },
      { question: "Which fraction represents one half?", options: ["1/3", "1/2", "1/4", "2/3"], answer: "1/2" },
      { question: "What is the place value of 6 in 462?", options: ["6", "600", "60", "2"], answer: "60" },
      { question: "How many minutes are in 2 hours?", options: ["60", "90", "180", "120"], answer: "120" },
      { question: "A pencil costs ₹8. How much do 4 pencils cost?", options: ["₹32", "₹24", "₹28", "₹36"], answer: "₹32" },
      { question: "A square has sides of 5 cm. What is its perimeter?", options: ["10 cm", "15 cm", "20 cm", "25 cm"], answer: "20 cm" },
      { question: "What is 125 + 75?", options: ["190", "210", "220", "200"], answer: "200" }
    ],

    2: [
      { question: "What is 345 + 256?", options: ["601", "591", "611", "621"], answer: "601" },
      { question: "What is 700 - 325?", options: ["365", "375", "385", "395"], answer: "375" },
      { question: "What is 9 × 6?", options: ["45", "56", "63", "54"], answer: "54" },
      { question: "What is 72 ÷ 8?", options: ["9", "7", "8", "10"], answer: "9" },
      { question: "What is one quarter of 20?", options: ["4", "5", "6", "10"], answer: "5" },
      { question: "What is 3/4 of 20?", options: ["10", "12", "15", "18"], answer: "15" },
      { question: "What is the area of 5 cm × 4 cm?", options: ["20 cm²", "9 cm²", "16 cm²", "25 cm²"], answer: "20 cm²" },
      { question: "What is 450 + 150?", options: ["500", "600", "550", "650"], answer: "600" },
      { question: "What is 900 - 450?", options: ["350", "400", "450", "500"], answer: "450" },
      { question: "What is 6 × 9?", options: ["45", "63", "72", "54"], answer: "54" }
    ],

    3: [
      { question: "What is 1,250 + 750?", options: ["1,500", "2,000", "1,750", "2,250"], answer: "2,000" },
      { question: "What is 2,000 - 875?", options: ["1,025", "1,225", "1,125", "1,325"], answer: "1,125" },
      { question: "What is 12 × 8?", options: ["86", "106", "116", "96"], answer: "96" },
      { question: "What is 144 ÷ 12?", options: ["12", "10", "11", "14"], answer: "12" },
      { question: "What is 0.5 as a fraction?", options: ["1/3", "1/4", "1/2", "2/3"], answer: "1/2" },
      { question: "What is 25% of 100?", options: ["10", "20", "50", "25"], answer: "25" },
      { question: "A rectangle is 8 cm long and 5 cm wide. What is its area?", options: ["40 cm²", "13 cm²", "26 cm²", "45 cm²"], answer: "40 cm²" },
      { question: "What is 3.5 + 2.2?", options: ["5.5", "5.7", "5.6", "5.8"], answer: "5.7" },
      { question: "What is the perimeter of a rectangle 6 cm × 4 cm?", options: ["10 cm", "24 cm", "28 cm", "20 cm"], answer: "20 cm" },
      { question: "What is the average of 10, 20 and 30?", options: ["20", "15", "25", "30"], answer: "20" }
    ]
  },

  4: {
    1: [
      { question: "What is 2,345 + 1,256?", options: ["3,501", "3,601", "3,701", "3,801"], answer: "3,601" },
      { question: "What is 5,000 - 2,375?", options: ["2,525", "2,725", "2,625", "2,825"], answer: "2,625" },
      { question: "What is 24 × 6?", options: ["144", "124", "134", "154"], answer: "144" },
      { question: "What is 96 ÷ 8?", options: ["10", "12", "11", "14"], answer: "12" },
      { question: "Which is greater?", options: ["1/4", "1/8", "1/2", "1/10"], answer: "1/2" },
      { question: "Which fraction is equal to 0.5?", options: ["1/3", "2/3", "3/4", "1/2"], answer: "1/2" },
      { question: "Which number is a factor of 24?", options: ["5", "8", "7", "11"], answer: "8" },
      { question: "What is the area of a rectangle 6 cm long and 4 cm wide?", options: ["10 cm²", "20 cm²", "24 cm²", "28 cm²"], answer: "24 cm²" },
      { question: "What is 3.5 + 2.2?", options: ["5.5", "5.6", "5.8", "5.7"], answer: "5.7" },
      { question: "A book costs ₹125. How much do 3 books cost?", options: ["₹375", "₹250", "₹325", "₹425"], answer: "₹375" }
    ],

    2: [
      { question: "What is 4,560 + 2,340?", options: ["6,700", "6,800", "6,900", "7,000"], answer: "6,900" },
      { question: "What is 8,000 - 3,450?", options: ["4,450", "4,650", "4,750", "4,550"], answer: "4,550" },
      { question: "What is 35 × 4?", options: ["140", "120", "130", "150"], answer: "140" },
      { question: "What is 144 ÷ 12?", options: ["10", "12", "11", "13"], answer: "12" },
      { question: "What is 2/4 in simplest form?", options: ["1/3", "2/3", "3/4", "1/2"], answer: "1/2" },
      { question: "What is 0.75 as a fraction?", options: ["3/4", "1/2", "2/3", "4/5"], answer: "3/4" },
      { question: "What is 15% of 100?", options: ["10", "15", "20", "25"], answer: "15" },
      { question: "What is the perimeter of a square with side 7 cm?", options: ["21 cm", "35 cm", "28 cm", "49 cm"], answer: "28 cm" },
      { question: "What is 4.5 + 2.5?", options: ["7", "6", "8", "9"], answer: "7" },
      { question: "A box has 24 pencils. If 6 are used, how many remain?", options: ["16", "18", "20", "22"], answer: "18" }
    ],

    3: [
      { question: "What is 6,250 + 3,750?", options: ["9,000", "9,500", "10,000", "10,500"], answer: "10,000" },
      { question: "What is 10,000 - 4,625?", options: ["5,275", "5,475", "5,575", "5,375"], answer: "5,375" },
      { question: "What is 125 × 8?", options: ["900", "1,000", "950", "1,050"], answer: "1,000" },
      { question: "What is 225 ÷ 15?", options: ["10", "12", "15", "18"], answer: "15" },
      { question: "What is 1/2 + 1/4?", options: ["2/4", "4/4", "5/4", "3/4"], answer: "3/4" },
      { question: "What is 25% of 200?", options: ["50", "25", "40", "75"], answer: "50" },
      { question: "What is 2.75 + 1.25?", options: ["3.5", "4.25", "4", "4.5"], answer: "4" },
      { question: "What is the area of 9 cm × 5 cm?", options: ["35 cm²", "40 cm²", "50 cm²", "45 cm²"], answer: "45 cm²" },
      { question: "What is the average of 10, 20 and 30?", options: ["20", "15", "25", "30"], answer: "20" },
      { question: "How many centimetres are in 3 metres?", options: ["30", "300", "100", "200"], answer: "300" }
    ]
  },

  5: {
    1: [
      { question: "What is 12,450 + 8,375?", options: ["20,725", "20,925", "21,025", "20,825"], answer: "20,825" },
      { question: "What is 15,000 - 6,725?", options: ["8,275", "8,175", "8,375", "8,475"], answer: "8,275" },
      { question: "What is 125 × 8?", options: ["900", "1,000", "950", "1,050"], answer: "1,000" },
      { question: "What is 144 ÷ 12?", options: ["10", "11", "12", "14"], answer: "12" },
      { question: "What is 3/4 + 1/4?", options: ["1", "1/2", "3/4", "5/4"], answer: "1" },
      { question: "What is 2.75 + 1.25?", options: ["3.5", "4", "4.25", "4.5"], answer: "4" },
      { question: "What is 25% of 100?", options: ["10", "20", "25", "50"], answer: "25" },
      { question: "What is the average of 10, 20 and 30?", options: ["15", "25", "30", "20"], answer: "20" },
      { question: "A rectangle is 8 cm long and 5 cm wide. What is its area?", options: ["13 cm²", "40 cm²", "26 cm²", "45 cm²"], answer: "40 cm²" },
      { question: "How many centimetres are in 3 metres?", options: ["30", "100", "300", "200"], answer: "300" }
    ],

    2: [
      { question: "What is 15,250 + 7,850?", options: ["22,100", "24,100", "25,100", "23,100"], answer: "23,100" },
      { question: "What is 20,000 - 8,750?", options: ["11,250", "10,250", "12,250", "13,250"], answer: "11,250" },
      { question: "What is 45 × 12?", options: ["440", "500", "540", "560"], answer: "540" },
      { question: "What is 360 ÷ 12?", options: ["20", "25", "35", "30"], answer: "30" },
      { question: "What is 2/5 + 1/5?", options: ["3/5", "2/5", "4/5", "1"], answer: "3/5" },
      { question: "What is 0.25 as a fraction?", options: ["1/2", "1/4", "1/3", "3/4"], answer: "1/4" },
      { question: "What is 10% of 500?", options: ["25", "40", "100", "50"], answer: "50" },
      { question: "What is the perimeter of a rectangle 8 cm × 5 cm?", options: ["26 cm", "13 cm", "20 cm", "40 cm"], answer: "26 cm" },
      { question: "What is 5.5 + 2.5?", options: ["7", "8", "9", "10"], answer: "8" },
      { question: "What is 3/4 of 20?", options: ["10", "12", "15", "18"], answer: "15" }
    ],

    3: [
      { question: "What is 25,000 + 17,500?", options: ["42,500", "40,500", "41,500", "43,500"], answer: "42,500" },
      { question: "What is 30,000 - 12,750?", options: ["16,250", "17,250", "18,250", "19,250"], answer: "17,250" },
      { question: "What is 125 × 16?", options: ["1,500", "2,500", "2,000", "3,000"], answer: "2,000" },
      { question: "What is 625 ÷ 25?", options: ["20", "30", "35", "25"], answer: "25" },
      { question: "What is 3/5 + 1/5?", options: ["3/5", "4/5", "5/5", "6/5"], answer: "4/5" },
      { question: "What is 50% of 240?", options: ["100", "140", "120", "160"], answer: "120" },
      { question: "What is 3.75 + 2.25?", options: ["5", "6.5", "7", "6"], answer: "6" },
      { question: "A rectangle is 12 cm long and 7 cm wide. What is its area?", options: ["84 cm²", "19 cm²", "38 cm²", "96 cm²"], answer: "84 cm²" },
      { question: "What is the average of 20, 30 and 40?", options: ["20", "35", "30", "40"], answer: "30" },
      { question: "What is 1.5 metres in centimetres?", options: ["15", "100", "200", "150"], answer: "150" }
    ]
  }
};
/* =========================================================
   DYSLEXIA QUEST — CONSOLIDATED APP
   ========================================================= */
const createWavBlob = (samples, sampleRate) => {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);

  const writeString = (offset, text) => {
    for (let i = 0; i < text.length; i++) {
      view.setUint8(offset + i, text.charCodeAt(i));
    }
  };

  const write16 = (offset, value) => {
    view.setUint16(offset, value, true);
  };

  const write32 = (offset, value) => {
    view.setUint32(offset, value, true);
  };

  writeString(0, "RIFF");
  write32(4, 36 + samples.length * 2);
  writeString(8, "WAVE");

  writeString(12, "fmt ");
  write32(16, 16);
  write16(20, 1);
  write16(22, 1);
  write32(24, sampleRate);
  write32(28, sampleRate * 2);
  write16(32, 2);
  write16(34, 16);

  writeString(36, "data");
  write32(40, samples.length * 2);

  let offset = 44;

  for (let i = 0; i < samples.length; i++) {
    let sample = samples[i];

    sample = Math.max(-1, Math.min(1, sample));

    const value =
      sample < 0
        ? sample * 0x8000
        : sample * 0x7fff;

    view.setInt16(offset, value, true);
    offset += 2;
  }

  return new Blob([buffer], {
    type: "audio/wav",
  });
};

/* =========================================================
   BLOB TO DATA URL
   DO NOT CHANGE - ORIGINAL AUDIO CODE
   ========================================================= */

const blobToDataURL = (blob) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onloadend = () => {
      resolve(reader.result);
    };

    reader.onerror = reject;

    reader.readAsDataURL(blob);
  });
};
const shuffleArray = (array) => {
  const shuffled = [...array];

  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));

    [shuffled[i], shuffled[j]] = [
      shuffled[j],
      shuffled[i],
    ];
  }

  return shuffled;
};

/*
  Creates a completely fresh Stage 1 copy.
  - Questions are shuffled.
  - Answer options are shuffled.
  - The original stage1Levels data is never modified.
*/
const stage2Levels = [
  {
    id: 1,
    title: "WORDS",
    difficulty: "EASY",
    description: "READ SIMPLE WORDS ALOUD.",
    exercises: [
      {
        id: "s2w1",
        type: "word",
        text: "CAT",
      },
      {
        id: "s2w2",
        type: "word",
        text: "DOG",
      },
      {
        id: "s2w3",
        type: "word",
        text: "SUN",
      },
      {
        id: "s2w4",
        type: "word",
        text: "BOOK",
      },
      {
        id: "s2w5",
        type: "word",
        text: "TREE",
      },
      {
        id: "s2w6",
        type: "word",
        text: "FISH",
      },
      {
        id: "s2w7",
        type: "word",
        text: "BALL",
      },
      {
        id: "s2w8",
        type: "word",
        text: "HOUSE",
      },
      {
        id: "s2w9",
        type: "word",
        text: "SCHOOL",
      },
      {
        id: "s2w10",
        type: "word",
        text: "APPLE",
      },
    ],
  },

  {
    id: 2,
    title: "SENTENCES",
    difficulty: "MEDIUM",
    description: "READ SHORT SENTENCES ALOUD.",
    exercises: [
      {
        id: "s2s1",
        type: "sentence",
        text: "THE CAT IS BIG.",
      },
      {
        id: "s2s2",
        type: "sentence",
        text: "THE DOG CAN RUN.",
      },
      {
        id: "s2s3",
        type: "sentence",
        text: "I LIKE MY BOOK.",
      },
      {
        id: "s2s4",
        type: "sentence",
        text: "THE SUN IS HOT.",
      },
      {
        id: "s2s5",
        type: "sentence",
        text: "THE FISH CAN SWIM.",
      },
      {
        id: "s2s6",
        type: "sentence",
        text: "I SEE A RED BALL.",
      },
      {
        id: "s2s7",
        type: "sentence",
        text: "THE CAT SAT ON THE MAT.",
      },
      {
        id: "s2s8",
        type: "sentence",
        text: "I LIKE TO READ BOOKS.",
      },
      {
        id: "s2s9",
        type: "sentence",
        text: "THE BOY IS IN THE HOUSE.",
      },
      {
        id: "s2s10",
        type: "sentence",
        text: "THE GIRL HAS A BLUE BAG.",
      },
    ],
  },

  {
    id: 3,
    title: "PARAGRAPHS",
    difficulty: "DIFFICULT",
    description: "READ A SHORT PARAGRAPH ALOUD.",
    exercises: [
      {
        id: "s2p1",
        type: "paragraph",
        text:
          "THE CAT SAT ON THE MAT. IT WAS WARM AND SUNNY. THE CAT CLOSED ITS EYES AND RESTED.",
      },
      {
        id: "s2p2",
        type: "paragraph",
        text:
          "SAM HAS A LITTLE DOG. THE DOG LIKES TO RUN IN THE PARK. EVERY DAY, SAM TAKES THE DOG OUTSIDE.",
      },
      {
        id: "s2p3",
        type: "paragraph",
        text:
          "MIA LIKES TO READ BOOKS. SHE READS A LITTLE EVERY DAY. READING HELPS HER LEARN NEW WORDS.",
      },
      {
        id: "s2p4",
        type: "paragraph",
        text:
          "THE SUN WAS SHINING IN THE SKY. THE CHILDREN WENT OUTSIDE TO PLAY. THEY PLAYED WITH A BALL.",
      },
      {
        id: "s2p5",
        type: "paragraph",
        text:
          "TOM WENT TO SCHOOL IN THE MORNING. HE CARRIED HIS BLUE BAG. INSIDE HIS BAG WAS HIS FAVOURITE BOOK.",
      },
      {
        id: "s2p6",
        type: "paragraph",
        text:
          "ANNA LOVES TO DRAW PICTURES. SHE USES MANY COLOURS IN HER NOTEBOOK. AFTER SCHOOL, SHE SHOWS HER DRAWINGS TO HER FRIENDS.",
      },
      {
        id: "s2p7",
        type: "paragraph",
        text:
          "THE FAMILY WENT TO THE PARK ON SUNDAY. THEY PLAYED GAMES AND ATE LUNCH UNDER A BIG TREE. EVERYONE HAD A HAPPY DAY.",
      },
      {
        id: "s2p8",
        type: "paragraph",
        text:
          "RAHUL FOUND A SMALL KITE IN HIS ROOM. HE TOOK IT OUTSIDE AND WAITED FOR THE WIND. SOON THE KITE WAS FLYING HIGH IN THE SKY.",
      },
      {
        id: "s2p9",
        type: "paragraph",
        text:
          "MEENA WAKES UP EARLY EACH MORNING. SHE GETS READY FOR SCHOOL AND PACKS HER BOOKS. SHE ALWAYS CHECKS HER BAG BEFORE LEAVING HOME.",
      },
      {
        id: "s2p10",
        type: "paragraph",
        text:
          "READING CAN HELP CHILDREN LEARN NEW WORDS. WHEN WE READ SLOWLY AND CAREFULLY, WE CAN UNDERSTAND THE STORY BETTER AND REMEMBER MORE.",
      },
    ],
  },
];



const CLASS1_STAGE2_BANK = [
  {
    id: 1,
    title: "LEVEL 1 — EASY",
    difficulty: "EASY",
    description: "Read simple Class 1 words aloud.",
    exercises: [
      { id: "c1-s2-l1-q1", type: "word", text: "CAT" },
      { id: "c1-s2-l1-q2", type: "word", text: "DOG" },
      { id: "c1-s2-l1-q3", type: "word", text: "SUN" },
      { id: "c1-s2-l1-q4", type: "word", text: "RUN" },
      { id: "c1-s2-l1-q5", type: "word", text: "MAP" },
      { id: "c1-s2-l1-q6", type: "word", text: "BED" },
      { id: "c1-s2-l1-q7", type: "word", text: "FISH" },
      { id: "c1-s2-l1-q8", type: "word", text: "BOOK" },
      { id: "c1-s2-l1-q9", type: "word", text: "TREE" },
    ],
  },

  {
    id: 2,
    title: "LEVEL 2 — MEDIUM",
    difficulty: "MEDIUM",
    description: "Read short Class 1 sentences aloud.",
    exercises: [
      { id: "c1-s2-l2-q1", type: "sentence", text: "THE CAT IS BIG." },
      { id: "c1-s2-l2-q2", type: "sentence", text: "THE DOG CAN RUN." },
      { id: "c1-s2-l2-q3", type: "sentence", text: "I SEE A RED BALL." },
      { id: "c1-s2-l2-q4", type: "sentence", text: "THE SUN IS HOT." },
      { id: "c1-s2-l2-q5", type: "sentence", text: "MY BOOK IS BLUE." },
      { id: "c1-s2-l2-q6", type: "sentence", text: "THE BIRD CAN FLY." },
      { id: "c1-s2-l2-q7", type: "sentence", text: "WE GO TO SCHOOL." },
      { id: "c1-s2-l2-q8", type: "sentence", text: "THE BOY HAS A BAG." },
      { id: "c1-s2-l2-q9", type: "sentence", text: "I LIKE TO PLAY." },
    ],
  },

  {
    id: 3,
    title: "LEVEL 3 — HARD",
    difficulty: "HARD",
    description: "Read slightly longer Class 1 words aloud.",
    exercises: [
      { id: "c1-s2-l3-q1", type: "word", text: "RABBIT" },
      { id: "c1-s2-l3-q2", type: "word", text: "WINDOW" },
      { id: "c1-s2-l3-q3", type: "word", text: "GARDEN" },
      { id: "c1-s2-l3-q4", type: "word", text: "YELLOW" },
      { id: "c1-s2-l3-q5", type: "word", text: "TEACHER" },
      { id: "c1-s2-l3-q6", type: "word", text: "MORNING" },
      { id: "c1-s2-l3-q7", type: "word", text: "CHILDREN" },
      { id: "c1-s2-l3-q8", type: "word", text: "PLAYGROUND" },
      { id: "c1-s2-l3-q9", type: "word", text: "ELEPHANT" },
    ],
  },
];

const CLASS1_STAGE3_BANK = [
  {
    id: 1,
    title: "LEVEL 1 — EASY",
    difficulty: "EASY",
    description: "Complete the missing letter.",
    exercises: [
      {
        id: "c1-s3-l1-q1",
        type: "missing-letter",
        question: "Complete: C _ T",
        answer: "A",
      },
      {
        id: "c1-s3-l1-q2",
        type: "missing-letter",
        question: "Complete: D _ G",
        answer: "O",
      },
      {
        id: "c1-s3-l1-q3",
        type: "missing-letter",
        question: "Complete: S _ N",
        answer: "U",
      },
      {
        id: "c1-s3-l1-q4",
        type: "missing-letter",
        question: "Complete: M _ P",
        answer: "A",
      },
      {
        id: "c1-s3-l1-q5",
        type: "missing-letter",
        question: "Complete: B _ D",
        answer: "E",
      },
      {
        id: "c1-s3-l1-q6",
        type: "missing-letter",
        question: "Complete: F _ SH",
        answer: "I",
      },
      {
        id: "c1-s3-l1-q7",
        type: "missing-letter",
        question: "Complete: TR _ E",
        answer: "E",
      },
      {
        id: "c1-s3-l1-q8",
        type: "missing-letter",
        question: "Complete: B _ LL",
        answer: "A",
      },
      {
        id: "c1-s3-l1-q9",
        type: "missing-letter",
        question: "Complete: H _ T",
        answer: "A",
      },
    ],
  },

  {
    id: 2,
    title: "LEVEL 2 — MEDIUM",
    difficulty: "MEDIUM",
    description: "Arrange the letters to make a word.",
    exercises: [
      {
        id: "c1-s3-l2-q1",
        type: "arrange",
        question: "Arrange: C / A / T",
        answer: "CAT",
      },
      {
        id: "c1-s3-l2-q2",
        type: "arrange",
        question: "Arrange: D / O / G",
        answer: "DOG",
      },
      {
        id: "c1-s3-l2-q3",
        type: "arrange",
        question: "Arrange: S / U / N",
        answer: "SUN",
      },
      {
        id: "c1-s3-l2-q4",
        type: "arrange",
        question: "Arrange: B / A / G",
        answer: "BAG",
      },
      {
        id: "c1-s3-l2-q5",
        type: "arrange",
        question: "Arrange: R / U / N",
        answer: "RUN",
      },
      {
        id: "c1-s3-l2-q6",
        type: "arrange",
        question: "Arrange: M / A / P",
        answer: "MAP",
      },
      {
        id: "c1-s3-l2-q7",
        type: "arrange",
        question: "Arrange: F / I / S / H",
        answer: "FISH",
      },
      {
        id: "c1-s3-l2-q8",
        type: "arrange",
        question: "Arrange: B / O / O / K",
        answer: "BOOK",
      },
      {
        id: "c1-s3-l2-q9",
        type: "arrange",
        question: "Arrange: T / R / E / E",
        answer: "TREE",
      },
    ],
  },

  {
    id: 3,
    title: "LEVEL 3 — HARD",
    difficulty: "HARD",
    description: "Choose the sentence that makes sense.",
    exercises: [
      {
        id: "c1-s3-l3-q1",
        type: "choice",
        question: "Which sentence makes sense?",
        options: ["The bird flies in the sky."], answer: "The bird flies in the sky.",
      },
      {
        id: "c1-s3-l3-q2",
        type: "choice",
        question: "Which sentence makes sense?",
        options: ["The dog runs in the park."], answer: "The dog runs in the park.",
      },
      {
        id: "c1-s3-l3-q3",
        type: "choice",
        question: "Which sentence makes sense?",
        options: ["The fish swims in water."], answer: "The fish swims in water.",
      },
      {
        id: "c1-s3-l3-q4",
        type: "choice",
        question: "Which sentence makes sense?",
        options: ["The boy reads a book."], answer: "The boy reads a book.",
      },
      {
        id: "c1-s3-l3-q5",
        type: "choice",
        question: "Which sentence makes sense?",
        options: ["The girl drinks water."], answer: "The girl drinks water.",
      },
      {
        id: "c1-s3-l3-q6",
        type: "choice",
        question: "Which sentence makes sense?",
        options: ["The sun shines in the sky."], answer: "The sun shines in the sky.",
      },
      {
        id: "c1-s3-l3-q7",
        type: "choice",
        question: "Which sentence makes sense?",
        options: ["The teacher writes on the board."], answer: "The teacher writes on the board.",
      },
      {
        id: "c1-s3-l3-q8",
        type: "choice",
        question: "Which sentence makes sense?",
        options: ["The cat sleeps on the mat."], answer: "The cat sleeps on the mat.",
      },
      {
        id: "c1-s3-l3-q9",
        type: "choice",
        question: "Which sentence makes sense?",
        options: ["The children play outside."], answer: "The children play outside.",
      },
    ],
  },
];

const CLASS2_STAGE2_BANK = [
  {
    id: 1,
    title: "LEVEL 1 — EASY",
    difficulty: "EASY",
    description: "Read Class 2 words aloud.",
    exercises: [
      { id: "c2-s2-l1-q1", type: "word", text: "ship" },
      { id: "c2-s2-l1-q2", type: "word", text: "chair" },
      { id: "c2-s2-l1-q3", type: "word", text: "shop" },
      { id: "c2-s2-l1-q4", type: "word", text: "fish" },
      { id: "c2-s2-l1-q5", type: "word", text: "train" },
      { id: "c2-s2-l1-q6", type: "word", text: "school" },
      { id: "c2-s2-l1-q7", type: "word", text: "green" },
      { id: "c2-s2-l1-q8", type: "word", text: "black" },
      { id: "c2-s2-l1-q9", type: "word", text: "smile" },
    ],
  },

  {
    id: 2,
    title: "LEVEL 2 — MEDIUM",
    difficulty: "MEDIUM",
    description: "Read Class 2 sentences aloud.",
    exercises: [
      { id: "c2-s2-l2-q1", type: "sentence", text: "The boy has a blue bag." },
      { id: "c2-s2-l2-q2", type: "sentence", text: "The girl is eating an apple." },
      { id: "c2-s2-l2-q3", type: "sentence", text: "The cat sleeps on the chair." },
      { id: "c2-s2-l2-q4", type: "sentence", text: "The children walk to school." },
      { id: "c2-s2-l2-q5", type: "sentence", text: "My father drives a red car." },
      { id: "c2-s2-l2-q6", type: "sentence", text: "The bird builds a nest." },
      { id: "c2-s2-l2-q7", type: "sentence", text: "We read books every day." },
      { id: "c2-s2-l2-q8", type: "sentence", text: "The teacher writes a sentence." },
      { id: "c2-s2-l2-q9", type: "sentence", text: "The dog plays with a ball." },
    ],
  },

  {
    id: 3,
    title: "LEVEL 3 — HARD",
    difficulty: "HARD",
    description: "Read longer Class 2 sentences aloud.",
    exercises: [
      { id: "c2-s2-l3-q1", type: "sentence", text: "The bird is sitting in the tree." },
      { id: "c2-s2-l3-q2", type: "sentence", text: "My teacher reads a story." },
      { id: "c2-s2-l3-q3", type: "sentence", text: "The children are playing outside." },
      { id: "c2-s2-l3-q4", type: "sentence", text: "The little dog runs very fast." },
      { id: "c2-s2-l3-q5", type: "sentence", text: "I packed my books in my bag." },
      { id: "c2-s2-l3-q6", type: "sentence", text: "The yellow bus goes to school." },
      { id: "c2-s2-l3-q7", type: "sentence", text: "We planted flowers in the garden." },
      { id: "c2-s2-l3-q8", type: "sentence", text: "My friend likes to play football." },
      { id: "c2-s2-l3-q9", type: "sentence", text: "The rabbit is hiding behind the chair." },
    ],
  },
];

const CLASS3_STAGE2_BANK = [
  // ============================================================
  // LEVEL 1 — EASY
  // ============================================================

  {
    id: 1,
    title: "LEVEL 1 — EASY",
    difficulty: "EASY",
    description: "Read simple Class 3 words aloud carefully.",
    exercises: [
      { id: "c3-s2-l1-q1", type: "word", text: "BEAUTIFUL" },
      { id: "c3-s2-l1-q2", type: "word", text: "MORNING" },
      { id: "c3-s2-l1-q3", type: "word", text: "ANIMAL" },
      { id: "c3-s2-l1-q4", type: "word", text: "COUNTRY" },
      { id: "c3-s2-l1-q5", type: "word", text: "GARDEN" },
      { id: "c3-s2-l1-q6", type: "word", text: "HOLIDAY" },
      { id: "c3-s2-l1-q7", type: "word", text: "TEACHER" },
      { id: "c3-s2-l1-q8", type: "word", text: "SUNSHINE" },
      { id: "c3-s2-l1-q9", type: "word", text: "FRIENDSHIP" },
    ],
  },

  // ============================================================
  // LEVEL 2 — MEDIUM
  // ============================================================

  {
    id: 2,
    title: "LEVEL 2 — MEDIUM",
    difficulty: "MEDIUM",
    description: "Read short Class 3 sentences aloud carefully.",
    exercises: [
      { id: "c3-s2-l2-q1", type: "sentence", text: "THE CHILDREN PLAYED HAPPILY IN THE PARK." },
      { id: "c3-s2-l2-q2", type: "sentence", text: "MY MOTHER PLANTED FLOWERS IN THE GARDEN." },
      { id: "c3-s2-l2-q3", type: "sentence", text: "THE LITTLE BIRD BUILT A NEST IN THE TREE." },
      { id: "c3-s2-l2-q4", type: "sentence", text: "WE VISITED OUR GRANDPARENTS DURING THE HOLIDAYS." },
      { id: "c3-s2-l2-q5", type: "sentence", text: "THE BOY CARRIED HIS BOOKS TO SCHOOL." },
      { id: "c3-s2-l2-q6", type: "sentence", text: "MY FRIEND LOVES TO READ INTERESTING STORIES." },
      { id: "c3-s2-l2-q7", type: "sentence", text: "THE TEACHER EXPLAINED THE LESSON VERY CLEARLY." },
      { id: "c3-s2-l2-q8", type: "sentence", text: "THE SUN SHINES BRIGHTLY ON A SUNNY MORNING." },
      { id: "c3-s2-l2-q9", type: "sentence", text: "WE SHOULD ALWAYS HELP OUR FRIENDS AND FAMILY." },
    ],
  },

  // ============================================================
  // LEVEL 3 — HARD
  // ============================================================

  {
    id: 3,
    title: "LEVEL 3 — HARD",
    difficulty: "HARD",
    description: "Read longer Class 3 passages aloud carefully.",
    exercises: [
      {
        id: "c3-s2-l3-q1",
        type: "paragraph",
        text: "Rohan woke up early in the morning and looked outside his window. The sun was shining brightly, and the birds were singing in the trees.",
      },
      {
        id: "c3-s2-l3-q2",
        type: "paragraph",
        text: "Maya went to the garden with her mother. They planted small flowers and watered the plants before going back home.",
      },
      {
        id: "c3-s2-l3-q3",
        type: "paragraph",
        text: "The children visited the library after school. They chose some interesting books and sat quietly while reading their favourite stories.",
      },
      {
        id: "c3-s2-l3-q4",
        type: "paragraph",
        text: "A little bird built a nest on a tall tree near our house. It carried small sticks and dry leaves to make the nest comfortable.",
      },
      {
        id: "c3-s2-l3-q5",
        type: "paragraph",
        text: "Arjun found a lost puppy near the playground. He gave the puppy some water and asked his teacher to help find its owner.",
      },
      {
        id: "c3-s2-l3-q6",
        type: "paragraph",
        text: "During the holidays, Neha visited her grandparents in the village. She enjoyed walking through the fields and playing with her cousins.",
      },
      {
        id: "c3-s2-l3-q7",
        type: "paragraph",
        text: "The students worked together on a school project. They shared their ideas, collected pictures, and made a colourful chart for their classroom.",
      },
      {
        id: "c3-s2-l3-q8",
        type: "paragraph",
        text: "One evening, dark clouds covered the sky and rain began to fall. The children quickly came inside and watched the rain from the window.",
      },
      {
        id: "c3-s2-l3-q9",
        type: "paragraph",
        text: "Reading every day can help children learn new words and improve their language skills. It also helps them understand stories and express their ideas better.",
      },
    ],
  },
];

const CLASS4_STAGE2_BANK = [
  {
    id: 1,
    title: "LEVEL 1 — EASY",
    difficulty: "EASY",
    description: "Read simple Class 4 words aloud.",
    exercises: [
      { id: "c4-s2-l1-q1", type: "word", text: "JOURNEY" },
      { id: "c4-s2-l1-q2", type: "word", text: "MARKET" },
      { id: "c4-s2-l1-q3", type: "word", text: "FOREST" },
      { id: "c4-s2-l1-q4", type: "word", text: "BRIDGE" },
      { id: "c4-s2-l1-q5", type: "word", text: "COUNTRY" },
      { id: "c4-s2-l1-q6", type: "word", text: "PICTURE" },
      { id: "c4-s2-l1-q7", type: "word", text: "MORNING" },
      { id: "c4-s2-l1-q8", type: "word", text: "FRIENDSHIP" },
      { id: "c4-s2-l1-q9", type: "word", text: "ANIMAL" },
      { id: "c4-s2-l1-q10", type: "word", text: "WEATHER" },
    ],
  },

  {
    id: 2,
    title: "LEVEL 2 — MEDIUM",
    difficulty: "MEDIUM",
    description: "Read short Class 4 sentences aloud.",
    exercises: [
      {
        id: "c4-s2-l2-q1",
        type: "sentence",
        text: "THE CHILDREN WALKED TO SCHOOL TOGETHER.",
      },
      {
        id: "c4-s2-l2-q2",
        type: "sentence",
        text: "MY BROTHER ENJOYS READING ADVENTURE BOOKS.",
      },
      {
        id: "c4-s2-l2-q3",
        type: "sentence",
        text: "THE FARMER GROWS VEGETABLES IN HIS FIELD.",
      },
      {
        id: "c4-s2-l2-q4",
        type: "sentence",
        text: "WE VISITED THE MUSEUM DURING OUR HOLIDAY.",
      },
      {
        id: "c4-s2-l2-q5",
        type: "sentence",
        text: "THE LITTLE BIRD BUILT A NEST NEAR THE WINDOW.",
      },
      {
        id: "c4-s2-l2-q6",
        type: "sentence",
        text: "ROHAN HELPED HIS MOTHER CLEAN THE GARDEN.",
      },
      {
        id: "c4-s2-l2-q7",
        type: "sentence",
        text: "THE STUDENTS LISTENED CAREFULLY TO THEIR TEACHER.",
      },
      {
        id: "c4-s2-l2-q8",
        type: "sentence",
        text: "OUR FAMILY WENT TO THE MARKET ON SUNDAY.",
      },
      {
        id: "c4-s2-l2-q9",
        type: "sentence",
        text: "THE RAIN STOPPED BEFORE THE CHILDREN WENT OUTSIDE.",
      },
      {
        id: "c4-s2-l2-q10",
        type: "sentence",
        text: "I FOUND AN INTERESTING STORY IN THE LIBRARY.",
      },
    ],
  },

  {
    id: 3,
    title: "LEVEL 3 — HARD",
    difficulty: "HARD",
    description: "Read longer Class 4 passages aloud carefully.",
    exercises: [
      {
        id: "c4-s2-l3-q1",
        type: "paragraph",
        text: "Riya woke up early one morning and looked outside her window. The sky was bright, and the birds were singing in the trees.",
      },
      {
        id: "c4-s2-l3-q2",
        type: "paragraph",
        text: "A group of children visited the village farm with their teacher. They learned how farmers grow vegetables and take care of animals.",
      },
      {
        id: "c4-s2-l3-q3",
        type: "paragraph",
        text: "Arjun found an old book in his school library. He opened it carefully and discovered many interesting stories about explorers and distant countries.",
      },
      {
        id: "c4-s2-l3-q4",
        type: "paragraph",
        text: "During the summer holidays, Meena travelled to her grandmother's village. She enjoyed playing in the garden and helping her grandmother prepare delicious food.",
      },
      {
        id: "c4-s2-l3-q5",
        type: "paragraph",
        text: "The students planted small trees near their school playground. They promised to water the plants regularly and keep the area clean.",
      },
      {
        id: "c4-s2-l3-q6",
        type: "paragraph",
        text: "One afternoon, dark clouds covered the sky and strong winds began to blow. The children quickly returned home before the heavy rain started.",
      },
      {
        id: "c4-s2-l3-q7",
        type: "paragraph",
        text: "Rahul wanted to learn how to ride a bicycle. His father helped him practise every evening until he could ride confidently without any help.",
      },
      {
        id: "c4-s2-l3-q8",
        type: "paragraph",
        text: "The school organised a reading competition for all the students. Everyone practised their passages carefully and tried to read clearly and confidently.",
      },
      {
        id: "c4-s2-l3-q9",
        type: "paragraph",
        text: "A young girl noticed that a puppy was lost near the park. She gave it some water and asked nearby people if they knew where it belonged.",
      },
      {
        id: "c4-s2-l3-q10",
        type: "paragraph",
        text: "Reading every day can help children improve their vocabulary and speaking skills. It also helps them understand new ideas and become more confident readers.",
      },
    ],
  },
];

const CLASS5_STAGE2_BANK = [
  {
    id: 1,
    title: "LEVEL 1 — EASY",
    difficulty: "EASY",
    description: "Read simple Class 5 sentences aloud.",
    exercises: [
      { id: "c5-s2-l1-q1", type: "sentence", text: "The students finished their work." },
      { id: "c5-s2-l1-q2", type: "sentence", text: "The teacher explained the lesson." },
      { id: "c5-s2-l1-q3", type: "sentence", text: "The children played together." },
      { id: "c5-s2-l1-q4", type: "sentence", text: "My friend likes reading books." },
      { id: "c5-s2-l1-q5", type: "sentence", text: "The students practice every day." },
      { id: "c5-s2-l1-q6", type: "sentence", text: "The girl opened her notebook." },
      { id: "c5-s2-l1-q7", type: "sentence", text: "The boy checked his answer." },
      { id: "c5-s2-l1-q8", type: "sentence", text: "The class listened to the teacher." },
      { id: "c5-s2-l1-q9", type: "sentence", text: "The students went back to their classroom." },
    ],
  },

  {
    id: 2,
    title: "LEVEL 2 — MEDIUM",
    difficulty: "MEDIUM",
    description: "Read Class 5 sentences carefully.",
    exercises: [
      { id: "c5-s2-l2-q1", type: "sentence", text: "Good readers think about the meaning of words." },
      { id: "c5-s2-l2-q2", type: "sentence", text: "Careful reading helps students notice spelling mistakes." },
      { id: "c5-s2-l2-q3", type: "sentence", text: "Students improve when they practise every day." },
      { id: "c5-s2-l2-q4", type: "sentence", text: "Reading a paragraph helps us learn new ideas." },
      { id: "c5-s2-l2-q5", type: "sentence", text: "Reading a sentence again can make it easier to understand." },
      { id: "c5-s2-l2-q6", type: "sentence", text: "Good learners listen carefully to instructions." },
      { id: "c5-s2-l2-q7", type: "sentence", text: "Checking your answer can help you find mistakes." },
      { id: "c5-s2-l2-q8", type: "sentence", text: "Reading aloud helps students read difficult words clearly." },
      { id: "c5-s2-l2-q9", type: "sentence", text: "Regular practice makes students more confident." },
    ],
  },

  {
    id: 3,
    title: "LEVEL 3 — HARD",
    difficulty: "HARD",
    description: "Read longer Class 5 sentences carefully.",
    exercises: [
      { id: "c5-s2-l3-q1", type: "sentence", text: "The students compared two sentences before choosing the correct answer." },
      { id: "c5-s2-l3-q2", type: "sentence", text: "The science project needed careful observation and good notes." },
      { id: "c5-s2-l3-q3", type: "sentence", text: "The teacher asked the students to read the paragraph again." },
      { id: "c5-s2-l3-q4", type: "sentence", text: "The students looked carefully at the differences between two sentences." },
      { id: "c5-s2-l3-q5", type: "sentence", text: "The girl checked her spelling before submitting her assignment." },
      { id: "c5-s2-l3-q6", type: "sentence", text: "The class worked together to find the important information." },
      { id: "c5-s2-l3-q7", type: "sentence", text: "The student concentrated because some answers looked very similar." },
      { id: "c5-s2-l3-q8", type: "sentence", text: "Small changes in words can sometimes change the meaning of a sentence." },
      { id: "c5-s2-l3-q9", type: "sentence", text: "The students checked their work and corrected their mistakes." },
    ],
  },
];

/* =========================================================
   SHUFFLE STAGE 2
   A fresh question order is created whenever Stage 2 starts.
   ========================================================= */

const getNormalizedClassNumber = (rawClass) => {
  if (typeof rawClass === "number" && rawClass >= 1 && rawClass <= 5) return rawClass;
  const match = String(rawClass || "").match(/[1-5]/);
  return match ? Number(match[0]) : 1;
};

const createShuffledStage2 = (classNumber = 1) => {
  const classKey = String(getNormalizedClassNumber(classNumber));

  const sourceLevels =
    classKey === "1"
      ? CLASS1_STAGE2_BANK
      : classKey === "2"
        ? CLASS2_STAGE2_BANK
        : classKey === "3"
          ? CLASS3_STAGE2_BANK
          : classKey === "4"
            ? CLASS4_STAGE2_BANK
            : CLASS5_STAGE2_BANK;

  return sourceLevels.map((level) => ({
    ...level,
    exercises: [...level.exercises],
  }));
};

/* =========================================================
   NORMALISE SPEECH FOR COMPARISON
   ========================================================= */

const normaliseSpeech = (text) => {
  return text
    .toLowerCase()
    .replace(/[.,!?;:'"]/g, "")
    .replace(/\s+/g, " ")
    .trim();
};

/* =========================================================
   READING MATCH SCORE
   ========================================================= */

const calculateReadingAccuracy = (
  expected,
  spoken
) => {
  const expectedWords =
    normaliseSpeech(expected)
      .split(" ")
      .filter(Boolean);

  const spokenWords =
    normaliseSpeech(spoken)
      .split(" ")
      .filter(Boolean);

  if (!expectedWords.length) {
    return 0;
  }

  let matches = 0;

  expectedWords.forEach(
    (word, index) => {
      if (
        spokenWords[index] === word
      ) {
        matches++;
      }
    }
  );

  return Math.round(
    (matches /
      expectedWords.length) *
    100
  );
};
const ALLOWED_CLASSES = ["1", "2", "3", "4", "5"];

const CLASS_INFO = {
  1: {
    name: "CLASS 1",
    difficulty: "FOUNDATION",
  },
  2: {
    name: "CLASS 2",
    difficulty: "BASIC",
  },
  3: {
    name: "CLASS 3",
    difficulty: "INTERMEDIATE",
  },
  4: {
    name: "CLASS 4",
    difficulty: "ADVANCED",
  },
  5: {
    name: "CLASS 5",
    difficulty: "HIGHER",
  },
};
/* =========================================================
   CLASS-WISE LEARNING QUESTION BANK
   CLASS 1 TO CLASS 5
   3 STAGES × 3 LEVELS × 10 QUESTIONS
   ========================================================= */


/* =========================================================
   CLASS-WISE STAGE 1 QUESTION BANK
   5 CLASSES × 3 LEVELS × 9 QUESTIONS = 135 QUESTIONS

   IMPORTANT:
   - STAGE 1 IS VISUAL ONLY.
   - NO QUESTION AUDIO / READ-ALOUD IS USED IN STAGE 1.
   - Difficulty increases from Level 1 → Level 3.
   ========================================================= */
const makeVisualLevel = (
  levelId,
  title,
  difficulty,
  items,
  questionText,
  description
) => {
  return {
    id: levelId,
    level: levelId,
    title,
    difficulty,
    description,
    exercises: items.map((item, index) => ({
      id: `l${levelId}q${index + 1}`,
      type: "visual",
      question: item.question || questionText,
      visual: item.visual,
      options: shuffleArray(item.options || []),
      answer: item.answer,
    })),
  };
};
const CLASS_STAGE1_BANK = {
  1: [
    makeVisualLevel(
      1, "LEVEL 1", "EASY",
      [
        { visual: "A", options: ["B", "A", "C", "D"], answer: "A" },
        { visual: "B", options: ["D", "P", "B", "R"], answer: "B" },
        { visual: "C", options: ["O", "G", "D", "C"], answer: "C" },
        { visual: "D", options: ["D", "B", "P", "Q"], answer: "D" },
        { visual: "E", options: ["F", "L", "E", "I"], answer: "E" },
        { visual: "F", options: ["E", "T", "P", "F"], answer: "F" },
        { visual: "G", options: ["G", "C", "Q", "O"], answer: "G" },
        { visual: "H", options: ["N", "H", "K", "M"], answer: "H" },
        { visual: "I", options: ["L", "T", "J", "I"], answer: "I" },
      ],
      "WHICH CAPITAL LETTER IS EXACTLY THE SAME?",
      "MATCH SIMPLE CAPITAL LETTERS."
    ),
    makeVisualLevel(
      2, "LEVEL 2", "MEDIUM",
      [
        { visual: "a", options: ["a", "e", "o", "d"], answer: "a" },
        { visual: "b", options: ["d", "b", "p", "q"], answer: "b" },
        { visual: "c", options: ["e", "o", "c", "a"], answer: "c" },
        { visual: "d", options: ["d", "b", "p", "q"], answer: "d" },
        { visual: "m", options: ["n", "m", "w", "u"], answer: "m" },
        { visual: "n", options: ["m", "u", "n", "h"], answer: "n" },
        { visual: "p", options: ["q", "b", "d", "p"], answer: "p" },
        { visual: "u", options: ["n", "u", "v", "w"], answer: "u" },
        { visual: "w", options: ["m", "n", "w", "u"], answer: "w" },
      ],
      "WHICH SMALL LETTER IS EXACTLY THE SAME?",
      "MATCH SMALL LETTERS AND WATCH THEIR SHAPES."
    ),
    makeVisualLevel(
      3, "LEVEL 3", "HARD",
      [
        { visual: "A a", options: ["A e", "B a", "a A", "A a"], answer: "A a" },
        { visual: "B b", options: ["B b", "B d", "D b", "b B"], answer: "B b" },
        { visual: "C c", options: ["C e", "c C", "C c", "G c"], answer: "C c" },
        { visual: "D d", options: ["B d", "D p", "d D", "D d"], answer: "D d" },
        { visual: "M m", options: ["M m", "M n", "N m", "m M"], answer: "M m" },
        { visual: "N n", options: ["M n", "N n", "N u", "n N"], answer: "N n" },
        { visual: "P p", options: ["P q", "B p", "p P", "P p"], answer: "P p" },
        { visual: "U u", options: ["U u", "U v", "V u", "u U"], answer: "U u" },
        { visual: "W w", options: ["W m", "W w", "M w", "w W"], answer: "W w" },
      ],
      "WHICH OPTION HAS THE EXACT SAME CAPITAL-SMALL PAIR?",
      "COMPARE BOTH LETTERS IN THE PAIR."
    ),
  ],

  2: [
    makeVisualLevel(
      1, "LEVEL 1", "EASY",
      [
        { question: "WHICH WORD STARTS WITH SH?", options: ["CAT", "DOG", "SHIP", "SUN"], answer: "SHIP" },
        { question: "WHICH WORD STARTS WITH CH?", options: ["CHAIR", "MAP", "SUN", "DOG"], answer: "CHAIR" },
        { question: "WHICH WORD RHYMES WITH CAKE?", options: ["DOG", "LAKE", "FISH", "SUN"], answer: "LAKE" },
        { question: "COMPLETE: B_ _ ACK", options: ["R", "T", "L", "M"], answer: "L" },
        { question: "COMPLETE: ST_ R", options: ["O", "E", "I", "A"], answer: "A" },
        { question: "WHICH WORD HAS THE LONG A SOUND?", options: ["CAT", "CAKE", "MAP", "DOG"], answer: "CAKE" },
        { question: "ARRANGE C, A, T TO MAKE A WORD.", options: ["ACT", "TAC", "CAT", "CTA"], answer: "CAT" },
        { question: "WHICH WORD STARTS WITH TR?", options: ["RAIN", "CHAIN", "BRAIN", "TRAIN"], answer: "TRAIN" },
        { question: "WHICH WORD ENDS WITH CK?", options: ["BACK", "BAG", "BAT", "BAN"], answer: "BACK" },
      ],
      "CHOOSE THE BEST MATCH.",
      "RECOGNISE COMMON PHONIC PATTERNS VISUALLY."
    ),
    makeVisualLevel(
      2, "LEVEL 2", "MEDIUM",
      [
        { question: "WHICH WORD STARTS WITH BL?", options: ["BACK", "BLOCK", "BLACK", "BLESS"], answer: "BLACK" },
        { question: "WHICH WORD STARTS WITH ST?", options: ["CAR", "SHARK", "SCAR", "STAR"], answer: "STAR" },
        { question: "WHICH WORD RHYMES WITH LIGHT?", options: ["NIGHT", "LATE", "LIFT", "LEAF"], answer: "NIGHT" },
        { question: "COMPLETE: _RAIN", options: ["C", "B", "D", "P"], answer: "B" },
        { question: "COMPLETE: S_ OOL", options: ["SH", "TH", "PH", "CH"], answer: "CH" },
        { question: "WHICH WORD HAS THE LONG E SOUND?", options: ["TREE", "BED", "PEN", "RED"], answer: "TREE" },
        { question: "WHICH WORD IS SPELLED CORRECTLY?", options: ["FREIND", "FRIEND", "FREEND", "FRINED"], answer: "FRIEND" },
        { question: "WHICH WORD HAS THE SAME ENDING AS PLAY?", options: ["PLAN", "STOP", "STAY", "PLUM"], answer: "STAY" },
        { question: "WHICH WORD BEGINS AND ENDS WITH THE SAME SOUND PATTERN?", options: ["MOM", "MAP", "MEN", "MAT"], answer: "MOM" },
      ],
      "CHOOSE THE BEST WORD.",
      "USE COMMON BLENDS, RHYMES AND SPELLING PATTERNS."
    ),
    makeVisualLevel(
      3, "LEVEL 3", "HARD",
      [
        { question: "WHICH WORD HAS THE SAME VOWEL PATTERN AS TRAIN?", options: ["TRIP", "BRAIN", "TREE", "TRUCK"], answer: "BRAIN" },
        { question: "WHICH WORD HAS THE SAME BEGINNING BLEND AS SPLASH?", options: ["SPRING", "SHAPE", "SPLIT", "SPACE"], answer: "SPLIT" },
        { question: "WHICH WORD RHYMES WITH BRIGHT?", options: ["BRING", "BREAK", "BREAD", "FLIGHT"], answer: "FLIGHT" },
        { question: "COMPLETE: _IGHT", options: ["R", "L", "M", "T"], answer: "L" },
        { question: "COMPLETE: S_ OOL", options: ["TH", "PH", "CH", "SH"], answer: "CH" },
        { question: "WHICH WORD HAS A SILENT E?", options: ["PLAN", "PLANT", "PLAIN", "PLANE"], answer: "PLANE" },
        { question: "WHICH WORD IS DIFFERENT FROM THE OTHER THREE?", options: ["TRIP", "TRAIN", "BRAIN", "CHAIN"], answer: "TRIP" },
        { question: "WHICH WORD HAS THE SAME NUMBER OF SYLLABLES AS WINDOW?", options: ["DOG", "SCHOOL", "PENCIL", "TREE"], answer: "PENCIL" },
        { question: "WHICH WORD IS IN THE CORRECT ALPHABETICAL ORDER AFTER GARDEN?", options: ["GAME", "FISH", "APPLE", "GIRL"], answer: "GIRL" },
      ],
      "FIND THE PATTERN.",
      "COMPARE SOUNDS, SPELLING PATTERNS AND WORD STRUCTURE."
    ),
  ],

  3: [
    makeVisualLevel(
      1, "LEVEL 1", "EASY",
      [
        { visual: "BRIGHT", options: ["BRIGHT", "RIGHT", "BRING", "BIRTH"], answer: "BRIGHT" },
        { visual: "FRIEND", options: ["FIEND", "FRIEND", "FREIND", "FREND"], answer: "FRIEND" },
        { visual: "SCHOOL", options: ["SCOOL", "SHCOOL", "SCHOLL", "SCHOOL"], answer: "SCHOOL" },
        { visual: "PLANET", options: ["PLANT", "PLANETT", "PLANNET", "PLANET"], answer: "PLANET" },
        { visual: "MARKET", options: ["MARket", "MARKET", "MACKET", "MARKIT"], answer: "MARKET" },
        { visual: "WINDOW", options: ["WINDO", "WINODW", "WINDOW", "WINDWO"], answer: "WINDOW" },
        { visual: "PENCIL", options: ["PENCIL", "PENCLE", "PENCILL", "PENICL"], answer: "PENCIL" },
        { visual: "FLOWER", options: ["FLOER", "FLOWER", "FLAWER", "FLOOWER"], answer: "FLOWER" },
        { visual: "BASKET", options: ["BASket", "BASKIT", "BASKET", "BAKS ET"], answer: "BASKET" },
      ],
      "WHICH WORD IS SPELLED EXACTLY THE SAME?",
      "COMPARE LONGER WORDS CAREFULLY."
    ),
    makeVisualLevel(
      2, "LEVEL 2", "MEDIUM",
      [
        { visual: "ELEPHANT", options: ["ELEFANT", "ELEPHENT", "ELEPHNAT", "ELEPHANT"], answer: "ELEPHANT" },
        { visual: "IMPORTANT", options: ["IMPORTENT", "IMPORTANT", "IMORTANT", "IMPORTNAT"], answer: "IMPORTANT" },
        { visual: "LANGUAGE", options: ["LANGAUGE", "LANGUGE", "LANGUAGE", "LANGUIGE"], answer: "LANGUAGE" },
        { visual: "NOTEBOOK", options: ["NOTBOOK", "NOTEBOOOK", "NOTEEBOOK", "NOTEBOOK"], answer: "NOTEBOOK" },
        { visual: "BUILDING", options: ["BUILDING", "BUIDLING", "BUILIDNG", "BUILDIN"], answer: "BUILDING" },
        { visual: "MORNING", options: ["MORNIGN", "MORNINGG", "MORNIN", "MORNING"], answer: "MORNING" },
        { visual: "RAINBOW", options: ["RAINBOWW", "RANIBOW", "RAINBO", "RAINBOW"], answer: "RAINBOW" },
        { visual: "HOLIDAY", options: ["HOLIDAY", "HOLYDAY", "HOLIDY", "HOLIDA"], answer: "HOLIDAY" },
        { visual: "PICTURE", options: ["PICTUER", "PICTURE", "PICUTRE", "PICTUR"], answer: "PICTURE" },
      ],
      "WHICH LONGER WORD MATCHES EXACTLY?",
      "CHECK LETTER ORDER, NOT JUST THE FIRST LETTER."
    ),
    makeVisualLevel(
      3, "LEVEL 3", "HARD",
      [
        { visual: "THE SMALL BIRD FLEW.", options: ["THE SMALL BIRD FLOW.", "THE SMALL BIRD FELL.", "THE SMALL BIRD FLY.", "THE SMALL BIRD FLEW."], answer: "THE SMALL BIRD FLEW." },
        { visual: "MAYA CARRIED HER BLUE BAG.", options: ["MAYA CARRIED HER BLUE BAG.", "MAYA CARRIES HER BLUE BAG.", "MAYA CARRIED HER BLUE BIG.", "MAYA CARRIED HIS BLUE BAG."], answer: "MAYA CARRIED HER BLUE BAG." },
        { visual: "THE CHILDREN PLAYED AFTER LUNCH.", options: ["THE CHILDREN PLAY AFTER LUNCH.", "THE CHILDREN PLAYED AFTER LUNCH.", "THE CHILDREN PLAYED BEFORE LUNCH.", "THE CHILDREN PLAYED AFTER LUNCH"], answer: "THE CHILDREN PLAYED AFTER LUNCH." },
        { visual: "MY FRIEND FOUND A PENCIL.", options: ["MY FRIEND FIND A PENCIL.", "MY FRIEND FOUND A PEN.", "MY FRIEND FOUND A PENCIL.", "MY FRIEND FOUND THE PENCIL."], answer: "MY FRIEND FOUND A PENCIL." },
        { visual: "THE DOG RAN QUICKLY.", options: ["THE DOG RAN QUICKLY.", "THE DOG RUN QUICKLY.", "THE DOG RAN QUIETLY.", "THE DOG RAN QUICK."], answer: "THE DOG RAN QUICKLY." },
        { visual: "WE READ A FUNNY STORY.", options: ["WE READ A FUN STORY.", "WE READ A FUNNY STORY.", "WE RED A FUNNY STORY.", "WE READ A SUNNY STORY."], answer: "WE READ A FUNNY STORY." },
        { visual: "SHE PUT THE RED BOOK BESIDE THE WINDOW.", options: ["SHE PUT THE RED BOOK INSIDE THE WINDOW.", "SHE PUT THE RED BOOK BESIDE A WINDOW.", "SHE PUT THE RED BOOK BESIDE THE WINDOW.", "SHE PUT THE RED BAG BESIDE THE WINDOW."], answer: "SHE PUT THE RED BOOK BESIDE THE WINDOW." },
        { visual: "THE TEACHER WROTE A NEW SENTENCE.", options: ["THE TEACHER WRITE A NEW SENTENCE.", "THE TEACHER WROTE A NEW SENTENCES.", "THE TEACHER READ A NEW SENTENCE.", "THE TEACHER WROTE A NEW SENTENCE."], answer: "THE TEACHER WROTE A NEW SENTENCE." },
        { visual: "THE YOUNG BOY OPENED THE OLD BOX.", options: ["THE YOUNG BOY OPEN THE OLD BOX.", "THE YOUNG BOY OPENED THE OLD BOX.", "THE YOUNG GIRL OPENED THE OLD BOX.", "THE YOUNG BOY OPENED THE NEW BOX."], answer: "THE YOUNG BOY OPENED THE OLD BOX." },
      ],
      "WHICH SENTENCE IS EXACTLY THE SAME?",
      "COMPARE EVERY WORD, INCLUDING SMALL DIFFERENCES."
    ),
  ],

  4: [
    makeVisualLevel(
      1, "LEVEL 1", "EASY",
      [
        { visual: "bd", options: ["db", "pq", "bd", "qp"], answer: "bd" },
        { visual: "db", options: ["bd", "pq", "qp", "db"], answer: "db" },
        { visual: "pq", options: ["pq", "qp", "bd", "db"], answer: "pq" },
        { visual: "qp", options: ["pq", "bd", "qp", "db"], answer: "qp" },
        { visual: "rn", options: ["rm", "nn", "mn", "rn"], answer: "rn" },
        { visual: "ur", options: ["ur", "ru", "un", "nu"], answer: "ur" },
        { visual: "mn", options: ["nm", "mn", "rn", "mr"], answer: "mn" },
        { visual: "cl", options: ["lc", "ci", "il", "cl"], answer: "cl" },
        { visual: "il", options: ["il", "li", "ll", "ii"], answer: "il" },
      ],
      "WHICH LETTER PAIR IS EXACTLY THE SAME?",
      "DISCRIMINATE BETWEEN SIMILAR LETTER PAIRS."
    ),
    makeVisualLevel(
      2, "LEVEL 2", "MEDIUM",
      [
        { visual: "ELEPHANT", options: ["ELEFANT", "ELEPHANT", "ELEPHENT", "ELEPHNAT"], answer: "ELEPHANT" },
        { visual: "IMPORTANT", options: ["IMPORTENT", "IMORTANT", "IMPORTANT", "IMPORTNAT"], answer: "IMPORTANT" },
        { visual: "DIFFERENT", options: ["DIFFERENT", "DIFFRENT", "DIFFIRENT", "DIFFERANT"], answer: "DIFFERENT" },
        { visual: "UNDERSTAND", options: ["UNDERSTNAD", "UNDERSTAND", "UNDERTSAND", "UNDERSTEND"], answer: "UNDERSTAND" },
        { visual: "EDUCATION", options: ["EDUCATOIN", "EDUCATON", "EDUCATION", "EDUCAITON"], answer: "EDUCATION" },
        { visual: "REMEMBERING", options: ["REMEMBRING", "REMEBERING", "REMEMBERNIG", "REMEMBERING"], answer: "REMEMBERING" },
        { visual: "BEAUTIFUL", options: ["BEATIFUL", "BEAUTIFUL", "BEAUTIFULL", "BEUTIFUL"], answer: "BEAUTIFUL" },
        { visual: "COMMUNITY", options: ["COMUNITY", "COMMUNITTY", "COMMUNITY", "COMMUNTIY"], answer: "COMMUNITY" },
        { visual: "KNOWLEDGE", options: ["KNOWLDEGE", "KNOWLEDGE", "KNOWLEDG", "KNWOLEDGE"], answer: "KNOWLEDGE" },
      ],
      "WHICH WORD HAS THE EXACT LETTER ORDER?",
      "TRACK INTERNAL LETTER ORDER IN LONG WORDS."
    ),
    makeVisualLevel(
      3, "LEVEL 3", "HARD",
      [
        { visual: "THE CHILDREN PLAYED QUIETLY IN THE SCHOOL LIBRARY.", options: ["THE CHILDREN PLAYED QUIETLY IN THE SCHOOL LIBRARY.", "THE CHILDREN PLAYED QUIETLY AT THE SCHOOL LIBRARY.", "THE CHILDREN PLAY QUIETLY IN THE SCHOOL LIBRARY.", "THE CHILDREN PLAYED QUIETLY IN THE SCHOOL LIBRARY"], answer: "THE CHILDREN PLAYED QUIETLY IN THE SCHOOL LIBRARY." },
        { visual: "RAVI CAREFULLY PACKED HIS BOOKS BEFORE LEAVING HOME.", options: ["RAVI CAREFULLY PACKED HIS BOOK BEFORE LEAVING HOME.", "RAVI CAREFULLY PACKED HIS BOOKS AFTER LEAVING HOME.", "RAVI CAREFULLY PACKED HIS BOOKS BEFORE LEAVING HOME.", "RAVI CAREFULLY PACK HIS BOOKS BEFORE LEAVING HOME."], answer: "RAVI CAREFULLY PACKED HIS BOOKS BEFORE LEAVING HOME." },
        { visual: "THE BRIGHT YELLOW BUTTERFLY LANDED ON A FLOWER.", options: ["THE BRIGHT YELLOW BUTTERFLY LANDED IN A FLOWER.", "THE BRIGHT YELLOW BUTTERFLY LANDed ON A FLOWER.", "THE BRIGHT YELLOW BUTTERFLY LANDED ON THE FLOWER.", "THE BRIGHT YELLOW BUTTERFLY LANDED ON A FLOWER."], answer: "THE BRIGHT YELLOW BUTTERFLY LANDED ON A FLOWER." },
        { visual: "OUR TEACHER EXPLAINED THE NEW ACTIVITY VERY CLEARLY.", options: ["OUR TEACHER EXPLAINED THE NEW ACTIVITY VERY CLEARLY.", "OUR TEACHER EXPLAINED THE OLD ACTIVITY VERY CLEARLY.", "OUR TEACHER EXPLAINED THE NEW ACTIVITY VERY CLEAR.", "OUR TEACHER EXPLAINED THE NEW ACTIVITY VERY CAREFULLY."], answer: "OUR TEACHER EXPLAINED THE NEW ACTIVITY VERY CLEARLY." },
        { visual: "THE LITTLE GIRL FOUND A SILVER COIN UNDER THE CHAIR.", options: ["THE LITTLE GIRL FOUND A SILVER COIN BESIDE THE CHAIR.", "THE LITTLE GIRL FOUND A SILVER COIN UNDER THE CHAIR.", "THE LITTLE BOY FOUND A SILVER COIN UNDER THE CHAIR.", "THE LITTLE GIRL FOUND A GOLD COIN UNDER THE CHAIR."], answer: "THE LITTLE GIRL FOUND A SILVER COIN UNDER THE CHAIR." },
        { visual: "WE VISITED THE CITY MUSEUM DURING OUR SCHOOL TRIP.", options: ["WE VISITED THE CITY LIBRARY DURING OUR SCHOOL TRIP.", "WE VISITED THE CITY MUSEUM BEFORE OUR SCHOOL TRIP.", "WE VISITED THE CITY MUSEUM DURING OUR SCHOOL DAY.", "WE VISITED THE CITY MUSEUM DURING OUR SCHOOL TRIP."], answer: "WE VISITED THE CITY MUSEUM DURING OUR SCHOOL TRIP." },
        { visual: "THE BOY FINISHED HIS HOMEWORK BEFORE PLAYING OUTSIDE.", options: ["THE BOY FINISHED HIS HOMEWORK BEFORE PLAYING OUTSIDE.", "THE BOY FINISHED HIS HOMEWORK AFTER PLAYING OUTSIDE.", "THE GIRL FINISHED HIS HOMEWORK BEFORE PLAYING OUTSIDE.", "THE BOY FINISHED HIS HOMEWORK BEFORE PLAYING INSIDE."], answer: "THE BOY FINISHED HIS HOMEWORK BEFORE PLAYING OUTSIDE." },
        { visual: "MOTHER PLACED THE FRESH FRUIT ON THE KITCHEN TABLE.", options: ["MOTHER PLACED THE FRESH FOOD ON THE KITCHEN TABLE.", "MOTHER PLACED THE FRESH FRUIT ON THE KITCHEN TABLE.", "MOTHER PLACED THE FRESH FRUIT UNDER THE KITCHEN TABLE.", "MOTHER PLACED THE FRESH FRUIT ON THE DINING TABLE."], answer: "MOTHER PLACED THE FRESH FRUIT ON THE KITCHEN TABLE." },
        { visual: "THE FRIENDLY DOG WAITED PATIENTLY BESIDE THE FRONT DOOR.", options: ["THE FRIENDLY DOG WAITED PATIENTLY BEHIND THE FRONT DOOR.", "THE FRIENDLY CAT WAITED PATIENTLY BESIDE THE FRONT DOOR.", "THE FRIENDLY DOG WAITED PATIENTLY BESIDE THE FRONT DOOR.", "THE FRIENDLY DOG WAITED QUICKLY BESIDE THE FRONT DOOR."], answer: "THE FRIENDLY DOG WAITED PATIENTLY BESIDE THE FRONT DOOR." },
      ],
      "WHICH SENTENCE MATCHES EXACTLY?",
      "COMPARE WORDS, POSITION AND PUNCTUATION."
    ),
  ],

  5: [
    makeVisualLevel(
      1, "LEVEL 1", "EASY",
      [
        { visual: "b d", options: ["bd", "db", "pq", "qp"], answer: "bd" },
        { visual: "d b", options: ["bd", "db", "pq", "qp"], answer: "db" },
        { visual: "p q", options: ["qp", "bd", "pq", "db"], answer: "pq" },
        { visual: "q p", options: ["pq", "bd", "db", "qp"], answer: "qp" },
        { visual: "m n", options: ["nm", "mn", "wn", "mw"], answer: "mn" },
        { visual: "n m", options: ["mn", "wn", "nm", "mw"], answer: "nm" },
        { visual: "rn m", options: ["rmm", "nrm", "mnr", "rnm"], answer: "rnm" },
        { visual: "cl d", options: ["cld", "cdl", "dcl", "ldc"], answer: "cld" },
        { visual: "u n", options: ["nu", "um", "un", "nm"], answer: "un" },
      ],
      "WHICH LETTER SEQUENCE MATCHES EXACTLY?",
      "COMPARE ORDER AND ORIENTATION OF SIMILAR LETTERS."
    ),
    makeVisualLevel(
      2, "LEVEL 2", "MEDIUM",
      [
        { visual: "ADVENTURE", options: ["ADVENTUER", "ADVENTUR", "ADVENUTRE", "ADVENTURE"], answer: "ADVENTURE" },
        { visual: "KNOWLEDGE", options: ["KNOLWEDGE", "KNOWLDEGE", "KNOWLEDG", "KNOWLEDGE"], answer: "KNOWLEDGE" },
        { visual: "DIFFERENT", options: ["DIFFRENT", "DIFFERENT", "DIFFIRENT", "DIFFERANT"], answer: "DIFFERENT" },
        { visual: "IMPORTANT", options: ["IMPORTENT", "IMORTANT", "IMPORTNAT", "IMPORTANT"], answer: "IMPORTANT" },
        { visual: "UNDERSTAND", options: ["UNDERSTAND", "UNDERSTNAD", "UNDERTSAND", "UNDERSTEND"], answer: "UNDERSTAND" },
        { visual: "EDUCATION", options: ["EDUCATOIN", "EDUCATION", "EDUCATON", "EDUCAITON"], answer: "EDUCATION" },
        { visual: "REMEMBERING", options: ["REMEMBRING", "REMEBERING", "REMEMBERING", "REMEMBERNIG"], answer: "REMEMBERING" },
        { visual: "BEAUTIFUL", options: ["BEAUTIFUL", "BEATIFUL", "BEAUTIFULL", "BEUTIFUL"], answer: "BEAUTIFUL" },
        { visual: "COMMUNITY", options: ["COMUNITY", "COMMUNITY", "COMMUNITTY", "COMMUNTIY"], answer: "COMMUNITY" },
      ],
      "WHICH WORD IS EXACTLY CORRECT?",
      "HANDLE LONG WORDS WITH SIMILAR LETTER SEQUENCES."
    ),
    makeVisualLevel(
      3, "LEVEL 3", "HARD",
      [
        { visual: "THE STUDENT CAREFULLY CHECKED EVERY WORD BEFORE CHOOSING AN ANSWER.", options: ["THE STUDENT CAREFULLY CHECKED EVERY WORD AFTER CHOOSING AN ANSWER.", "THE STUDENT CAREFULLY CHECKED EVERY WORD BEFORE CHOOSING THE ANSWER.", "THE STUDENT CAREFULLY CHECKED EVERY WORD BEFORE CHOOSING AN ANSWER.", "THE STUDENT CAREFULLY CHECKED EVERY WORD BEFORE CHOOSING AN ANSWER"], answer: "THE STUDENT CAREFULLY CHECKED EVERY WORD BEFORE CHOOSING AN ANSWER." },
        { visual: "READING SLOWLY CAN HELP US NOTICE SMALL DIFFERENCES BETWEEN WORDS.", options: ["READING QUICKLY CAN HELP US NOTICE SMALL DIFFERENCES BETWEEN WORDS.", "READING SLOWLY CAN HELP US NOTICE SMALL DIFFERENCES IN WORDS.", "READING SLOWLY CAN HELP US NOTICE SMALL DIFFERENCE BETWEEN WORDS.", "READING SLOWLY CAN HELP US NOTICE SMALL DIFFERENCES BETWEEN WORDS."], answer: "READING SLOWLY CAN HELP US NOTICE SMALL DIFFERENCES BETWEEN WORDS." },
        { visual: "THE CLASSROOM BECAME QUIET WHILE EVERYONE WORKED ON THE ACTIVITY.", options: ["THE CLASSROOM BECAME QUIET WHILE EVERYONE WORKED IN THE ACTIVITY.", "THE CLASSROOM BECAME QUIET WHILE EVERYONE WORKED ON THE ACTIVITY.", "THE CLASSROOM BECAME QUITE WHILE EVERYONE WORKED ON THE ACTIVITY.", "THE CLASSROOM BECAME QUIET WHILE EVERYONE WORKED ON AN ACTIVITY."], answer: "THE CLASSROOM BECAME QUIET WHILE EVERYONE WORKED ON THE ACTIVITY." },
        { visual: "MY FRIEND ORGANIZED THE COLOURED CARDS INTO THREE NEAT GROUPS.", options: ["MY FRIEND ORGANIZED THE COLOURED CARDS INTO TWO NEAT GROUPS.", "MY FRIEND ORGANISED THE COLOURED CARDS INTO THREE NEAT GROUPS.", "MY FRIEND ORGANIZED THE COLOURED CARDS INTO THREE NEAT GROUPS.", "MY FRIEND ORGANIZED THE COLORED CARDS INTO THREE NEAT GROUPS."], answer: "MY FRIEND ORGANIZED THE COLOURED CARDS INTO THREE NEAT GROUPS." },
        { visual: "THE TEACHER ASKED US TO COMPARE EACH SENTENCE VERY CAREFULLY.", options: ["THE TEACHER ASKED US TO COMPLETE EACH SENTENCE VERY CAREFULLY.", "THE TEACHER ASKED US TO COMPARE EACH SENTENCES VERY CAREFULLY.", "THE TEACHER ASKED US TO COMPARE EACH SENTENCE VERY CLEARLY.", "THE TEACHER ASKED US TO COMPARE EACH SENTENCE VERY CAREFULLY."], answer: "THE TEACHER ASKED US TO COMPARE EACH SENTENCE VERY CAREFULLY." },
        { visual: "BEFORE SUBMITTING THE WORK, THE CHILD CHECKED THE SPELLING AGAIN.", options: ["BEFORE SUBMITTING THE WORK, THE CHILD CHECKED THE SPELLING AGAIN.", "AFTER SUBMITTING THE WORK, THE CHILD CHECKED THE SPELLING AGAIN.", "BEFORE SUBMITTING THE WORK, THE CHILD CHECKED THE SPELLINGS AGAIN.", "BEFORE SUBMITTING THE WORK THE CHILD CHECKED THE SPELLING AGAIN."], answer: "BEFORE SUBMITTING THE WORK, THE CHILD CHECKED THE SPELLING AGAIN." },
        { visual: "THE SCIENCE PROJECT REQUIRED PATIENCE, CAREFUL OBSERVATION, AND GOOD NOTES.", options: ["THE SCIENCE PROJECT REQUIRED PATIENCE, CAREFUL OBSERVATION AND GOOD NOTES.", "THE SCIENCE PROJECT REQUIRED PATIENTS, CAREFUL OBSERVATION, AND GOOD NOTES.", "THE SCIENCE PROJECT REQUIRED PATIENCE, CAREFUL OBSERVATION, AND GOOD NOTES.", "THE SCIENCE PROJECT REQUIRED PATIENCE, CAREFUL OBSERVATIONS, AND GOOD NOTES."], answer: "THE SCIENCE PROJECT REQUIRED PATIENCE, CAREFUL OBSERVATION, AND GOOD NOTES." },
        { visual: "THE STUDENTS DISCUSSED WHICH SENTENCE MATCHED THE ORIGINAL MOST EXACTLY.", options: ["THE STUDENTS DISCUSSED WHICH SENTENCE MATCHED THE ORIGINAL MOST EXACT.", "THE STUDENT DISCUSSED WHICH SENTENCE MATCHED THE ORIGINAL MOST EXACTLY.", "THE STUDENTS DISCUSSED WHICH SENTENCE MATCHED THE ORIGINALLY MOST EXACTLY.", "THE STUDENTS DISCUSSED WHICH SENTENCE MATCHED THE ORIGINAL MOST EXACTLY."], answer: "THE STUDENTS DISCUSSED WHICH SENTENCE MATCHED THE ORIGINAL MOST EXACTLY." },
        { visual: "GOOD VISUAL SKILLS HELP US NOTICE LETTER ORDER, SPACING, AND PUNCTUATION.", options: ["GOOD VISUAL SKILLS HELP US NOTICE LETTER ORDER, SPACING, AND PUNCTUATION.", "GOOD VISUAL SKILLS HELP US NOTICE LETTER ORDER, SPACING AND PUNCTUATION.", "GOOD VISUAL SKILLS HELP US NOTICE LETTER ORDERS, SPACING, AND PUNCTUATION.", "GOOD VISUAL SKILLS HELP US NOTICE LETTER ORDER, SPELLING, AND PUNCTUATION."], answer: "GOOD VISUAL SKILLS HELP US NOTICE LETTER ORDER, SPACING, AND PUNCTUATION." },
      ],
      "WHICH SENTENCE IS COMPLETELY IDENTICAL?",
      "USE HIGH-ATTENTION VISUAL COMPARISON OF WORDS, SPACING AND PUNCTUATION."
    ),
  ],
};
/* =========================================================
   STAGE 1 ACCESSOR
   Stable IDs: class + level + question.
   ========================================================= */
/* =========================================================
   GRADE 1 — STAGE 3 QUESTION BANK
   WRITING & UNDERSTANDING

   3 LEVELS × 9 QUESTIONS = 27 QUESTIONS
   ========================================================= */


/* =======================================================
   LEVEL 1 — EASY
   LETTERS & SIMPLE WORDS
   ======================================================= */
const CLASS5_STAGE3_BANK = [
  {
    id: 1,
    title: "LEVEL 1",
    difficulty: "EASY",
    exercises: [
      {
        id: "c5-s3-l1-q1",
        prompt: "Complete: The boy ___ football every evening.",
        options: ["play", "playing", "plays"], answer: "plays",
      },
      {
        id: "c5-s3-l1-q2",
        prompt: "Choose the correct spelling.",
        options: ["morining", "mornning", "morning"], answer: "morning",
      },
      {
        id: "c5-s3-l1-q3",
        prompt: "What is the opposite of 'early'?",
        options: ["quick", "late", "fast"], answer: "late",
      },
      {
        id: "c5-s3-l1-q4",
        prompt: "Complete: I ___ my homework yesterday.",
        options: ["finish", "finishing", "finished"], answer: "finished",
      },
      {
        id: "c5-s3-l1-q5",
        prompt: "Which word describes the lion?",
        options: ["quickly", "run", "brave"], answer: "brave",
      },
      {
        id: "c5-s3-l1-q6",
        prompt: "Which sentence is correct?",
        options: [
          "My sister likes drawing.",
          "My sister like drawing.",
          "My sister liking drawing."
        ],
        answer: "My sister likes drawing.",
      },
      {
        id: "c5-s3-l1-q7",
        prompt: "Complete: The keys are ___ the table.",
        options: ["happy", "on", "run"], answer: "on",
      },
      {
        id: "c5-s3-l1-q8",
        prompt: "Which word rhymes with 'rain'?",
        options: ["book", "fish", "train"], answer: "train",
      },
      {
        id: "c5-s3-l1-q9",
        prompt: "Arrange the words: school / goes / Riya / to / every day",
        options: [
          "Riya goes to school every day.",
          "Every day school Riya goes to.",
          "Goes Riya every school day to."
        ],
        answer: "Riya goes to school every day.",
      },
    ],
  },

  {
    id: 2,
    title: "LEVEL 2",
    difficulty: "MEDIUM",
    exercises: [
      {
        id: "c5-s3-l2-q1",
        prompt: "Complete: We ___ a movie last night.",
        options: ["watching", "watched", "watch"], answer: "watched",
      },
      {
        id: "c5-s3-l2-q2",
        prompt: "Choose the correct punctuation: Where are you going___",
        options: ["!", ".", "?"], answer: "?",
      },
      {
        id: "c5-s3-l2-q3",
        prompt: "What is another word for 'small'?",
        options: ["huge", "little", "wide"], answer: "little",
      },
      {
        id: "c5-s3-l2-q4",
        prompt: "Complete: The children ___ playing in the garden.",
        options: ["am", "is", "are"], answer: "are",
      },
      {
        id: "c5-s3-l2-q5",
        prompt: "Which sentence is correct?",
        options: [
          "My father went to work early.",
          "My father go to work early.",
          "My father going to work early."
        ],
        answer: "My father went to work early.",
      },
      {
        id: "c5-s3-l2-q6",
        prompt: "Rahul took his umbrella before leaving because dark clouds covered the sky. Why did he take an umbrella?",
        options: [
          "He thought it might rain.",
          "He wanted to play.",
          "He wanted to sleep."
        ],
        answer: "He thought it might rain.",
      },
      {
        id: "c5-s3-l2-q7",
        prompt: "Complete: The elephant is ___ than the dog.",
        options: ["big", "biggest", "bigger"], answer: "bigger",
      },
      {
        id: "c5-s3-l2-q8",
        prompt: "Put these actions in the correct order.",
        options: [
          "Wake up, brush teeth, eat breakfast, go to school.",
          "Go to school, wake up, eat breakfast, brush teeth.",
          "Eat breakfast, go to school, wake up, brush teeth."
        ],
        answer: "Wake up, brush teeth, eat breakfast, go to school.",
      },
      {
        id: "c5-s3-l2-q9",
        prompt: "Which sentence makes sense?",
        options: [
          "The farmer grows vegetables on his farm.",
          "The farmer grows vegetables in the sky.",
          "The farmer grows vegetables inside a shoe."
        ],
        answer: "The farmer grows vegetables on his farm.",
      },
    ],
  },

  {
    id: 3,
    title: "LEVEL 3",
    difficulty: "HARD",
    exercises: [
      {
        id: "c5-s3-l3-q1",
        prompt: "Anaya practised her spelling words every day. She got all the words correct in her test. What helped Anaya?",
        options: [
          "Practising every day.",
          "Forgetting her spelling words.",
          "Not studying for the test."
        ],
        answer: "Practising every day.",
      },
      {
        id: "c5-s3-l3-q2",
        prompt: "Complete: It was raining, ___ we stayed inside.",
        options: ["and", "but", "so"], answer: "so",
      },
      {
        id: "c5-s3-l3-q3",
        prompt: "Which sentence is correct?",
        options: [
          "Although it was cold, we went outside.",
          "Although it cold was, we outside went.",
          "Although cold, outside we went was."
        ],
        answer: "Although it was cold, we went outside.",
      },
      {
        id: "c5-s3-l3-q4",
        prompt: "The plant had dry leaves because nobody watered it. What did the plant need?",
        options: ["Paper", "Paint", "Water"], answer: "Water",
      },
      {
        id: "c5-s3-l3-q5",
        prompt: "Complete: I wanted to play outside, ___ it was raining.",
        options: ["so", "because", "but"], answer: "but",
      },
      {
        id: "c5-s3-l3-q6",
        prompt: "A boy was carrying a wet umbrella. What probably happened?",
        options: [
          "It was raining.",
          "He was sitting in the sun.",
          "He was eating lunch."
        ],
        answer: "It was raining.",
      },
      {
        id: "c5-s3-l3-q7",
        prompt: "Which sentence has the clearest meaning?",
        options: [
          "Meena carefully carried the glass.",
          "Meena the glass carried carefully.",
          "The glass carefully Meena carried."
        ],
        answer: "Meena carefully carried the glass.",
      },
      {
        id: "c5-s3-l3-q8",
        prompt: "Ravi packed a water bottle before going for a long walk. Why?",
        options: [
          "He might feel thirsty.",
          "He wanted to read it.",
          "He wanted to wear it."
        ],
        answer: "He might feel thirsty.",
      },
      {
        id: "c5-s3-l3-q9",
        prompt: "Which sentence makes the most sense?",
        options: [
          "Although the bag was heavy, Neha carried it carefully.",
          "Although the bag was heavy, Neha ate it carefully.",
          "Although the bag was heavy, Neha read it carefully."
        ],
        answer: "Although the bag was heavy, Neha carried it carefully.",
      },
    ],
  },
];
const CLASS4_STAGE3_BANK = [
  {
    id: 1,
    title: "LEVEL 1",
    difficulty: "EASY",
    exercises: [
      {
        id: "c4-s3-l1-q1",
        prompt: "Complete: The girl ___ to school every day.",
        options: ["walk", "walking", "walks"], answer: "walks",
      },
      {
        id: "c4-s3-l1-q2",
        prompt: "Choose the correct spelling.",
        options: ["becaus", "because", "becouse"], answer: "because",
      },
      {
        id: "c4-s3-l1-q3",
        prompt: "What is the opposite of 'clean'?",
        options: ["bright", "soft", "dirty"], answer: "dirty",
      },
      {
        id: "c4-s3-l1-q4",
        prompt: "Which word describes the flower?",
        options: ["run", "beautiful", "quickly"], answer: "beautiful",
      },
      {
        id: "c4-s3-l1-q5",
        prompt: "Complete: The book is ___ the table.",
        options: ["happy", "on", "run"], answer: "on",
      },
      {
        id: "c4-s3-l1-q6",
        prompt: "Which sentence is correct?",
        options: [
          "My brother likes cricket.",
          "My brother like cricket.",
          "My brother liking cricket."
        ],
        answer: "My brother likes cricket.",
      },
      {
        id: "c4-s3-l1-q7",
        prompt: "Which word rhymes with 'cake'?",
        options: ["book", "fish", "lake"], answer: "lake",
      },
      {
        id: "c4-s3-l1-q8",
        prompt: "Complete: I was hungry, so I ___ a sandwich.",
        options: ["eat", "ate", "eating"], answer: "ate",
      },
      {
        id: "c4-s3-l1-q9",
        prompt: "Arrange the words: is / the / dog / sleeping",
        options: [
          "The dog is sleeping.",
          "Sleeping the dog is.",
          "The sleeping is dog."
        ],
        answer: "The dog is sleeping.",
      },
    ],
  },

  {
    id: 2,
    title: "LEVEL 2",
    difficulty: "MEDIUM",
    exercises: [
      {
        id: "c4-s3-l2-q1",
        prompt: "Complete: Yesterday, Riya ___ a story.",
        options: ["reads", "reading", "read"], answer: "read",
      },
      {
        id: "c4-s3-l2-q2",
        prompt: "Which sentence has the correct punctuation?",
        options: [
          "Where is my pencil?",
          "Where is my pencil.",
          "Where is my pencil!"
        ],
        answer: "Where is my pencil?",
      },
      {
        id: "c4-s3-l2-q3",
        prompt: "What is another word for 'happy'?",
        options: ["tired", "angry", "glad"], answer: "glad",
      },
      {
        id: "c4-s3-l2-q4",
        prompt: "Complete: The children ___ playing outside.",
        options: ["is", "are", "am"], answer: "are",
      },
      {
        id: "c4-s3-l2-q5",
        prompt: "Choose the correct sentence.",
        options: [
          "She went to the market with her mother.",
          "She go to the market with her mother.",
          "She going to the market with her mother."
        ],
        answer: "She went to the market with her mother.",
      },
      {
        id: "c4-s3-l2-q6",
        prompt: "Maya took an umbrella because the clouds were dark. Why did she take it?",
        options: [
          "She thought it might rain.",
          "She wanted to play.",
          "She wanted to sleep."
        ],
        answer: "She thought it might rain.",
      },
      {
        id: "c4-s3-l2-q7",
        prompt: "Complete: The puppy is ___ than the kitten.",
        options: ["big", "bigger", "biggest"], answer: "bigger",
      },
      {
        id: "c4-s3-l2-q8",
        prompt: "Put the actions in the correct order.",
        options: [
          "Wake up, brush my teeth, eat breakfast.",
          "Eat breakfast, wake up, brush my teeth.",
          "Brush my teeth, eat breakfast, wake up."
        ],
        answer: "Wake up, brush my teeth, eat breakfast.",
      },
      {
        id: "c4-s3-l2-q9",
        prompt: "Which sentence makes sense?",
        options: [
          "The farmer planted seeds in the soil.",
          "The farmer planted seeds in the sky.",
          "The farmer planted seeds in a shoe."
        ],
        answer: "The farmer planted seeds in the soil.",
      },
    ],
  },

  {
    id: 3,
    title: "LEVEL 3",
    difficulty: "HARD",
    exercises: [
      {
        id: "c4-s3-l3-q1",
        prompt: "Rohan studied for his test every evening. He answered the questions easily. What does this tell us?",
        options: [
          "He was well prepared.",
          "He forgot to study.",
          "He did not like the test."
        ],
        answer: "He was well prepared.",
      },
      {
        id: "c4-s3-l3-q2",
        prompt: "Complete: It was raining, ___ we stayed inside.",
        options: ["but", "so", "and"], answer: "so",
      },
      {
        id: "c4-s3-l3-q3",
        prompt: "Which sentence is written correctly?",
        options: [
          "Although it was cold, we went outside.",
          "Although it cold was, we outside went.",
          "Although cold, outside we went was."
        ],
        answer: "Although it was cold, we went outside.",
      },
      {
        id: "c4-s3-l3-q4",
        prompt: "The plant had dry leaves because nobody watered it. What did the plant need?",
        options: ["paint", "paper", "water"], answer: "water",
      },
      {
        id: "c4-s3-l3-q5",
        prompt: "Complete: Sara wanted to play outside, ___ it started raining.",
        options: ["so", "but", "because"], answer: "but",
      },
      {
        id: "c4-s3-l3-q6",
        prompt: "A boy was shivering and his clothes were wet. What probably happened?",
        options: [
          "He got wet in the rain.",
          "He was sitting in the sun.",
          "He was eating lunch."
        ],
        answer: "He got wet in the rain.",
      },
      {
        id: "c4-s3-l3-q7",
        prompt: "Which sentence has the clearest meaning?",
        options: [
          "Neha carefully carried the glass.",
          "Neha the glass carried carefully.",
          "The glass carefully Neha carried."
        ],
        answer: "Neha carefully carried the glass.",
      },
      {
        id: "c4-s3-l3-q8",
        prompt: "Aman packed a jacket before going outside because the weather was cold. Why did he pack it?",
        options: [
          "To keep himself warm.",
          "To keep his books dry.",
          "To play with it."
        ],
        answer: "To keep himself warm.",
      },
      {
        id: "c4-s3-l3-q9",
        prompt: "Which sentence is the most sensible?",
        options: [
          "Although the bag was heavy, Ravi carried it carefully.",
          "Although the bag was heavy, Ravi ate it carefully.",
          "Although the bag was heavy, Ravi read it carefully."
        ],
        answer: "Although the bag was heavy, Ravi carried it carefully.",
      },
    ],
  },
];
const CLASS3_STAGE3_BANK = [
  {
    id: 1,
    title: "LEVEL 1",
    difficulty: "EASY",

    exercises: [
      {
        id: "c3-s3-l1-q1",
        prompt: "Complete: The children ___ playing in the park.",
        options: ["am", "are", "is"], answer: "are",
      },

      {
        id: "c3-s3-l1-q2",
        prompt: "Choose the correct spelling.",
        options: ["beutiful", "beautifull", "beautiful"], answer: "beautiful",
      },

      {
        id: "c3-s3-l1-q3",
        prompt: "What is the opposite of 'noisy'?",
        options: ["bright", "loud", "quiet"], answer: "quiet",
      },

      {
        id: "c3-s3-l1-q4",
        prompt: "Complete: Rohan ___ his teeth every morning.",
        options: ["brushing", "brush", "brushes"], answer: "brushes",
      },

      {
        id: "c3-s3-l1-q5",
        prompt: "Which word is a noun?",
        options: ["beautiful", "garden", "quickly"], answer: "garden",
      },

      {
        id: "c3-s3-l1-q6",
        prompt: "Which sentence is correct?",
        options: [
          "She has a red umbrella.",
          "She have a red umbrella.",
          "She having a red umbrella."
        ],
        answer: "She has a red umbrella.",
      },

      {
        id: "c3-s3-l1-q7",
        prompt: "Complete: The baby is sleeping ___ the bed.",
        options: ["from", "with", "on"], answer: "on",
      },

      {
        id: "c3-s3-l1-q8",
        prompt: "Which word rhymes with 'light'?",
        options: ["book", "tree", "night"], answer: "night",
      },

      {
        id: "c3-s3-l1-q9",
        prompt: "Arrange the words: playing / children / are / outside",
        options: [
          "The children are playing outside.",
          "Playing children outside are.",
          "Outside playing are children."
        ],
        answer: "The children are playing outside.",
      },
    ],
  },

  {
    id: 2,
    title: "LEVEL 2",
    difficulty: "MEDIUM",

    exercises: [
      {
        id: "c3-s3-l2-q1",
        prompt: "Choose the correct punctuation: What a beautiful day___",
        options: ["?", ".", "!"], answer: "!",
      },

      {
        id: "c3-s3-l2-q2",
        prompt: "Complete: Yesterday, we ___ to the museum.",
        options: ["go", "going", "went"], answer: "went",
      },

      {
        id: "c3-s3-l2-q3",
        prompt: "Which word means the same as 'happy'?",
        options: ["tired", "joyful", "angry"], answer: "joyful",
      },

      {
        id: "c3-s3-l2-q4",
        prompt: "Complete: The birds ___ flying in the sky.",
        options: ["is", "are", "was"], answer: "are",
      },

      {
        id: "c3-s3-l2-q5",
        prompt: "Which sentence is written correctly?",
        options: [
          "My brother and I went to the library.",
          "my brother and I went to the library",
          "My brother and me went to the library."
        ],
        answer: "My brother and I went to the library.",
      },

      {
        id: "c3-s3-l2-q6",
        prompt: "Read: Maya carried an umbrella because the sky was dark. Why did Maya carry it?",
        options: [
          "She thought it might rain.",
          "She wanted to play tennis.",
          "She wanted to sleep."
        ],
        answer: "She thought it might rain.",
      },

      {
        id: "c3-s3-l2-q7",
        prompt: "Choose the correct order: first / breakfast / I / eat / then / go / school",
        options: [
          "First I eat breakfast, then I go to school.",
          "I school go then breakfast eat.",
          "Then breakfast I school go first."
        ],
        answer: "First I eat breakfast, then I go to school.",
      },

      {
        id: "c3-s3-l2-q8",
        prompt: "Complete: Neha is ___ than her younger sister.",
        options: ["tall", "tallest", "taller"], answer: "taller",
      },

      {
        id: "c3-s3-l2-q9",
        prompt: "Which sentence makes the most sense?",
        options: [
          "The farmer planted seeds in the soil.",
          "The farmer planted seeds in the sky.",
          "The farmer planted seeds in the cupboard."
        ],
        answer: "The farmer planted seeds in the soil.",
      },
    ],
  },

  {
    id: 3,
    title: "LEVEL 3",
    difficulty: "HARD",

    exercises: [
      {
        id: "c3-s3-l3-q1",
        prompt: "Read: Aarav forgot his lunch at home, so his mother brought it to school. Why did his mother come to school?",
        options: [
          "To bring Aarav his lunch.",
          "To take Aarav home.",
          "To play in the school."
        ],
        answer: "To bring Aarav his lunch.",
      },

      {
        id: "c3-s3-l3-q2",
        prompt: "Complete: Although the road was muddy, the children ___ walking carefully.",
        options: ["forgot", "continued", "stopped"], answer: "continued",
      },

      {
        id: "c3-s3-l3-q3",
        prompt: "Which sentence has the clearest meaning?",
        options: [
          "Riya carefully placed the glass on the table.",
          "Riya the glass carefully table placed.",
          "The table carefully placed Riya glass."
        ],
        answer: "Riya carefully placed the glass on the table.",
      },

      {
        id: "c3-s3-l3-q4",
        prompt: "Read: The garden was full of dry leaves, and the gardener swept them into a pile. What did the gardener do?",
        options: [
          "He swept the leaves.",
          "He watered the flowers.",
          "He planted new trees."
        ],
        answer: "He swept the leaves.",
      },

      {
        id: "c3-s3-l3-q5",
        prompt: "Choose the sentence with the correct use of 'because'.",
        options: [
          "I stayed inside because it was raining.",
          "Because I stayed inside it was raining.",
          "It was raining because stayed inside I."
        ],
        answer: "I stayed inside because it was raining.",
      },

      {
        id: "c3-s3-l3-q6",
        prompt: "Complete: Sara wanted to buy the book, ___ she did not have enough money.",
        options: ["and", "so", "but"], answer: "but",
      },

      {
        id: "c3-s3-l3-q7",
        prompt: "Read: The puppy was shivering and its fur was wet. What probably happened?",
        options: [
          "The puppy got wet in the rain.",
          "The puppy was sleeping in the sun.",
          "The puppy was eating its food."
        ],
        answer: "The puppy got wet in the rain.",
      },

      {
        id: "c3-s3-l3-q8",
        prompt: "Which sentence gives the best reason for carrying a water bottle?",
        options: [
          "I carried a water bottle because I might feel thirsty.",
          "I carried a water bottle because books can drink water.",
          "I carried a water bottle because shoes need water."
        ],
        answer: "I carried a water bottle because I might feel thirsty.",
      },

      {
        id: "c3-s3-l3-q9",
        prompt: "Which sentence is the most sensible?",
        options: [
          "Even though the bag was heavy, Meera carried it carefully.",
          "Even though the bag was heavy, Meera drank it carefully.",
          "Even though the bag was heavy, Meera read it carefully."
        ],
        answer: "Even though the bag was heavy, Meera carried it carefully.",
      },
    ],
  },
];
/* =========================================================
CLASS 2 — STAGE 3 QUESTION BANK
WRITING & UNDERSTANDING

3 LEVELS × 9 QUESTIONS = 27 QUESTIONS
========================================================= */

const CLASS2_STAGE3_BANK = [
  {
    id: 1,
    title: "LEVEL 1",
    difficulty: "EASY",

    exercises: [
      {
        id: "c2-s3-l1-q1",
        prompt: "Complete: The sun is ___.",
        options: ["small", "cold", "hot"], answer: "hot",
      },

      {
        id: "c2-s3-l1-q2",
        prompt: "Complete: I ___ to school every day.",
        options: ["eat", "sleep", "go"], answer: "go",
      },

      {
        id: "c2-s3-l1-q3",
        prompt: "Which is the correct sentence?",
        options: [
          "The cat is sleeping.",
          "The cat are sleeping.",
          "The cat sleeping is."
        ],
        answer: "The cat is sleeping.",
      },

      {
        id: "c2-s3-l1-q4",
        prompt: "Complete: Birds can ___.",
        options: ["read", "swim", "fly"], answer: "fly",
      },

      {
        id: "c2-s3-l1-q5",
        prompt: "Which word rhymes with ball?",
        options: ["sun", "cat", "tall"], answer: "tall",
      },

      {
        id: "c2-s3-l1-q6",
        prompt: "Which is the correct spelling?",
        options: ["shcool", "school", "skool"], answer: "school",
      },

      {
        id: "c2-s3-l1-q7",
        prompt: "Complete: I drink water when I am ___.",
        options: ["happy", "sleepy", "thirsty"], answer: "thirsty",
      },

      {
        id: "c2-s3-l1-q8",
        prompt: "Which sentence makes sense?",
        options: [
          "I wear shoes on my feet.",
          "I wear shoes on my head.",
          "I wear shoes in my water."
        ],
        answer: "I wear shoes on my feet.",
      },

      {
        id: "c2-s3-l1-q9",
        prompt: "What is the opposite of big?",
        options: ["long", "small", "tall"], answer: "small",
      },
    ],
  },

  {
    id: 2,
    title: "LEVEL 2",
    difficulty: "MEDIUM",

    exercises: [
      {
        id: "c2-s3-l2-q1",
        prompt: "Complete: Riya ___ a book every night.",
        options: ["read", "reading", "reads"], answer: "reads",
      },

      {
        id: "c2-s3-l2-q2",
        prompt: "Which sentence has the correct punctuation?",
        options: [
          "Where are you?",
          "Where are you.",
          "Where are you!"
        ],
        answer: "Where are you?",
      },

      {
        id: "c2-s3-l2-q3",
        prompt: "Complete: The children ___ playing.",
        options: ["am", "are", "is"], answer: "are",
      },

      {
        id: "c2-s3-l2-q4",
        prompt: "What is the opposite of early?",
        options: ["fast", "quick", "late"], answer: "late",
      },

      {
        id: "c2-s3-l2-q5",
        prompt: "The boy was hungry, so he ___ lunch.",
        options: ["eating", "ate", "eat"], answer: "ate",
      },

      {
        id: "c2-s3-l2-q6",
        prompt: "Which is the correct sentence?",
        options: [
          "My friend has a blue bag.",
          "My friend have a blue bag.",
          "My friend blue has a bag."
        ],
        answer: "My friend has a blue bag.",
      },

      {
        id: "c2-s3-l2-q7",
        prompt: "Complete: Take an umbrella when it is ___.",
        options: ["dry", "sunny", "raining"], answer: "raining",
      },

      {
        id: "c2-s3-l2-q8",
        prompt: "Complete: The puppy is ___ than the dog.",
        options: ["small", "smaller", "smallest"], answer: "smaller",
      },

      {
        id: "c2-s3-l2-q9",
        prompt: "Arrange the words: school / I / go / to",
        options: [
          "I go to school.",
          "School I go to.",
          "Go I school to."
        ],
        answer: "I go to school.",
      },
    ],
  },

  {
    id: 3,
    title: "LEVEL 3",
    difficulty: "HARD",

    exercises: [
      {
        id: "c2-s3-l3-q1",
        prompt: "Which is the correct sentence?",
        options: [
          "Because it was raining, we stayed inside.",
          "Because raining it was, we inside stayed.",
          "We stayed because inside raining was it."
        ],
        answer: "Because it was raining, we stayed inside.",
      },

      {
        id: "c2-s3-l3-q2",
        prompt: "Complete: Aman was tired, ___ he went to bed early.",
        options: ["but", "so", "or"], answer: "so",
      },

      {
        id: "c2-s3-l3-q3",
        prompt: "Which sentence correctly shows that Sara owns the bag?",
        options: [
          "Sara has a red bag.",
          "Sara red a bag has.",
          "A red bag Sara."
        ],
        answer: "Sara has a red bag.",
      },

      {
        id: "c2-s3-l3-q4",
        prompt: "The plant did not get water. What happened?",
        options: [
          "It became dry.",
          "It became wet.",
          "It started swimming."
        ],
        answer: "It became dry.",
      },

      {
        id: "c2-s3-l3-q5",
        prompt: "Which sentence is spelled correctly?",
        options: [
          "The rabbit jumped over the fence.",
          "The rabit jumpt over the fense.",
          "The rabbit jumpt over the fence."
        ],
        answer: "The rabbit jumped over the fence.",
      },

      {
        id: "c2-s3-l3-q6",
        prompt: "Complete: Meena wanted to play outside, ___ it was raining.",
        options: ["so", "but", "and"], answer: "but",
      },

      {
        id: "c2-s3-l3-q7",
        prompt: "Which sentence has the clearest meaning?",
        options: [
          "The boy carefully carried the glass.",
          "The boy glass carried carefully the.",
          "Carefully glass the boy."
        ],
        answer: "The boy carefully carried the glass.",
      },

      {
        id: "c2-s3-l3-q8",
        prompt: "Tom packed an umbrella because dark clouds filled the sky. What did he think?",
        options: [
          "He thought it might rain.",
          "He thought it might snow.",
          "He thought the sun was very bright."
        ],
        answer: "He thought it might rain.",
      },

      {
        id: "c2-s3-l3-q9",
        prompt: "Which sentence is the most sensible?",
        options: [
          "Although the box was heavy, Ravi carried it carefully.",
          "Although the box was heavy, Ravi ate it carefully.",
          "Although the box was heavy, Ravi read it carefully."
        ],
        answer: "Although the box was heavy, Ravi carried it carefully.",
      },
    ],
  },
];
const GRADE1_STAGE3_BANK = [
  {
    id: 1,
    title: "LEVEL 1",
    difficulty: "EASY",

    exercises: [

      {
        id: "g1-s3-l1-q1",
        prompt: "What letter comes after A?",
        options: ["B", "C", "D"], answer: "B",
      },

      {
        id: "g1-s3-l1-q2",
        prompt: "What letter comes before D?",
        options: ["E", "C", "B"], answer: "C",
      },

      {
        id: "g1-s3-l1-q3",
        prompt: "Which letter comes after F?",
        options: ["E", "H", "G"], answer: "G",
      },

      {
        id: "g1-s3-l1-q4",
        prompt: "Which letter comes before H?",
        options: ["F", "I", "G"], answer: "G",
      },

      {
        id: "g1-s3-l1-q5",
        prompt: "Complete the word: C _ T",
        options: ["I", "A", "E"], answer: "A",
      },

      {
        id: "g1-s3-l1-q6",
        prompt: "Complete the word: D _ G",
        options: ["A", "E", "O"], answer: "O",
      },

      {
        id: "g1-s3-l1-q7",
        prompt: "Which word starts with B?",
        options: ["CAT", "SUN", "BALL"], answer: "BALL",
      },

      {
        id: "g1-s3-l1-q8",
        prompt: "Which word starts with M?",
        options: ["MAP", "SUN", "DOG"], answer: "MAP",
      },

      {
        id: "g1-s3-l1-q9",
        prompt: "Which word starts with P?",
        options: ["CAT", "FISH", "PEN"], answer: "PEN",
      },

    ],
  },


  /* =======================================================
     LEVEL 2 — MEDIUM
     WORD FORMATION & SPELLING
     ======================================================= */

  {
    id: 2,
    title: "LEVEL 2",
    difficulty: "MEDIUM",

    exercises: [

      {
        id: "g1-s3-l2-q1",
        prompt: "Which word is spelled correctly?",
        options: ["FIS", "FESH", "FISH"], answer: "FISH",
      },

      {
        id: "g1-s3-l2-q2",
        prompt: "Which word is spelled correctly?",
        options: ["SCHOOL", "SKOOL", "SHCOOL"], answer: "SCHOOL",
      },

      {
        id: "g1-s3-l2-q3",
        prompt: "Complete: SH _ P",
        options: ["E", "I", "A"], answer: "I",
      },

      {
        id: "g1-s3-l2-q4",
        prompt: "Complete: TR _ E",
        options: ["I", "A", "E"], answer: "E",
      },

      {
        id: "g1-s3-l2-q5",
        prompt: "Which word rhymes with CAT?",
        options: ["HAT", "DOG", "SUN"], answer: "HAT",
      },

      {
        id: "g1-s3-l2-q6",
        prompt: "Which word rhymes with TREE?",
        options: ["BOOK", "BEE", "CAR"], answer: "BEE",
      },

      {
        id: "g1-s3-l2-q7",
        prompt: "Which word has the same beginning sound as FISH?",
        options: ["DOG", "CAT", "FAN"], answer: "FAN",
      },

      {
        id: "g1-s3-l2-q8",
        prompt: "Which word has the same beginning sound as SHIP?",
        options: ["SHOP", "DOG", "CAT"], answer: "SHOP",
      },

      {
        id: "g1-s3-l2-q9",
        prompt: "Which word can be made from B-A-T?",
        options: ["BET", "BAT", "BIT"], answer: "BAT",
      },

    ],
  },


  /* =======================================================
     LEVEL 3 — HARD
     SENTENCE UNDERSTANDING
     ======================================================= */

  {
    id: 3,
    title: "LEVEL 3",
    difficulty: "HARD",

    exercises: [

      {
        id: "g1-s3-l3-q1",
        prompt: "Complete: The cat is ___ the mat.",
        options: ["BLUE", "RUN", "ON"], answer: "ON",
      },

      {
        id: "g1-s3-l3-q2",
        prompt: "Complete: The sun is ___ today.",
        options: ["RUN", "BOOK", "HOT"], answer: "HOT",
      },

      {
        id: "g1-s3-l3-q3",
        prompt: "Complete: The bird can ___.",
        options: ["BOOK", "FLY", "BLUE"], answer: "FLY",
      },

      {
        id: "g1-s3-l3-q4",
        prompt: "Complete: I drink ___ when I am thirsty.",
        options: ["CHAIR", "BALL", "WATER"], answer: "WATER",
      },

      {
        id: "g1-s3-l3-q5",
        prompt: "Complete: I use a ___ to read.",
        options: ["SHOE", "BALL", "BOOK"], answer: "BOOK",
      },

      {
        id: "g1-s3-l3-q6",
        prompt: "Complete: The fish lives in ___.",
        options: ["WATER", "BED", "TREE"], answer: "WATER",
      },

      {
        id: "g1-s3-l3-q7",
        prompt: "Which sentence makes sense?",
        options: ["The dog reads the blue.", "The dog drinks a chair.", "The dog runs in the park."],
        answer: "The dog runs in the park.",
      },

      {
        id: "g1-s3-l3-q8",
        prompt: "Which sentence makes sense?",
        options: ["I wear shoes on my book.", "I wear shoes in my water.", "I wear shoes on my feet."],
        answer: "I wear shoes on my feet.",
      },

      {
        id: "g1-s3-l3-q9",
        prompt: "Which sentence makes sense?",
        options: ["The bird flies in the sky.", "The bird reads a chair.", "The bird eats a pencil."],
        answer: "The bird flies in the sky.",
      },

    ],
  },

];

/* =========================================================
   GRADE 1 — STAGE 3
   WRITING & UNDERSTANDING
   3 LEVELS × 9 QUESTIONS
   ========================================================= */



const getStage1LevelsForClass = (classNumber) => {
  const classKey = String(getNormalizedClassNumber(classNumber));
  const levels =
    CLASS_STAGE1_BANK[classKey] ||
    CLASS_STAGE1_BANK["1"];

  return levels.map((level) => ({
    ...level,
    exercises: level.exercises.map((exercise, index) => ({
      ...exercise,
      id: `c${classKey}l${level.id}q${index + 1}`,
      options: shuffleArray([
        ...new Set(exercise.options || []),
      ]),
    })),
  }));
};

const createShuffledStage1 = (classNumber) => {
  return getStage1LevelsForClass(classNumber);
};

const getStage3LevelsForClass = (classNumber = 1) => {
  const classKey = getNormalizedClassNumber(classNumber);
  const sourceBank =
    classKey === 5
      ? CLASS5_STAGE3_BANK
      : classKey === 4
        ? CLASS4_STAGE3_BANK
        : classKey === 3
          ? CLASS3_STAGE3_BANK
          : classKey === 2
            ? CLASS2_STAGE3_BANK
            : GRADE1_STAGE3_BANK;

  return sourceBank.map((level) => ({
    ...level,
    exercises: level.exercises.map((ex) => ({
      ...ex,
      options: ex.options ? shuffleArray([...new Set(ex.options)]) : ex.options,
    })),
  }));
};

const getStage4LevelsForClass = (classNumber) => {
  const classKey = getNormalizedClassNumber(classNumber);
  const classBank = mathQuestionBanks[classKey] || mathQuestionBanks[1];

  const levelConfigs = [
    { id: 1, title: "LEVEL 1", difficulty: "EASY", description: "SOLVE SIMPLE MATHS PROBLEMS." },
    { id: 2, title: "LEVEL 2", difficulty: "MEDIUM", description: "SOLVE INTERMEDIATE MATHS PROBLEMS." },
    { id: 3, title: "LEVEL 3", difficulty: "HARD", description: "SOLVE ADVANCED MATHS PROBLEMS." },
  ];

  return levelConfigs.map((cfg) => {
    const rawQuestions = classBank[cfg.id] || [];
    return {
      ...cfg,
      exercises: rawQuestions.map((q, idx) => ({
        id: `c${classKey}-m-l${cfg.id}-q${idx + 1}`,
        question: q.question,
        options: shuffleArray([...(q.options || [])]),
        answer: q.answer,
      })),
    };
  });
};

const createShuffledStage4 = (classNumber) => {
  return getStage4LevelsForClass(classNumber);
};

/* =========================================================
   SHAPES VECTOR ENGINE (SVG)
   ========================================================= */

const ShapeVisual = ({ shape, size = 90 }) => {
  const norm = String(shape || "").toLowerCase().trim();

  switch (norm) {
    case "circle":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: "drop-shadow(0 4px 6px rgba(59, 130, 246, 0.3))" }}>
          <defs>
            <linearGradient id="g-circle" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#60a5fa" />
              <stop offset="100%" stopColor="#2563eb" />
            </linearGradient>
          </defs>
          <circle cx="50" cy="50" r="40" fill="url(#g-circle)" stroke="#1d4ed8" strokeWidth="4" />
        </svg>
      );
    case "square":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: "drop-shadow(0 4px 6px rgba(16, 185, 129, 0.3))" }}>
          <defs>
            <linearGradient id="g-square" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#34d399" />
              <stop offset="100%" stopColor="#059669" />
            </linearGradient>
          </defs>
          <rect x="15" y="15" width="70" height="70" rx="12" fill="url(#g-square)" stroke="#047857" strokeWidth="4" />
        </svg>
      );
    case "triangle":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: "drop-shadow(0 4px 6px rgba(245, 158, 11, 0.3))" }}>
          <defs>
            <linearGradient id="g-triangle" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fbbf24" />
              <stop offset="100%" stopColor="#d97706" />
            </linearGradient>
          </defs>
          <polygon points="50,12 88,85 12,85" fill="url(#g-triangle)" stroke="#b45309" strokeWidth="4" strokeLinejoin="round" />
        </svg>
      );
    case "rectangle":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: "drop-shadow(0 4px 6px rgba(139, 92, 246, 0.3))" }}>
          <defs>
            <linearGradient id="g-rectangle" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#a78bfa" />
              <stop offset="100%" stopColor="#7c3aed" />
            </linearGradient>
          </defs>
          <rect x="10" y="24" width="80" height="52" rx="10" fill="url(#g-rectangle)" stroke="#6d28d9" strokeWidth="4" />
        </svg>
      );
    case "star":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: "drop-shadow(0 4px 6px rgba(234, 179, 8, 0.35))" }}>
          <defs>
            <linearGradient id="g-star" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fde047" />
              <stop offset="100%" stopColor="#eab308" />
            </linearGradient>
          </defs>
          <polygon points="50,10 62,38 92,38 68,56 77,85 50,68 23,85 32,56 8,38 38,38" fill="url(#g-star)" stroke="#ca8a04" strokeWidth="3.5" strokeLinejoin="round" />
        </svg>
      );
    case "heart":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: "drop-shadow(0 4px 6px rgba(236, 72, 153, 0.35))" }}>
          <defs>
            <linearGradient id="g-heart" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f472b6" />
              <stop offset="100%" stopColor="#db2777" />
            </linearGradient>
          </defs>
          <path d="M50,82 C50,82 16,54 16,34 C16,20 28,12 39,18 C45,21 48,26 50,30 C52,26 55,21 61,18 C72,12 84,20 84,34 C84,54 50,82 50,82 Z" fill="url(#g-heart)" stroke="#be185d" strokeWidth="3.5" strokeLinejoin="round" />
        </svg>
      );
    case "diamond":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: "drop-shadow(0 4px 6px rgba(6, 182, 212, 0.3))" }}>
          <defs>
            <linearGradient id="g-diamond" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#22d3ee" />
              <stop offset="100%" stopColor="#0891b2" />
            </linearGradient>
          </defs>
          <polygon points="50,10 88,50 50,90 12,50" fill="url(#g-diamond)" stroke="#0e7490" strokeWidth="4" strokeLinejoin="round" />
        </svg>
      );
    case "oval":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: "drop-shadow(0 4px 6px rgba(99, 102, 241, 0.3))" }}>
          <defs>
            <linearGradient id="g-oval" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#818cf8" />
              <stop offset="100%" stopColor="#4f46e5" />
            </linearGradient>
          </defs>
          <ellipse cx="50" cy="50" rx="42" ry="28" fill="url(#g-oval)" stroke="#4338ca" strokeWidth="4" />
        </svg>
      );
    case "pentagon":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: "drop-shadow(0 4px 6px rgba(249, 115, 22, 0.3))" }}>
          <defs>
            <linearGradient id="g-pentagon" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fb923c" />
              <stop offset="100%" stopColor="#ea580c" />
            </linearGradient>
          </defs>
          <polygon points="50,12 90,41 75,88 25,88 10,41" fill="url(#g-pentagon)" stroke="#c2410c" strokeWidth="4" strokeLinejoin="round" />
        </svg>
      );
    case "hexagon":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: "drop-shadow(0 4px 6px rgba(20, 184, 166, 0.3))" }}>
          <defs>
            <linearGradient id="g-hexagon" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#2dd4bf" />
              <stop offset="100%" stopColor="#0d9488" />
            </linearGradient>
          </defs>
          <polygon points="50,12 86,31 86,69 50,88 14,69 14,31" fill="url(#g-hexagon)" stroke="#0f766e" strokeWidth="4" strokeLinejoin="round" />
        </svg>
      );
    case "octagon":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={{ filter: "drop-shadow(0 4px 6px rgba(239, 68, 68, 0.3))" }}>
          <defs>
            <linearGradient id="g-octagon" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f87171" />
              <stop offset="100%" stopColor="#dc2626" />
            </linearGradient>
          </defs>
          <polygon points="30,10 70,10 90,30 90,70 70,90 30,90 10,70 10,30" fill="url(#g-octagon)" stroke="#991b1b" strokeWidth="4" strokeLinejoin="round" />
        </svg>
      );
    case "cube":
      return <ShapeViewer3D shape="cube" color="#38bdf8" height={160} />;
    case "sphere":
      return <ShapeViewer3D shape="sphere" color="#818cf8" height={160} />;
    case "cylinder":
      return <ShapeViewer3D shape="cylinder" color="#f97316" height={160} />;
    case "cone":
      return <ShapeViewer3D shape="cone" color="#ec4899" height={160} />;
    case "pyramid":
      return <ShapeViewer3D shape="pyramid" color="#f59e0b" height={160} />;
    case "prism":
      return <ShapeViewer3D shape="prism" color="#10b981" height={160} />;
    default:
      return <IconShapes size={size} />;
  }
};

/* =========================================================
   CLASS-WISE SHAPES QUESTION BANK (CLASSES 1 TO 5)
   2 LEVELS PER CLASS × 8 QUESTIONS = 16 QUESTIONS PER CLASS
   WITH OPTIONAL FUN SHAPE FACTS
   ========================================================= */

const classShapesQuestionBank = {
  1: {
    1: [
      { question: "Which shape is round with no corners?", shape: "circle", options: ["Circle", "Square", "Triangle", "Rectangle"], answer: "Circle", hint: "Think of a coin or a round plate. It curves around smoothly without any sharp points.", fact: "Did you know? Wheels are circles because round shapes roll smoothly and easily!" },
      { question: "Which shape has 3 sides and 3 corners?", shape: "triangle", options: ["Square", "Triangle", "Oval", "Circle"], answer: "Triangle", hint: "Count the straight sides: one, two, three! It looks like a slice of pizza or a party hat.", fact: "Did you know? Triangles are the strongest shape used to build bridges and roofs!" },
      { question: "Which shape has 4 equal sides?", shape: "square", options: ["Circle", "Star", "Square", "Triangle"], answer: "Square", hint: "All 4 sides are the exact same length, like a square window or a checkerboard tile.", fact: "Did you know? A square looks the same from every side because all 4 sides are identical!" },
      { question: "Which shape shines bright in the night sky?", shape: "star", options: ["Square", "Oval", "Heart", "Star"], answer: "Star", hint: "Look up at the clear night sky. This shape usually has 5 sparkling pointy arms.", fact: "Did you know? A classic star shape has 5 shiny points!" },
      { question: "Which shape looks like a door or a book?", shape: "rectangle", options: ["Circle", "Rectangle", "Triangle", "Heart"], answer: "Rectangle", hint: "It has 4 straight sides: two are long and two are short, just like an entrance door.", fact: "Did you know? A rectangle has two long sides and two short sides!" },
      { question: "Which shape is a symbol of love and friendship?", shape: "heart", options: ["Star", "Diamond", "Heart", "Circle"], answer: "Heart", hint: "People draw this warm shape on cards, with two round bumps on top coming to a point at the bottom.", fact: "Did you know? People have drawn heart shapes on cards for hundreds of years!" },
      { question: "Which shape looks like an egg?", shape: "oval", options: ["Triangle", "Diamond", "Square", "Oval"], answer: "Oval", hint: "It is curved like a circle, but gently stretched out longer from top to bottom.", fact: "Did you know? Birds lay oval-shaped eggs so they don't roll out of nests!" },
      { question: "Which shape looks like a flying kite?", shape: "diamond", options: ["Diamond", "Circle", "Triangle", "Square"], answer: "Diamond", hint: "It has 4 straight sides tilted up on one point, ready to soar in the wind like a kite.", fact: "Did you know? If you turn a square slightly on its corner, it looks like a diamond!" }
    ],
    2: [
      { question: "A delicious round pizza is which shape?", shape: "circle", options: ["Triangle", "Square", "Circle", "Rectangle"], answer: "Circle", hint: "A whole, uncut pizza is completely round and rolls if tipped on its edge.", fact: "Did you know? Even though a whole pizza is round, its slices are shaped like triangles!" },
      { question: "A slice of watermelon looks like a:", shape: "triangle", options: ["Star", "Circle", "Square", "Triangle"], answer: "Triangle", hint: "Notice how one slice has three corners and three sides, tapering down to a juicy point.", fact: "Did you know? The Great Pyramids look like giant triangles from the ground!" },
      { question: "A smartphone or tablet screen is shaped like a:", shape: "rectangle", options: ["Rectangle", "Circle", "Triangle", "Heart"], answer: "Rectangle", hint: "The screen is taller than it is wide, with 4 straight edges: two long sides and two short sides.", fact: "Did you know? Almost all TV, computer, and phone screens are rectangles!" },
      { question: "A chessboard or ludo board is a:", shape: "square", options: ["Circle", "Square", "Triangle", "Oval"], answer: "Square", hint: "Every side of a game board is identical in length, forming a perfect balanced square.", fact: "Did you know? A chessboard contains 64 small black and white squares!" },
      { question: "The wheel of a bicycle or car is a:", shape: "circle", options: ["Square", "Diamond", "Rectangle", "Circle"], answer: "Circle", hint: "Wheels need to roll without bumping, so they must be perfectly round with no corners.", fact: "Did you know? The wheel is one of the most famous and useful inventions ever made!" },
      { question: "A starfish in the ocean has the shape of a:", shape: "star", options: ["Star", "Heart", "Square", "Circle"], answer: "Star", hint: "This sea creature has five pointy arms spreading outward from its center.", fact: "Did you know? Starfish usually have 5 arms and can grow back a lost arm!" },
      { question: "A notebook or storybook is shaped like a:", shape: "rectangle", options: ["Circle", "Rectangle", "Heart", "Triangle"], answer: "Rectangle", hint: "A book has 4 straight borders: two tall sides and two shorter top and bottom edges.", fact: "Did you know? Book pages are rectangular because they are easy to hold and turn!" },
      { question: "A strawberry naturally looks a bit like a:", shape: "heart", options: ["Oval", "Rectangle", "Heart", "Square"], answer: "Heart", hint: "A strawberry is wider and rounded at the top leafy end and narrows down to a tip, like a heart.", fact: "Did you know? Strawberries are the only fruit with their seeds on the outside!" }
    ]
  },

  2: {
    1: [
      { question: "How many sides does a triangle have?", shape: "triangle", options: ["3", "2", "4", "5"], answer: "3", hint: "'Tri' means three! Count the 3 straight lines connecting the 3 corners.", fact: "Did you know? 'Tri' means three! A tricycle has 3 wheels, and a triangle has 3 sides!" },
      { question: "How many corners does a square have?", shape: "square", options: ["5", "4", "3", "6"], answer: "4", hint: "Count each sharp point where two straight edges meet: 1, 2, 3, and 4 corners.", fact: "Did you know? Every corner of a square is a special 90-degree right angle!" },
      { question: "How many straight sides does a circle have?", shape: "circle", options: ["2", "4", "0", "1"], answer: "0", hint: "A circle is one continuous curve that never stops. It has zero straight sides.", fact: "Did you know? Circles are made of one continuous, smooth curved line with 0 straight sides!" },
      { question: "How many sides does a rectangle have?", shape: "rectangle", options: ["5", "6", "3", "4"], answer: "4", hint: "Count the borders: 2 long sides plus 2 short sides make 4 sides in all.", fact: "Did you know? A picture frame is a rectangle with 4 sides and 4 corners!" },
      { question: "Which shape has 5 straight sides?", shape: "pentagon", options: ["Square", "Pentagon", "Circle", "Triangle"], answer: "Pentagon", hint: "'Penta' means five. Count around the perimeter to find five straight edges.", fact: "Did you know? 'Penta' means five in Greek! The famous Pentagon building has 5 sides!" },
      { question: "Which shape is like a stretched circle?", shape: "oval", options: ["Square", "Diamond", "Oval", "Triangle"], answer: "Oval", hint: "Take a circle and gently pull both ends outward: it forms an elongated oval.", fact: "Did you know? Planets orbit the Sun in paths called ellipses, which look like ovals!" },
      { question: "Which 4-sided shape has slanted sides like a kite?", shape: "diamond", options: ["Circle", "Oval", "Triangle", "Diamond"], answer: "Diamond", hint: "Turn a square on its corner or picture a kite in the breeze: that's a diamond.", fact: "Did you know? In geometry, a diamond shape with equal sides is called a rhombus!" },
      { question: "Which shape has 6 straight sides?", shape: "hexagon", options: ["Hexagon", "Pentagon", "Triangle", "Square"], answer: "Hexagon", hint: "'Hexa' means six! Think of the 6 sides of a honeycomb cell or a snowflake.", fact: "Did you know? 'Hex' means six! Snowflakes are natural hexagonal crystals with 6 arms!" }
    ],
    2: [
      { question: "A wall clock telling time is usually a:", shape: "circle", options: ["Star", "Triangle", "Circle", "Diamond"], answer: "Circle", hint: "Most classic wall clocks are round so the hands can turn in a smooth full circle.", fact: "Did you know? Round clock faces allow the hands to sweep around smoothly in a circle!" },
      { question: "A brick used to build houses is shaped like a:", shape: "rectangle", options: ["Circle", "Triangle", "Heart", "Rectangle"], answer: "Rectangle", hint: "Bricks have two longer edges and two shorter edges so builders can interlock them.", fact: "Did you know? Rectangular bricks stack tightly on top of each other to make strong walls!" },
      { question: "A road hazard or yield sign is shaped like a:", shape: "triangle", options: ["Triangle", "Square", "Oval", "Circle"], answer: "Triangle", hint: "Road warning signs use 3 pointed corners to catch a driver's attention quickly.", fact: "Did you know? Warning signs use triangles so drivers can spot them from very far away!" },
      { question: "A playing dice has how many square faces?", shape: "cube", options: ["12", "6", "4", "8"], answer: "6", hint: "Hold a dice: count top and bottom (2), plus 4 sides around = 6 flat square faces.", fact: "Did you know? On any standard dice, opposite faces always add up to 7 (like 1+6 or 2+5)!" },
      { question: "Honeybees build the cells in their honeycombs using:", shape: "hexagon", options: ["Triangle", "Circle", "Square", "Hexagon"], answer: "Hexagon", hint: "Bees use 6-sided shapes because they pack together tightly without leaving any empty gaps.", fact: "Did you know? Hexagons fit together with zero wasted space, holding the most honey!" },
      { question: "A rugby ball or watermelon looks like an:", shape: "oval", options: ["Oval", "Triangle", "Star", "Cube"], answer: "Oval", hint: "It is round but stretched longwise, with smooth curves like an oval.", fact: "Did you know? An oval rugby ball is aerodynamic and easy to tuck under an arm while running!" },
      { question: "A diamond shape with 4 equal sides is also called a:", shape: "diamond", options: ["Circle", "Rhombus", "Square", "Oval"], answer: "Rhombus", hint: "In geometry, a four-sided shape with equal sides tilted like a diamond is a rhombus.", fact: "Did you know? Diamonds are the hardest natural mineral known on Earth!" },
      { question: "A paper currency note is shaped like a:", shape: "rectangle", options: ["Triangle", "Pentagon", "Rectangle", "Circle"], answer: "Rectangle", hint: "Paper money is flat with two long horizontal sides and two shorter vertical sides: a rectangle.", fact: "Did you know? Rectangular banknotes stack flat and fit neatly into wallets!" }
    ]
  },

  3: {
    1: [
      { question: "In a square, all four sides are:", shape: "square", options: ["Equal in length", "Curved", "Different lengths", "Unequal"], answer: "Equal in length", hint: "Measure any side of a square: each of the four sides has the exact same equal length.", fact: "Did you know? Because all sides are equal, a square's perimeter is simply 4 times one side!" },
      { question: "In a rectangle, opposite sides are:", shape: "rectangle", options: ["Unequal", "Equal and parallel", "Curved and wavy", "Three in total"], answer: "Equal and parallel", hint: "Look across: top matches bottom, left matches right. Opposite sides are equal and run parallel.", fact: "Did you know? The word rectangle comes from Latin 'rectus' (straight) and 'angulus' (angle)!" },
      { question: "A triangle with all 3 sides equal is called:", shape: "triangle", options: ["Hexagon", "Oval", "Equilateral", "Square"], answer: "Equilateral", hint: "'Equi' means equal and 'lateral' means side. An equilateral triangle has three equal sides.", fact: "Did you know? In an equilateral triangle, all three interior angles are exactly 60 degrees!" },
      { question: "How many corners does a pentagon have?", shape: "pentagon", options: ["4", "7", "6", "5"], answer: "5", hint: "Every straight-sided flat shape has the same number of corners as sides: 5 sides = 5 corners.", fact: "Did you know? Every regular 2D polygon has the exact same number of sides and corners!" },
      { question: "How many sides does a hexagon have?", shape: "hexagon", options: ["5", "6", "7", "8"], answer: "6", hint: "'Hex' means six. A hexagon has 6 straight lines joined together.", fact: "Did you know? Giant basalt columns at the Giant's Causeway in Ireland cooled into natural hexagons!" },
      { question: "The distance around the outside edge of a circle is its:", shape: "circle", options: ["Perimeter", "Corner", "Circumference", "Radius"], answer: "Circumference", hint: "Just like a perimeter, the special word for the complete outer boundary of a circle is circumference.", fact: "Did you know? Dividing any circle's circumference by its width always gives the number Pi (3.14)!" },
      { question: "A rhombus is a 4-sided shape with all sides:", shape: "diamond", options: ["Unequal", "Curved", "Zero", "Equal"], answer: "Equal", hint: "Like a squished square, all four sides of a rhombus must be identical in length.", fact: "Did you know? A square is a special rhombus with 90-degree right angles!" },
      { question: "Which shape has 8 straight sides like a stop sign?", shape: "octagon", options: ["Octagon", "Hexagon", "Square", "Pentagon"], answer: "Octagon", hint: "'Octo' means eight (like an octopus with 8 arms). An 8-sided shape is an octagon.", fact: "Did you know? 'Octo' means eight! An octopus has 8 arms, and an octagon has 8 sides!" }
    ],
    2: [
      { question: "Which 3D solid has 6 flat square faces like a toy block?", shape: "cube", options: ["Sphere", "Cone", "Cube", "Cylinder"], answer: "Cube", hint: "A 3D box where every single face is a flat square is called a cube.", fact: "Did you know? Sugar and salt crystals naturally form tiny cubes when magnified!" },
      { question: "Which 3D shape is completely round like an orange?", shape: "sphere", options: ["Cone", "Cylinder", "Cube", "Sphere"], answer: "Sphere", hint: "A 3D solid that is completely round from every single angle is a sphere.", fact: "Did you know? A sphere has no corners and no edges, so it rolls in every direction!" },
      { question: "A drinking glass or soda can has the 3D shape of a:", shape: "cylinder", options: ["Cylinder", "Sphere", "Pyramid", "Cube"], answer: "Cylinder", hint: "It has two flat circular ends joined by a smooth round curved tube: a cylinder.", fact: "Did you know? A cylinder has 2 flat circular faces and 1 smooth curved surface!" },
      { question: "An ice-cream cone or birthday party hat is a:", shape: "cone", options: ["Sphere", "Cone", "Cube", "Cylinder"], answer: "Cone", hint: "It has a circular base that narrows smoothly upward to a single pointy tip: a cone.", fact: "Did you know? A cone has 1 flat circle base and tapers up to a single point called the apex!" },
      { question: "How many corners (vertices) does a cube have?", shape: "cube", options: ["12", "6", "4", "8"], answer: "8", hint: "Count 4 corners on the top square and 4 corners on the bottom square: 4 + 4 = 8 corners.", fact: "Did you know? A cube has 6 faces, 8 corners, and 12 straight edges!" },
      { question: "How many flat circular faces does a cylinder have?", shape: "cylinder", options: ["2", "1", "0", "3"], answer: "2", hint: "Count the flat top circle and the flat bottom circle: exactly 2 circular faces.", fact: "Did you know? If you peel the curved side off a cylinder, it unrolls into a rectangle!" },
      { question: "Can a sphere be stacked on top of another sphere?", shape: "sphere", options: ["Always", "Yes, easily", "No, it rolls off", "Only in the morning"], answer: "No, it rolls off", hint: "Spheres are curved everywhere without any flat base to rest upon, so they slide and roll off.", fact: "Did you know? Spheres roll off each other because they touch at only a single tiny point!" },
      { question: "Which 3D shape has triangular sides meeting at a point?", shape: "pyramid", options: ["Cylinder", "Cube", "Pyramid", "Sphere"], answer: "Pyramid", hint: "Think of ancient Egyptian monuments with sloping triangular sides meeting at a sharp peak: a pyramid.", fact: "Did you know? Pyramids are one of the sturdiest architectural structures ever designed!" }
    ]
  },

  4: {
    1: [
      { question: "A traffic stop sign has 8 sides. It is an:", shape: "octagon", options: ["Octagon", "Pentagon", "Decagon", "Hexagon"], answer: "Octagon", hint: "Count the 8 straight red edges around the stop sign: 'Octa' stands for eight (octagon).", fact: "Did you know? Stop signs are octagons so drivers can recognize them even from behind!" },
      { question: "A triangle with two equal sides is called:", shape: "triangle", options: ["Equilateral", "Isosceles", "Scalene", "Hexagon"], answer: "Isosceles", hint: "When exactly two sides (or 'legs') have the exact same length, it is an isosceles triangle.", fact: "Did you know? 'Isosceles' comes from ancient Greek words meaning 'equal legs'!" },
      { question: "Any 4-sided closed shape is called a:", shape: "rectangle", options: ["Pentagon", "Hexagon", "Quadrilateral", "Triangle"], answer: "Quadrilateral", hint: "'Quad' means four. Any polygon with 4 straight sides is classified as a quadrilateral.", fact: "Did you know? 'Quad' means four! Squares, rectangles, and kites are all quadrilaterals!" },
      { question: "A line from the center of a circle to its outer edge is the:", shape: "circle", options: ["Arc", "Diameter", "Chord", "Radius"], answer: "Radius", hint: "Think of a bicycle spoke going from the middle hub to the rim: that distance is the radius.", fact: "Did you know? 'Radius' is Latin for the spoke of a chariot wheel!" },
      { question: "A shape can be divided into two matching halves by a line of:", shape: "square", options: ["Diameter", "Symmetry", "Perimeter", "Volume"], answer: "Symmetry", hint: "A line that cuts a shape so both sides mirror each other perfectly is a line of symmetry.", fact: "Did you know? Human faces and butterflies have bilateral symmetry!" },
      { question: "What is the sum of all 3 angles inside any triangle?", shape: "triangle", options: ["270 degrees", "360 degrees", "180 degrees", "90 degrees"], answer: "180 degrees", hint: "Add the 3 interior angles of any triangle together: they always total exactly 180 degrees (a straight line).", fact: "Did you know? No matter how big or skewed a triangle is, its angles always add to 180°!" },
      { question: "A 4-sided shape with opposite parallel sides is a:", shape: "diamond", options: ["Triangle", "Pentagon", "Circle", "Parallelogram"], answer: "Parallelogram", hint: "When both pairs of opposite sides run parallel without ever meeting, it is a parallelogram.", fact: "Did you know? A slanted rectangle is a parallelogram!" },
      { question: "How many equal equilateral triangles make up a hexagon?", shape: "hexagon", options: ["6", "8", "4", "5"], answer: "6", hint: "From the center point of a regular hexagon, connect lines to each of the 6 corners to form 6 triangles.", fact: "Did you know? Drawing 3 lines through the center of a hexagon creates 6 equal triangles!" }
    ],
    2: [
      { question: "How many straight edges does a cube have?", shape: "cube", options: ["8", "16", "12", "6"], answer: "12", hint: "Count 4 edges around the top face, 4 around the bottom face, and 4 upright edges: 4 + 4 + 4 = 12 edges.", fact: "Did you know? Every edge of a cube is where two flat square faces meet!" },
      { question: "Earth is shaped like a sphere, but slightly flatter at the:", shape: "sphere", options: ["Oceans", "Equator", "Clouds", "Poles"], answer: "Poles", hint: "Because our planet spins continuously, it bulges at the equator and flattens slightly at the North and South Poles.", fact: "Did you know? Earth's spin causes a slight bulge at the equator, making it an oblate spheroid!" },
      { question: "If you cut a cylinder horizontally, the cross-section is a:", shape: "cylinder", options: ["Circle", "Square", "Triangle", "Star"], answer: "Circle", hint: "Slicing across parallel to the top and bottom circles reveals another identical flat circle.", fact: "Did you know? Every horizontal slice through a cylinder produces an identical circle!" },
      { question: "A kitchen funnel or megaphone has the 3D shape of a:", shape: "cone", options: ["Sphere", "Cone", "Cylinder", "Cube"], answer: "Cone", hint: "A shape that widens smoothly from a narrow hole to a wide circular opening is conical (a cone).", fact: "Did you know? Cones channel sound waves outward, which is why megaphones work so well!" },
      { question: "A square pyramid has a square base and how many triangular faces?", shape: "pyramid", options: ["3", "5", "6", "4"], answer: "4", hint: "One triangular wall rises from each of the 4 edges of the square base: 4 triangular faces.", fact: "Did you know? A square pyramid has 5 faces in total: 1 square bottom + 4 triangular sides!" },
      { question: "The flat 2D pattern that folds up into a 3D shape is a:", shape: "cube", options: ["Net", "Frame", "Blanket", "Sheet"], answer: "Net", hint: "A flattened folding diagram of a solid geometric shape is called its net.", fact: "Did you know? There are exactly 11 different 2D nets that can fold into a cube!" },
      { question: "Which 3D shape can both roll smoothly and slide flat?", shape: "cylinder", options: ["Star", "Cylinder", "Sphere", "Cube"], answer: "Cylinder", hint: "It can slide on its flat round face and roll forward along its curved side: a cylinder.", fact: "Did you know? A cylinder rolls on its curved side and slides on its flat circular face!" },
      { question: "How many flat faces and corners does a sphere have?", shape: "sphere", options: ["2", "4", "0", "1"], answer: "0", hint: "A sphere is completely curved all around with zero flat planes, zero edges, and zero corners (0).", fact: "Did you know? A sphere has zero flat faces, zero edges, and zero corners!" }
    ]
  },

  5: {
    1: [
      { question: "A square's corner forms a right angle measuring exactly:", shape: "square", options: ["90 degrees", "60 degrees", "45 degrees", "180 degrees"], answer: "90 degrees", hint: "Think of the perpendicular corner of a book: a right angle is always exactly 90 degrees.", fact: "Did you know? Builders use 90-degree right angles so walls stand straight up!" },
      { question: "A triangle with one 90-degree right angle is a:", shape: "triangle", options: ["Acute triangle", "Right-angled triangle", "Obtuse triangle", "Equilateral triangle"], answer: "Right-angled triangle", hint: "Look for the square corner symbol (90°): any triangle containing a 90° angle is a right-angled triangle.", fact: "Did you know? Pythagoras discovered that in right triangles, a² + b² = c²!" },
      { question: "A straight line crossing completely across a circle through its center is the:", shape: "circle", options: ["Radius", "Chord", "Diameter", "Tangent"], answer: "Diameter", hint: "A line going all the way across through the middle is the diameter (equal to twice the radius).", fact: "Did you know? The diameter is always exactly twice as long as the radius!" },
      { question: "The interior angles of a regular hexagon are each:", shape: "hexagon", options: ["108 degrees", "90 degrees", "60 degrees", "120 degrees"], answer: "120 degrees", hint: "Total interior angles of a 6-sided shape equal (6 - 2) × 180° = 720°. Divide by 6 corners = 120 degrees.", fact: "Did you know? Because 120° divides 360° evenly, hexagons tessellate with zero gaps!" },
      { question: "What is the perimeter of a regular octagon with 5 cm sides?", shape: "octagon", options: ["35 cm", "40 cm", "30 cm", "45 cm"], answer: "40 cm", hint: "Perimeter is distance around all sides. An octagon has 8 equal sides: 8 sides × 5 cm = 40 cm.", fact: "Did you know? The perimeter is found by multiplying 8 sides by 5 cm = 40 cm!" },
      { question: "How many sides does a regular pentagon have?", shape: "pentagon", options: ["6", "8", "5", "7"], answer: "5", hint: "The prefix 'penta' means five. A regular pentagon consists of 5 equal sides.", fact: "Did you know? Okra slices, starfish, and apple cores naturally show 5-point pentagonal symmetry!" },
      { question: "The area of a rectangle is calculated by:", shape: "rectangle", options: ["Length + Width", "Length ÷ Width", "2 × (Length + Width)", "Length × Width"], answer: "Length × Width", hint: "Area measures the flat space inside. Multiply how long it is by how wide it is: Length × Width.", fact: "Did you know? Area tells us how many 1×1 unit squares fit inside a 2D boundary!" },
      { question: "Two straight lines that never cross no matter how far they go are:", shape: "rectangle", options: ["Parallel", "Diagonal", "Perpendicular", "Intersecting"], answer: "Parallel", hint: "Like railway tracks or opposite edges of a ruler, lines that remain equidistant and never touch are parallel.", fact: "Did you know? Train tracks are a classic real-world example of parallel lines!" }
    ],
    2: [
      { question: "The volume of a cube with side length 3 cm is:", shape: "cube", options: ["9 cm³", "12 cm³", "27 cm³", "18 cm³"], answer: "27 cm³", hint: "Volume of a cube is side × side × side: 3 × 3 × 3 = 9 × 3 = 27 cm³.", fact: "Did you know? Volume measures 3D capacity: 3 × 3 × 3 = 27 cubic centimeters!" },
      { question: "Which 3D shape encloses the maximum volume with minimum surface area?", shape: "sphere", options: ["Cone", "Cylinder", "Cube", "Sphere"], answer: "Sphere", hint: "Nature uses this shape for raindrops and bubbles because a sphere holds the most volume using the least surface.", fact: "Did you know? Soap bubbles form spheres because surface tension pulls them into the smallest surface area!" },
      { question: "The volume of a cylinder is base area multiplied by:", shape: "cylinder", options: ["Height", "Radius", "Width", "Perimeter"], answer: "Height", hint: "To find how much a cylinder holds, take the flat circular base area (πr²) and multiply by its Height.", fact: "Did you know? Pipes are cylindrical because fluids flow with minimum friction through circular tubes!" },
      { question: "Volcanoes often form over centuries in the 3D shape of a:", shape: "cone", options: ["Sphere", "Cone", "Cube", "Cylinder"], answer: "Cone", hint: "Lava and ash erupt and build up around the vent, tapering upward to a peak in the form of a cone.", fact: "Did you know? Japan's famous Mount Fuji is known worldwide for its symmetrical volcanic cone!" },
      { question: "How many total edges does a square pyramid have?", shape: "pyramid", options: ["6", "10", "12", "8"], answer: "8", hint: "Count 4 edges on the square base plus 4 sloping edges connecting to the apex: 4 + 4 = 8 edges.", fact: "Did you know? 4 edges form the base, and 4 edges meet at the top apex!" },
      { question: "Carbon atoms in super-strong graphene form sheets of:", shape: "hexagon", options: ["Hexagons", "Triangles", "Circles", "Squares"], answer: "Hexagons", hint: "Carbon atoms link into a flat honeycomb lattice composed of repeating 6-sided hexagons.", fact: "Did you know? Graphene is 200 times stronger than steel and made of hexagonal carbon rings!" },
      { question: "If a cube's total surface area is 24 cm², what is the area of 1 face?", shape: "cube", options: ["12 cm²", "4 cm²", "8 cm²", "6 cm²"], answer: "4 cm²", hint: "A cube has 6 identical square faces. Divide total surface area by 6: 24 ÷ 6 = 4 cm².", fact: "Did you know? Since a cube has 6 identical square faces, 24 ÷ 6 = 4 cm² per face!" },
      { question: "Grain silos on farms are shaped like cylinders primarily because:", shape: "cylinder", options: ["They prevent rain", "They look like squares", "They distribute pressure evenly", "They catch the wind"], answer: "They distribute pressure evenly", hint: "Round walls distribute outward pressure evenly without corners where grain can jam or exert dangerous stress.", fact: "Did you know? Circular walls eliminate weak corners, distributing grain pressure evenly!" }
    ]
  }
};

const getShapesLevelsForClass = (classNumber) => {
  const classKey = getNormalizedClassNumber(classNumber);
  const classBank = classShapesQuestionBank[classKey] || classShapesQuestionBank[1];

  const levelConfigs = [
    { id: 1, title: "LEVEL 1 — EASY", difficulty: "EASY", description: "EXPLORE AND IDENTIFY SHAPES." },
    { id: 2, title: "LEVEL 2 — MEDIUM", difficulty: "MEDIUM", description: "DISCOVER SIDES, CORNERS & REAL OBJECTS." },
  ];

  return levelConfigs.map((cfg) => {
    const rawQuestions = classBank[cfg.id] || [];
    return {
      ...cfg,
      exercises: rawQuestions.map((q, idx) => ({
        id: `c${classKey}-sh-l${cfg.id}-q${idx + 1}`,
        question: q.question,
        shape: q.shape,
        options: shuffleArray([...(q.options || [])]),
        answer: q.answer,
        hint: q.hint,
        fact: q.fact,
      })),
    };
  });
};

const createShuffledShapes = (classNumber) => {
  return getShapesLevelsForClass(classNumber);
};

const isValidPhoneNumber = (phone) => {
  return /^\d{10}$/.test(phone);
};

const isValidEmail = (email) => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
    email.trim()
  );
};


/* =======================================================
   DYSLEXIA DIAGNOSTIC ENGINE & CURATED RECOMMENDATIONS
   ======================================================= */

const DYSLEXIA_RECOMMENDATIONS = {
  visual_dyslexia: {
    typeId: "visual_dyslexia",
    name: "Visual / Surface Dyslexic Tendency",
    tag: "SURFACE & ORTHOGRAPHIC PROCESSING",
    badge: "eye",
    badgeColor: "#2563eb",
    bgColor: "#eff6ff",
    borderColor: "#93c5fd",
    strengths: [
      "Vivid three-dimensional spatial imagination",
      "Intuitive big-picture conceptual understanding",
      "Creative problem solving and holistic thinking"
    ],
    growthAreas: [
      "Letter orientation & directionality (reversing b/d, p/q)",
      "Visual orthographic word recognition (words with irregular spelling)",
      "Visual line tracking fatigue across crowded text"
    ],
    explanation:
      "Your child demonstrates strong spatial and conceptual thinking, but experienced hesitation or errors with visual letter orientation and shape symmetry. In surface/visual dyslexia, the brain naturally examines 2D letters as 3D objects, which can cause mirror reversals. Multi-sensory tactile tracing and visual anchor rules help lock in correct orientation.",
    videos: [
      {
        id: "v1",
        title: "How to Remember the Difference Between b and d",
        channel: "Nessy Learning",
        duration: "3 mins",
        description: "The famous 'bed' hand trick and animated story that permanently fixes b and d confusion for dyslexic kids.",
        url: "https://www.youtube.com/watch?v=WP1blvh1Z2Q",
        thumbnailColor: "#1e40af"
      },
      {
        id: "v2",
        title: "What is Dyslexia? (Animated Explanation)",
        channel: "TED-Ed",
        duration: "4 mins",
        description: "A fun, inspiring animation showing how dyslexic brains are uniquely wired for creativity and spatial gifts.",
        url: "https://www.youtube.com/watch?v=zafiGBrFkRM",
        thumbnailColor: "#b91c1c"
      },
      {
        id: "v3",
        title: "Visual Memory & Spelling Strategies for Dyslexia",
        channel: "BBC Teach",
        duration: "5 mins",
        description: "Animated mnemonic strategies to visualize word shapes and overcome letter flipping.",
        url: "https://www.youtube.com/watch?v=11r79zGwpQ4",
        thumbnailColor: "#047857"
      }
    ],
    exercises: [
      {
        title: "Sand & Shaving Cream Finger Tracing",
        icon: "edit",
        steps: [
          "Spread kinetic sand or shaving cream on a shallow baking tray.",
          "Have your child trace confusing letters (like 'b' and 'd') using their index finger while reciting the letter's sound aloud.",
          "Tactile sensory feedback permanently imprints correct letter motor patterns in the brain."
        ]
      },
      {
        title: "The 'BED' Two-Hand Visual Anchor",
        icon: "shapes",
        steps: [
          "Have your child make two fists with both thumbs pointing up.",
          "Bring the knuckles together: the left hand naturally forms the letter 'b', and the right forms 'd' (spelling B-E-D).",
          "Whenever unsure, making this quick hand gesture provides an instant physical anchor."
        ]
      },
      {
        title: "Colored Highlighting Ruler / Reading Window",
        icon: "eye",
        steps: [
          "Place a yellow or soft blue transparent reading strip over a line of text.",
          "This isolates one sentence at a time, preventing words from appearing to 'drift' or jump lines."
        ]
      }
    ],
    books: [
      "Hank Zipzer: The World's Greatest Underachiever by Henry Winkler",
      "Here's Hank: Bookmarks Are People Too! by Henry Winkler & Lin Oliver",
      "Percy Jackson & The Olympians: The Lightning Thief by Rick Riordan"
    ],
    accommodations: [
      "Use OpenDyslexic or Atkinson Hyperlegible fonts with generous line spacing (1.5x).",
      "Allow tactile tools and scrap paper for visual anchoring before answering.",
      "Praise creative and spatial problem-solving to protect learning confidence."
    ]
  },

  phonological_dyslexia: {
    typeId: "phonological_dyslexia",
    name: "Phonological / Auditory Dyslexic Tendency",
    tag: "PHONEMIC AWARENESS & SOUND BLENDING",
    badge: "mic",
    badgeColor: "#7c3aed",
    bgColor: "#f5f3ff",
    borderColor: "#c4b5fd",
    strengths: [
      "Rich listening vocabulary and verbal comprehension",
      "Expressive oral storytelling and discussions",
      "High emotional intelligence and empathy"
    ],
    growthAreas: [
      "Isolating middle vowel sounds (e.g. C_T, D_G)",
      "Blending individual phonemes into words smoothly",
      "Rhyming word family recognition and phonetic spelling"
    ],
    explanation:
      "The student demonstrates bright comprehension, but shows difficulty segmenting and blending individual speech sounds (phonemes) into written words. Phonological dyslexia is the most common form of reading difference. Using rhythmic clapping, physical syllable tapping, and multi-sensory sound-letter games accelerates phonetic mastery.",
    videos: [
      {
        id: "v4",
        title: "Phonics Blending Made Easy - Letters & Word Magic",
        channel: "Alphablocks Official (BBC)",
        duration: "5 mins",
        description: "Fun animated blocks hold hands to teach how phonemes combine into words step-by-step.",
        url: "https://www.youtube.com/watch?v=F3G8a9tF684",
        thumbnailColor: "#7c3aed"
      },
      {
        id: "v5",
        title: "Hairy Phonics - Magic E & Long Vowel Sounds",
        channel: "Nessy Learning",
        duration: "4 mins",
        description: "Hairy monsters show how the silent 'e' at the end makes the vowel say its own name.",
        url: "https://www.youtube.com/watch?v=b4O5u_V70oA",
        thumbnailColor: "#c026d3"
      },
      {
        id: "v6",
        title: "Rhyming Words for Kids - Fun Phonics Animation",
        channel: "Kids Academy",
        duration: "4 mins",
        description: "Animated cartoon lesson showing word families (cat/hat/bat, tree/bee) with audio cues.",
        url: "https://www.youtube.com/watch?v=cSPmAByNmR8",
        thumbnailColor: "#ea580c"
      }
    ],
    exercises: [
      {
        title: "Finger Tap & Blend (Orton-Gillingham)",
        icon: "mic",
        steps: [
          "Tap the thumb to the index finger for sound 1 (e.g., /c/), middle finger for sound 2 (/a/), and ring finger for sound 3 (/t/).",
          "Sweep all fingers across the palm in a smooth motion to say the complete word: 'CAT!'.",
          "Translating abstract sounds into physical finger motions builds automaticity."
        ]
      },
      {
        title: "Syllable Clapping & Stomping Rhythm Game",
        icon: "volume",
        steps: [
          "Say a word together aloud and clap hands or stomp feet on each beat (e.g., wa-ter-mel-on = 4 claps).",
          "Helps children feel where words break apart into smaller manageable chunks."
        ]
      },
      {
        title: "Mirror Mouth Watching",
        icon: "book",
        steps: [
          "Hold a pocket mirror and watch how the lips, teeth, and tongue move when pronouncing tricky sounds (like 'th', 'ch', 'sh', 'f').",
          "Seeing mouth shapes gives visual confirmation of phonetic differences."
        ]
      }
    ],
    books: [
      "Dog Man series by Dav Pilkey (high picture support, comic format)",
      "InvestiGators by John Patrick Green (full-color graphic novel)",
      "Frog and Toad Are Friends by Arnold Lobel"
    ],
    accommodations: [
      "Use text-to-speech audio read-aloud buttons whenever available.",
      "Break long reading tasks into short 5-minute sprints.",
      "Never ask the child to read unfamiliar text aloud unexpectedly in front of peers."
    ]
  },

  dyscalculia: {
    typeId: "dyscalculia",
    name: "Dyscalculia / Math Dyslexic Tendency",
    tag: "NUMBER SENSE & ARITHMETIC SEQUENCING",
    badge: "calculator",
    badgeColor: "#d97706",
    bgColor: "#fffbeb",
    borderColor: "#fde68a",
    strengths: [
      "Intuitive practical logic and spatial reasoning",
      "Good comprehension of cause-and-effect concepts",
      "Hands-on architectural and visual-artistic abilities"
    ],
    growthAreas: [
      "Rapid retrieval of addition/subtraction math facts",
      "Number sequence tracking (counting backwards, patterns)",
      "Distinguishing mathematical operator symbols (+, -, ×, ÷)"
    ],
    explanation:
      "The student demonstrates good conceptual reasoning, but struggles with automatic mental calculations and number sequence jumps. Math dyslexia (dyscalculia) affects how the brain stores and retrieves abstract numbers. Using physical objects, visual number lines, and color-coded symbols makes math tangible and stress-free.",
    videos: [
      {
        id: "v7",
        title: "How Addition & Grouping Works Step-by-Step",
        channel: "Numberblocks Official",
        duration: "5 mins",
        description: "Living number blocks stack and combine visually, making quantity relationships instantly clear.",
        url: "https://www.youtube.com/watch?v=t89r5F1i378",
        thumbnailColor: "#b45309"
      },
      {
        id: "v8",
        title: "Basic Addition & Subtraction Visualized",
        channel: "Math Antics",
        duration: "6 mins",
        description: "Humorous, clear animation demonstrating place value columns and regrouping with ease.",
        url: "https://www.youtube.com/watch?v=mAvuom42NyY",
        thumbnailColor: "#0284c7"
      },
      {
        id: "v9",
        title: "Skip Counting & Number Line Patterns",
        channel: "Khan Academy Kids",
        duration: "4 mins",
        description: "Friendly animal animations demonstrating jumps of 2s, 5s, and 10s on a colorful number line.",
        url: "https://www.youtube.com/watch?v=V96_Pa4Bw5A",
        thumbnailColor: "#15803d"
      }
    ],
    exercises: [
      {
        title: "The Living Floor Number Line",
        icon: "calculator",
        steps: [
          "Use painter's tape to make a number line 0 to 20 on the floor.",
          "For addition (e.g. 5 + 3), have the child stand on 5 and jump forward 3 steps to land on 8.",
          "For subtraction (8 - 3), jump backward. Physical movement anchors number magnitude."
        ]
      },
      {
        title: "Lego Brick Ten-Frames",
        icon: "shapes",
        steps: [
          "Use 2x4 Lego bricks or egg carton cups to group items in sets of 10.",
          "Counting in physical groups of ten demystifies place value and multi-digit math."
        ]
      },
      {
        title: "Color-Coded Operation Highlighting",
        icon: "target",
        steps: [
          "Highlight '+' in green (go forward) and '-' in red (stop/take away).",
          "Color-coding prevents operator confusion under timed or visual pressure."
        ]
      }
    ],
    books: [
      "Sir Cumference and the First Round Table by Cindy Neuschwander",
      "Bedtime Math: A Fun Excuse to Stay Up Late by Laura Overdeck",
      "The Boy Who Loved Math: The Improbable Life of Paul Erdös"
    ],
    accommodations: [
      "Provide access to a visual reference card with multiplication/number line grids.",
      "Allow using scratch paper, fingers, or tokens without penalty.",
      "Focus on understanding the concept rather than timed computational speed."
    ]
  },

  spatial_geometry: {
    typeId: "spatial_geometry",
    name: "Visual-Spatial & Directional Processing Profile",
    tag: "2D/3D GEOMETRY & DIRECTIONAL SENSE",
    badge: "shapes",
    badgeColor: "#059669",
    bgColor: "#ecfdf5",
    borderColor: "#a7f3d0",
    strengths: [
      "High natural curiosity about how objects are constructed",
      "Creative artistic and building talents",
      "Strong memory for real-world landmarks and places"
    ],
    growthAreas: [
      "Distinguishing 2D flat shapes vs 3D solid volumes",
      "Counting vertices, edges, and faces without losing track",
      "Left/right and rotational orientation"
    ],
    explanation:
      "The student is an imaginative, hands-on visual learner. They occasionally confuse terminology like faces, edges, and corners when looking at flat 2D drawings of 3D objects. Hands-on modeling with playdough, toothpicks, and real-world household items makes geometric concepts concrete.",
    videos: [
      {
        id: "v10",
        title: "Shapes Song & 3D Solids Adventure",
        channel: "StoryBots (Netflix Jr)",
        duration: "3 mins",
        description: "Catchy animated musical journey exploring cubes, spheres, cones, and cylinders in nature.",
        url: "https://www.youtube.com/watch?v=8bO_iA-R-Xg",
        thumbnailColor: "#059669"
      },
      {
        id: "v11",
        title: "2D & 3D Shapes Mystery - Faces, Edges & Corners",
        channel: "Scratch Garden",
        duration: "4 mins",
        description: "Funny cartoon characters demonstrate the difference between flat shapes and 3D solids.",
        url: "https://www.youtube.com/watch?v=guNdJ5MtX1A",
        thumbnailColor: "#d97706"
      },
      {
        id: "v12",
        title: "Why Are Wheels Round & Honeycombs Hexagonal?",
        channel: "SciShow Kids",
        duration: "5 mins",
        description: "Engaging science animation showing why geometry works the way it does in nature.",
        url: "https://www.youtube.com/watch?v=68M2q0L6W3U",
        thumbnailColor: "#2563eb"
      }
    ],
    exercises: [
      {
        title: "Toothpick & Playdough 3D Sculpting",
        icon: "shapes",
        steps: [
          "Roll small playdough balls for corners (vertices) and use toothpicks for straight edges.",
          "Assemble a cube, triangle pyramid, and rectangular prism.",
          "Holding and feeling the vertices and edges eliminates confusion on 2D tests."
        ]
      },
      {
        title: "Household Shape Detective Safari",
        icon: "eye",
        steps: [
          "Give the child a clipboard with shape silhouettes.",
          "Hunt around the kitchen or living room to find matching items: soup cans (cylinders), oranges (spheres), cereal boxes (rectangular prisms).",
          "Connecting geometry to real life builds instant confidence."
        ]
      },
      {
        title: "Origami Paper Net Folding",
        icon: "layers",
        steps: [
          "Cut a cross-shaped 6-square net out of paper.",
          "Have the child fold the sides up into an open cube.",
          "Teaches how 2D flat patterns become 3D solid objects."
        ]
      }
    ],
    books: [
      "The Greedy Triangle by Marilyn Burns",
      "Round Is a Tortilla: A Book of Shapes by Roseanne Greenfield Thong",
      "Shapes That Roll by Karen Nagel"
    ],
    accommodations: [
      "Provide physical 3D shape blocks during geometry learning.",
      "Allow the student to point and trace boundaries with a finger.",
      "Highlight differences between 2D flat shapes and 3D solids."
    ]
  },

  emergent_mastery: {
    typeId: "emergent_mastery",
    name: "Strong Cognitive Mastery & High Accuracy Profile",
    tag: "WELL-COMPENSATED / EMERGENT PROGRESS",
    badge: "star",
    badgeColor: "#ca8a04",
    bgColor: "#fefce8",
    borderColor: "#fde047",
    strengths: [
      "High accuracy and strong focus under challenge",
      "Fast self-correction without frustration",
      "Confidence across both visual and verbal tasks"
    ],
    growthAreas: [
      "Expanding advanced vocabulary and multi-clause sentences",
      "Building sustained reading endurance with longer chapter books",
      "Creative writing organization and speed"
    ],
    explanation:
      "The student performed exceptionally well in this stage with minimal errors, showing strong compensatory habits and solid grasp of the concepts. Continuing to provide engaging, multisensory reading and creative problem-solving will keep their enthusiasm and fluency growing.",
    videos: [
      {
        id: "v13",
        title: "How to Master Reading Comprehension & Fluency",
        channel: "BBC Bitesize",
        duration: "4 mins",
        description: "Tips and tricks for young readers to boost comprehension and read smoothly.",
        url: "https://www.youtube.com/watch?v=11r79zGwpQ4",
        thumbnailColor: "#ca8a04"
      },
      {
        id: "v14",
        title: "The Superpowers of the Dyslexic Mind",
        channel: "Made By Dyslexia",
        duration: "4 mins",
        description: "Inspiring animation featuring astronauts, architects, and storytellers with dyslexic thinking.",
        url: "https://www.youtube.com/watch?v=zafiGBrFkRM",
        thumbnailColor: "#2563eb"
      }
    ],
    exercises: [
      {
        title: "Paired 'Popcorn' Reading",
        icon: "star",
        steps: [
          "Take turns reading a sentence or paragraph aloud back and forth.",
          "Keep it lively, fun, and fast-paced to build natural prosody and expression."
        ]
      },
      {
        title: "Story Mapping & Comic Strip Creation",
        icon: "edit",
        steps: [
          "Draw 3 comic panels showing the beginning, middle, and end of a favorite story.",
          "Encourages synthesis and sequential planning without writing fatigue."
        ]
      }
    ],
    books: [
      "The Wild Robot by Peter Brown",
      "Zoey and Sassafras: Dragons and Marshmallows by Asia Citro",
      "Amulet (Graphic Novel Series) by Kazu Kibuishi"
    ],
    accommodations: [
      "Continue offering positive reinforcement and celebrate creative thinking.",
      "Offer graphic novels and illustrated chapter books to maintain joy in reading."
    ]
  }
};

const analyzeStagePerformance = (stageKey, performance, totalQuestions, studentClass) => {
  const safeTotal = Math.max(1, totalQuestions || 1);
  const wrongCount = performance?.wrongAttempts || 0;
  const firstTrySuccess = performance?.firstTrySuccess || Math.max(0, safeTotal - wrongCount);
  const hintsCount = performance?.hintsUsed || 0;
  const accuracy = Math.min(100, Math.max(0, Math.round((firstTrySuccess / safeTotal) * 100)));

  let profileKey = "emergent_mastery";
  let severity = "Mild / Typical Progress";

  if (accuracy >= 85 && wrongCount <= 1) {
    profileKey = "emergent_mastery";
    severity = "Strong Compensatory Mastery (Score: " + accuracy + "%)";
  } else if (stageKey === "stage1") {
    profileKey = "visual_dyslexia";
    severity = wrongCount >= 4 ? "Notable Visual Reversal / Orthographic Pattern" : "Mild Visual Reversal Tendency";
  } else if (stageKey === "stage2") {
    profileKey = "phonological_dyslexia";
    severity = wrongCount >= 3 ? "Notable Rapid Naming & Speech Blending Challenge" : "Mild Phonological Fluency Hesitation";
  } else if (stageKey === "stage3") {
    profileKey = "phonological_dyslexia";
    severity = wrongCount >= 4 ? "Notable Phonemic Spelling & Sequencing Pattern" : "Mild Phonics & Spelling Hesitation";
  } else if (stageKey === "stage4") {
    profileKey = "dyscalculia";
    severity = wrongCount >= 4 ? "Notable Arithmetic Sequencing / Symbol Confusion" : "Mild Mental Calculation Hesitation";
  } else if (stageKey === "comprehension") {
    profileKey = wrongCount >= 3 ? "phonological_dyslexia" : "emergent_mastery";
    severity = wrongCount >= 3 ? "Reading Comprehension & Orthographic Working Memory Fatigue" : "Well-Compensated Reading Synthesis";
  } else if (stageKey === "shapes") {
    profileKey = "spatial_geometry";
    severity = wrongCount >= 4 ? "Notable 2D/3D Spatial & Directional Challenge" : "Mild Geometric Differentiation Pattern";
  }

  const profile = DYSLEXIA_RECOMMENDATIONS[profileKey] || DYSLEXIA_RECOMMENDATIONS.emergent_mastery;

  return {
    stageKey,
    studentClass,
    totalQuestions: safeTotal,
    firstTrySuccess,
    wrongCount,
    hintsCount,
    accuracy,
    severity,
    profile,
    analyzedAt: new Date().toISOString()
  };
};

const StageComprehensiveAnalysis = ({
  stageKey,
  stageName,
  performance,
  totalQuestions,
  studentName,
  studentClass,
  score,
  onRestart,
  onNextStage,
  nextStageTitle
}) => {
  const analysis = analyzeStagePerformance(stageKey, performance, totalQuestions, studentClass);
  const { profile, accuracy, wrongCount, hintsCount, firstTrySuccess, severity } = analysis;

  const handleReadAnalysis = () => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const textToRead = `${stageName} Diagnostic Analysis for ${studentName || "Student"}. Accuracy: ${accuracy} percent with ${wrongCount} incorrect attempts. Detected Profile: ${profile.name}. ${profile.explanation}`;
      const utterance = new SpeechSynthesisUtterance(textToRead);
      utterance.rate = 0.88;
      window.speechSynthesis.speak(utterance);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="diagnostic-container">
      {/* 1. TOP BANNER */}
      <div className="diagnostic-header-bar">
        <div>
          <span className="diagnostic-tag">Clinical & Educational Assessment</span>
          <h2 className="diagnostic-title">
            <IconBrain size={22} /> Comprehensive Performance & Cognitive Profile
          </h2>
          <p className="diagnostic-subtitle">
            Diagnostic insights, error frequency breakdown & personalized recommendations for <strong>{studentName || "Student"}</strong> (Class {studentClass})
          </p>
        </div>
        <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
          <button
            type="button"
            className="shape-fact-audio-btn read-aloud-btn"
            onClick={handleReadAnalysis}
            title="Read Analysis Aloud"
          >
            <IconVolume size={14} /> 🔊 Read Analysis
          </button>
          <button
            type="button"
            className="shape-fact-audio-btn print-hide"
            style={{ background: "#f8fafc", color: "#334155", borderColor: "#cbd5e1" }}
            onClick={handlePrint}
            title="Print or Save as PDF"
          >
            Print Report
          </button>
        </div>
      </div>

      {/* 2. PERFORMANCE METRICS ROW */}
      <div className="diagnostic-metrics-grid">
        <div className="metric-box">
          <div className="metric-icon"><IconTarget size={18} /></div>
          <div className="metric-val">{accuracy}%</div>
          <div className="metric-label">First-Try Accuracy</div>
        </div>

        <div className="metric-box">
          <div className="metric-icon"><IconCross size={18} /></div>
          <div className="metric-val">{wrongCount}</div>
          <div className="metric-label">Incorrect Attempts</div>
        </div>

        <div className="metric-box">
          <div className="metric-icon"><IconLightbulb size={18} /></div>
          <div className="metric-val">{hintsCount}</div>
          <div className="metric-label">Hints Used</div>
        </div>

        <div className="metric-box">
          <div className="metric-icon"><IconStar size={18} /></div>
          <div className="metric-val">{score} XP</div>
          <div className="metric-label">XP Earned</div>
        </div>
      </div>

      {/* 3. DYSLEXIA TENDENCY DIAGNOSTIC CARD */}
      <div
        className="diagnostic-profile-card"
        style={{
          background: profile.bgColor,
          borderColor: profile.borderColor,
        }}
      >
        <div className="profile-badge-row">
          <div className="profile-main-badge" style={{ background: profile.badgeColor }}>
            {renderCategoryIcon(profile.badge, 24)}
          </div>
          <div>
            <div className="profile-tag" style={{ color: profile.badgeColor }}>
              {profile.tag}
            </div>
            <h3 className="profile-name">{profile.name}</h3>
            <div className="profile-severity">
              Status: <strong>{severity}</strong>
            </div>
          </div>
        </div>

        <p className="profile-explanation">{profile.explanation}</p>

        <div className="profile-insights-columns">
          <div className="insight-box strengths-box">
            <h4 className="insight-title">
              Notable Cognitive Strengths
            </h4>
            <ul>
              {profile.strengths.map((st, i) => (
                <li key={i}>{st}</li>
              ))}
            </ul>
          </div>

          <div className="insight-box growth-box">
            <h4 className="insight-title">
              Targeted Focus Areas
            </h4>
            <ul>
              {profile.growthAreas.map((ga, i) => (
                <li key={i}>{ga}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* 4. RECOMMENDED YOUTUBE ANIMATION & LESSON VIDEOS */}
      <div className="diagnostic-section">
        <h3 className="section-heading">
          Recommended Visual & Video Lessons
        </h3>
        <p className="section-description">
          Curated animated lessons designed specifically for children with this cognitive profile:
        </p>
        <div className="video-recommendation-grid">
          {profile.videos.map((vid) => (
            <div key={vid.id} className="video-card">
              <div
                className="video-thumbnail-placeholder"
                style={{ background: vid.thumbnailColor }}
              >
                <span className="video-play-icon">▶</span>
                <span className="video-duration-pill">{vid.duration}</span>
              </div>
              <div className="video-info">
                <div className="video-channel-pill">{vid.channel}</div>
                <h4 className="video-title">{vid.title}</h4>
                <p className="video-desc">{vid.description}</p>
                <a
                  href={vid.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="video-watch-link"
                >
                  Watch Lesson on YouTube
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5. MULTI-SENSORY READING & KINESTHETIC EXERCISES */}
      <div className="diagnostic-section">
        <h3 className="section-heading">
          Multisensory 3-Step Tactile Interventions
        </h3>
        <p className="section-description">
          Multi-sensory home & classroom activities to strengthen neurological pathways:
        </p>
        <div className="exercise-recommendation-grid">
          {profile.exercises.map((ex, i) => (
            <div key={i} className="exercise-card">
              <div className="exercise-icon">{renderCategoryIcon(ex.icon, 18)}</div>
              <h4 className="exercise-title">{ex.title}</h4>
              <ol className="exercise-steps">
                {ex.steps.map((step, sIdx) => (
                  <li key={sIdx}>{step}</li>
                ))}
              </ol>
            </div>
          ))}
        </div>
      </div>

      {/* 6. READING SUGGESTIONS & ACCOMMODATIONS */}
      <div className="diagnostic-section">
        <div className="resources-two-column">
          <div className="resource-subcard">
            <h4 className="subcard-title"><IconBookOpen size={16} /> Recommended High-Readability Books</h4>
            <ul className="book-list">
              {profile.books.map((b, i) => (
                <li key={i} className="book-item">{b}</li>
              ))}
            </ul>
          </div>
          <div className="resource-subcard">
            <h4 className="subcard-title"><IconShieldCheck size={16} /> Classroom & Home Accommodations</h4>
            <ul className="accommodation-list">
              {profile.accommodations.map((acc, i) => (
                <li key={i} className="accommodation-item">{acc}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* 7. NAVIGATION ACTION BAR */}
      <div className="diagnostic-nav-bar print-hide">
        {onRestart && (
          <button
            type="button"
            className="secondary-button"
            onClick={onRestart}
          >
            Restart Assessment
          </button>
        )}
        {onNextStage && (
          <button
            type="button"
            className="save-button next-button"
            onClick={onNextStage}
          >
            {nextStageTitle || "CONTINUE TO NEXT STAGE →"}
          </button>
        )}
      </div>
    </div>
  );
};


function App() {
  const { t } = useLanguage();
  /* =======================================================
     PERFORMANCE & DYSLEXIA DIAGNOSTIC TRACKING
     ======================================================= */
  const [stagePerformance, setStagePerformance] = useState(() => {
    try {
      const raw = localStorage.getItem("dyslexiaQuestPerformance");
      if (raw) return JSON.parse(raw);
    } catch { }
    return {
      stage1: { firstTrySuccess: 0, wrongAttempts: 0, hintsUsed: 0 },
      stage2: { firstTrySuccess: 0, wrongAttempts: 0, hintsUsed: 0 },
      stage3: { firstTrySuccess: 0, wrongAttempts: 0, hintsUsed: 0 },
      stage4: { firstTrySuccess: 0, wrongAttempts: 0, hintsUsed: 0 },
      shapes: { firstTrySuccess: 0, wrongAttempts: 0, hintsUsed: 0 },
      comprehension: { firstTrySuccess: 0, wrongAttempts: 0, hintsUsed: 0 },
    };
  });

  const questionMistakeTrackerRef = useRef({});

  const recordStagePerformance = (stageKey, isCorrect, exercise, answer) => {
    setStagePerformance((prev) => {
      const stageData = prev[stageKey] || { firstTrySuccess: 0, wrongAttempts: 0, hintsUsed: 0 };
      const qId = exercise?.id || `${stageKey}_q_${Date.now()}`;

      let nextStageData;
      if (isCorrect) {
        const hadWrongBefore = Boolean(questionMistakeTrackerRef.current[qId]);
        nextStageData = {
          ...stageData,
          firstTrySuccess: hadWrongBefore ? stageData.firstTrySuccess : stageData.firstTrySuccess + 1,
        };
      } else {
        questionMistakeTrackerRef.current[qId] = true;
        nextStageData = {
          ...stageData,
          wrongAttempts: stageData.wrongAttempts + 1,
        };
      }

      const updated = {
        ...prev,
        [stageKey]: nextStageData,
      };

      try {
        localStorage.setItem("dyslexiaQuestPerformance", JSON.stringify(updated));
      } catch { }

      return updated;
    });
  };

  const recordHintUsed = (stageKey) => {
    setStagePerformance((prev) => {
      const stageData = prev[stageKey] || { firstTrySuccess: 0, wrongAttempts: 0, hintsUsed: 0 };
      const updated = {
        ...prev,
        [stageKey]: {
          ...stageData,
          hintsUsed: stageData.hintsUsed + 1,
        },
      };
      try {
        localStorage.setItem("dyslexiaQuestPerformance", JSON.stringify(updated));
      } catch { }
      return updated;
    });
  };

  const resetStagePerformance = (stageKey) => {
    setStagePerformance((prev) => {
      const updated = {
        ...prev,
        [stageKey]: { firstTrySuccess: 0, wrongAttempts: 0, hintsUsed: 0 },
      };
      try {
        localStorage.setItem("dyslexiaQuestPerformance", JSON.stringify(updated));
      } catch { }
      return updated;
    });
    questionMistakeTrackerRef.current = {};
  };

  const getInitialActiveStudent = () => {
    try {
      return getActiveProfile();
    } catch {
      return null;
    }
  };
  const initialActiveStudent = getInitialActiveStudent();
  const initialClassNumber = getNormalizedClassNumber(initialActiveStudent?.studentClass || "1");

  /* =======================================================
     STAGE 2 - READING STATES
     ======================================================= */

  const [stage2LevelIndex, setStage2LevelIndex] = useState(0);

  const [stage2ExerciseIndex, setStage2ExerciseIndex] = useState(0);

  const [stage2Message, setStage2Message] = useState("");

  const [stage2SpokenText, setStage2SpokenText] = useState("");

  const [stage2Accuracy, setStage2Accuracy] = useState(0);

  const [stage2Listening, setStage2Listening] = useState(false);

  const [stage2Score, setStage2Score] = useState(10);

  const stage2RecognitionRef = useRef(null);

  const [playStage2Levels, setPlayStage2Levels] =
    useState(() => createShuffledStage2(initialClassNumber));
  /* =======================================================
 STAGE 3 — WRITING & UNDERSTANDING
 ======================================================= */

  const [stage3LevelIndex, setStage3LevelIndex] =
    useState(0);

  const [stage3ExerciseIndex, setStage3ExerciseIndex] =
    useState(0);
  const [playStage3Levels, setPlayStage3Levels] = useState(() => getStage3LevelsForClass(initialClassNumber));

  const [stage3Answer, setStage3Answer] =
    useState("");

  const [stage3Message, setStage3Message] =
    useState("");

  const [stage3Hint, setStage3Hint] =
    useState("");

  const [stage3HintUsed, setStage3HintUsed] =
    useState(false);

  const [stage3Score, setStage3Score] =
    useState(10);

  /* =======================================================
     STAGE 4 — MATHS QUEST
     ======================================================= */
  const [stage4LevelIndex, setStage4LevelIndex] = useState(0);
  const [stage4ExerciseIndex, setStage4ExerciseIndex] = useState(0);
  const [playStage4Levels, setPlayStage4Levels] = useState(() => createShuffledStage4(initialClassNumber));
  const [stage4Answer, setStage4Answer] = useState("");
  const [stage4Message, setStage4Message] = useState("");
  const [stage4Hint, setStage4Hint] = useState("");
  const [stage4HintUsed, setStage4HintUsed] = useState(false);
  const [stage4EliminatedOptions, setStage4EliminatedOptions] = useState([]);
  const [stage4Score, setStage4Score] = useState(10);

  /* =======================================================
     STAGE 5 — SHAPES QUEST
     ======================================================= */
  const [shapesLevelIndex, setShapesLevelIndex] = useState(0);
  const [shapesExerciseIndex, setShapesExerciseIndex] = useState(0);
  const [playShapesLevels, setPlayShapesLevels] = useState(() => createShuffledShapes(initialClassNumber));
  const [shapesAnswer, setShapesAnswer] = useState("");
  const [shapesMessage, setShapesMessage] = useState("");
  const [shapesHint, setShapesHint] = useState("");
  const [shapesHintUsed, setShapesHintUsed] = useState(false);
  const [shapesEliminatedOptions, setShapesEliminatedOptions] = useState([]);
  const [shapesScore, setShapesScore] = useState(10);
  const [showShapeFact, setShowShapeFact] = useState(false);
  /* =======================================================
       MODULE 06 — READING COMPREHENSION STATE
       ======================================================= */
  const [compLevelIndex, setCompLevelIndex] = useState(0);
  const [compQuestionIndex, setCompQuestionIndex] = useState(0);
  const [playComprehensionLevels, setPlayComprehensionLevels] = useState(() => getComprehensionLevelsForClass(initialClassNumber));
  const [compAnswer, setCompAnswer] = useState("");
  const [compMessage, setCompMessage] = useState("");
  const [compHint, setCompHint] = useState("");
  const [compHintUsed, setCompHintUsed] = useState(false);
  const [compScore, setCompScore] = useState(10);

  /*
   HOME IS NOW THE FIRST PAGE
  */
  const getInitialScreen = () => {
    try {
      const h = window.location.hash.replace("#", "").trim();
      if (h === "teacher" || h === "analysis") return "teacher";
      if ([
        "stages", "profile", "profileCreated",
        "stage1", "stage1Report",
        "stage2", "stage2Report",
        "stage3", "stage3Report",
        "stage4", "stage4Report",
        "shapes", "shapesReport",
        "comprehension", "comprehensionReport",
        "levelReport"
      ].includes(h)) {
        return h;
      }
    } catch (e) { }
    return "home";
  };

  const [screen, setScreen] = useState(getInitialScreen);

  const [spatialPulse, setSpatialPulse] = useState(0);
  const [pulseType, setPulseType] = useState("cyan");
  const [fxTrigger, setFxTrigger] = useState(0);
  const [fxScore, setFxScore] = useState(100);
  const [fxCombo, setFxCombo] = useState(1);

  const trigger3DCelebration = (points = 100, isCorrect = true) => {
    if (isCorrect) {
      setSpatialPulse((p) => p + 1);
      setPulseType("emerald");
      setFxScore(points);
      setFxCombo((c) => Math.min(c + 1, 5));
      setFxTrigger((t) => t + 1);
      playSuccessChime();
    } else {
      setSpatialPulse((p) => p + 1);
      setPulseType("amber");
      setFxCombo(1);
      playLetterFlip();
    }
  };

  /* =======================================================
     PROFILE
     ======================================================= */

  const [allProfiles, setAllProfiles] = useState(() => {
    try {
      return getAllProfiles();
    } catch {
      return [];
    }
  });
  const [activeProfileId, setActiveProfileId] = useState(() => initialActiveStudent?.id || "");
  const [studentName, setStudentName] = useState(() => initialActiveStudent?.studentName || "");
  const [studentAge, setStudentAge] = useState(() => initialActiveStudent?.studentAge || "");
  const [studentClass, setStudentClass] = useState(() => String(initialClassNumber));
  // =======================================================
  // CLASS-BASED DIFFICULTY
  // =======================================================

  const selectedClass = getNormalizedClassNumber(studentClass);

  const classDifficulty = {
    1: "very-easy",
    2: "easy",
    3: "medium",
    4: "hard",
    5: "very-hard",
  }[selectedClass];

  const [schoolName, setSchoolName] =
    useState("");

  const [parentName, setParentName] =
    useState("");

  const [parentPhone, setParentPhone] =
    useState("");

  const [parentEmail, setParentEmail] =
    useState("");

  const [studentPhoto, setStudentPhoto] =
    useState("");

  const [saveMessage, setSaveMessage] =
    useState("");

  /* =======================================================
     AUDIO
     ORIGINAL AUDIO CODE - UNCHANGED
     ======================================================= */

  const [recording, setRecording] =
    useState(false);

  const recordingRef =
    useRef(false);

  const [audioURL, setAudioURL] =
    useState("");

  const [audioData, setAudioData] =
    useState("");

  const [audioError, setAudioError] =
    useState("");

  const audioContextRef =
    useRef(null);

  const microphoneRef =
    useRef(null);

  const processorRef =
    useRef(null);

  const analyserRef =
    useRef(null);

  const streamRef =
    useRef(null);

  const audioSamplesRef =
    useRef([]);

  /* =======================================================
     STAGE 1
     ======================================================= */

  const [levelIndex, setLevelIndex] =
    useState(0);

  const [exerciseIndex, setExerciseIndex] =
    useState(0);

  const [playStage1Levels, setPlayStage1Levels] =
    useState(() => createShuffledStage1(initialClassNumber));

  const syncStageLevelsForClass = (classNum) => {
    const norm = getNormalizedClassNumber(classNum);
    setPlayStage1Levels(createShuffledStage1(norm));
    setPlayStage2Levels(createShuffledStage2(norm));
    setPlayStage3Levels(getStage3LevelsForClass(norm));
    setPlayStage4Levels(createShuffledStage4(norm));
    setPlayShapesLevels(createShuffledShapes(norm));
    setPlayComprehensionLevels(getComprehensionLevelsForClass(norm));
  };

  useEffect(() => {
    syncStageLevelsForClass(selectedClass);
  }, [selectedClass]);

  const [stageAnswer, setStageAnswer] =
    useState("");

  const [stageMessage, setStageMessage] =
    useState("");

  // Hints are available only after an incorrect answer.
  // One hint can be used per question and costs 5 XP.
  const [stageHint, setStageHint] =
    useState("");

  const [hintUsed, setHintUsed] =
    useState(false);

  const [stageScore, setStageScore] =
    useState(10);

  /*
    Number of questions answered in Stage 1.
    This is separate from score because even a wrong
    answer counts as a completed question.
  */

  const [completedQuestions, setCompletedQuestions] =
    useState(0);

  const [completedLevelNumber, setCompletedLevelNumber] =
    useState(0);

  // =========================================================
  // SAVED LEARNING PROGRESS
  // Every Stage 1 answer is saved immediately.
  // Progress is stored separately for each class.
  // 3 levels × 9 questions = 27 questions per class.
  // =========================================================

  const createEmptyClassProgress = () => ({
    completedQuestionIds: [],
    correctQuestionIds: [],
    completedQuestions: 0,
    // Student starts Stage 1 with 10 XP.
    xp: 10,
    totalQuestions: 27,
    stageCompleted: false,
    lastAnsweredQuestionId: "",
    savedAt: null,
  });

  const createEmptyStage4ClassProgress = () => ({
    completedQuestionIds: [],
    correctQuestionIds: [],
    completedQuestions: 0,
    completedLevels: [],
    xp: 10,
    totalQuestions: 30,
    stageCompleted: false,
    lastAnsweredQuestionId: "",
    savedAt: null,
  });

  const createEmptyComprehensionClassProgress = () => ({
    completedQuestions: 0,
    correctQuestionIds: [],
    completedQuestionIds: [],
    completedLevels: [],
    stageCompleted: false,
    xp: 10,
  });

  const createEmptyShapesClassProgress = () => ({
    completedQuestionIds: [],
    correctQuestionIds: [],
    completedQuestions: 0,
    completedLevels: [],
    xp: 10,
    totalQuestions: 16,
    stageCompleted: false,
    lastAnsweredQuestionId: "",
    savedAt: null,
  });

  const createEmptyLearningProgress = () => ({
    stage1: {
      classes: {
        1: createEmptyClassProgress(),
        2: createEmptyClassProgress(),
        3: createEmptyClassProgress(),
        4: createEmptyClassProgress(),
        5: createEmptyClassProgress(),
      },
    },
    stage4: {
      classes: {
        1: createEmptyStage4ClassProgress(),
        2: createEmptyStage4ClassProgress(),
        3: createEmptyStage4ClassProgress(),
        4: createEmptyStage4ClassProgress(),
        5: createEmptyStage4ClassProgress(),
      },
    },
    shapes: {
      classes: {
        1: createEmptyShapesClassProgress(),
        2: createEmptyShapesClassProgress(),
        3: createEmptyShapesClassProgress(),
        4: createEmptyShapesClassProgress(),
        5: createEmptyShapesClassProgress(),
      },
    },
    comprehension: {
      classes: {
        1: createEmptyComprehensionClassProgress(),
        2: createEmptyComprehensionClassProgress(),
        3: createEmptyComprehensionClassProgress(),
        4: createEmptyComprehensionClassProgress(),
        5: createEmptyComprehensionClassProgress(),
      },
    },
  });

  const [savedProgress, setSavedProgress] = useState(() => {
    try {
      const saved = localStorage.getItem("dyslexiaQuestProgress");

      if (!saved) {
        return createEmptyLearningProgress();
      }

      const parsed = JSON.parse(saved);

      // Keep the new class-wise format.
      if (parsed?.stage1?.classes) {
        return parsed;
      }

      // Old progress format is intentionally not mixed with the new
      // class-wise question IDs because the old Stage 1 had 48 questions.
      const freshProgress = createEmptyLearningProgress();

      // Preserve Stage 2 if it already exists.
      if (parsed?.stage2) {
        freshProgress.stage2 = parsed.stage2;
      }

      return freshProgress;
    } catch (error) {
      console.error("Could not load saved progress:", error);
      return createEmptyLearningProgress();
    }
  });

  const getSavedStage1ClassProgress = (classNumber) => {
    const classKey = String(getNormalizedClassNumber(classNumber));

    return (
      savedProgress?.stage1?.classes?.[classKey] ||
      createEmptyClassProgress()
    );
  };

  const getSavedStage4ClassProgress = (classNumber) => {
    const classKey = String(getNormalizedClassNumber(classNumber));

    return (
      savedProgress?.stage4?.classes?.[classKey] ||
      createEmptyStage4ClassProgress()
    );
  };

  const getSavedComprehensionClassProgress = (classNumber) => {
    const classKey = String(getNormalizedClassNumber(classNumber));
    return (
      savedProgress?.comprehension?.classes?.[classKey] ||
      createEmptyComprehensionClassProgress()
    );
  };

  const saveComprehensionQuestionProgress = (
    classNumber,
    levelNumber,
    exercise,
    isCorrect,
    xpOverride = null
  ) => {
    const classKey = String(getNormalizedClassNumber(classNumber));
    const levels = getComprehensionLevelsForClass(classNumber);

    const rawSaved = localStorage.getItem("dyslexiaQuestProgress");
    let previousProgress;
    try {
      previousProgress = rawSaved ? JSON.parse(rawSaved) : createEmptyLearningProgress();
    } catch {
      previousProgress = createEmptyLearningProgress();
    }

    if (!previousProgress.comprehension?.classes) {
      previousProgress = {
        ...previousProgress,
        comprehension: {
          classes: {
            1: createEmptyComprehensionClassProgress(),
            2: createEmptyComprehensionClassProgress(),
            3: createEmptyComprehensionClassProgress(),
            4: createEmptyComprehensionClassProgress(),
            5: createEmptyComprehensionClassProgress(),
          },
        },
      };
    }

    const previousClassProgress = {
      ...createEmptyComprehensionClassProgress(),
      ...(previousProgress.comprehension.classes[classKey] || {}),
    };

    const completedQuestionIds = new Set(previousClassProgress.completedQuestionIds || []);
    const correctQuestionIds = new Set(previousClassProgress.correctQuestionIds || []);

    completedQuestionIds.add(exercise.id);
    if (isCorrect) {
      correctQuestionIds.add(exercise.id);
    }

    const completedLevels = levels
      .filter((level) => level.questions.every((item) => completedQuestionIds.has(item.id)))
      .map((level) => level.id);

    const completedQuestions = completedQuestionIds.size;
    const updatedXP =
      xpOverride !== null
        ? Math.max(0, Number(xpOverride) || 0)
        : previousClassProgress.xp;

    const updatedClassProgress = {
      ...previousClassProgress,
      completedQuestionIds: Array.from(completedQuestionIds),
      correctQuestionIds: Array.from(correctQuestionIds),
      completedQuestions,
      completedLevels,
      stageCompleted: levels.length > 0 && completedLevels.length === levels.length,
      xp: updatedXP,
    };

    const updatedProgress = {
      ...previousProgress,
      comprehension: {
        ...previousProgress.comprehension,
        classes: {
          ...previousProgress.comprehension.classes,
          [classKey]: updatedClassProgress,
        },
      },
    };

    try {
      localStorage.setItem("dyslexiaQuestProgress", JSON.stringify(updatedProgress));
    } catch { }

    setSavedProgress(updatedProgress);
    setCompScore(updatedClassProgress.xp);

    return updatedClassProgress;
  };

  const getSavedShapesClassProgress = (classNumber) => {
    const classKey = String(getNormalizedClassNumber(classNumber));

    return (
      savedProgress?.shapes?.classes?.[classKey] ||
      createEmptyShapesClassProgress()
    );
  };

  // =========================================================
  // SAVE EVERY STAGE 1 QUESTION IMMEDIATELY
  // =========================================================

  const saveStage1QuestionProgress = (
    classNumber,
    levelNumber,
    exercise,
    isCorrect,
    xpOverride = null
  ) => {
    const classKey = String(getNormalizedClassNumber(classNumber));
    const levels = getStage1LevelsForClass(classNumber);

    const rawSaved = localStorage.getItem(
      "dyslexiaQuestProgress"
    );

    let previousProgress;

    try {
      previousProgress = rawSaved
        ? JSON.parse(rawSaved)
        : createEmptyLearningProgress();
    } catch {
      previousProgress = createEmptyLearningProgress();
    }

    if (!previousProgress.stage1?.classes) {
      previousProgress = {
        ...createEmptyLearningProgress(),
        ...(previousProgress.stage2
          ? { stage2: previousProgress.stage2 }
          : {}),
      };
    }

    const previousClassProgress = {
      ...createEmptyClassProgress(),
      ...(previousProgress.stage1.classes[classKey] || {}),
    };

    const completedQuestionIds = new Set(
      previousClassProgress.completedQuestionIds || []
    );

    const correctQuestionIds = new Set(
      previousClassProgress.correctQuestionIds || []
    );

    // A question is saved as completed whether the child is right or wrong.
    completedQuestionIds.add(exercise.id);

    if (isCorrect) {
      correctQuestionIds.add(exercise.id);
    }

    const completedLevels = levels
      .filter((level) =>
        level.exercises.every((item) =>
          completedQuestionIds.has(item.id)
        )
      )
      .map((level) => level.id);

    const completedQuestions =
      completedQuestionIds.size;

    const updatedXP =
      xpOverride !== null
        ? Math.max(0, Number(xpOverride) || 0)
        : Number.isFinite(previousClassProgress.xp)
          ? previousClassProgress.xp
          : correctQuestionIds.size;

    const updatedClassProgress = {
      ...previousClassProgress,
      completedQuestionIds: Array.from(
        completedQuestionIds
      ),
      correctQuestionIds: Array.from(
        correctQuestionIds
      ),
      completedQuestions,
      completedLevels,
      totalQuestions: 27,
      stageCompleted:
        completedQuestions >= 27,
      xp: updatedXP,
      lastAnsweredQuestionId:
        exercise.id,
      lastAnsweredLevel:
        levelNumber,
      savedAt:
        new Date().toISOString(),
    };

    const updatedProgress = {
      ...previousProgress,
      stage1: {
        ...previousProgress.stage1,
        classes: {
          ...previousProgress.stage1.classes,
          [classKey]: updatedClassProgress,
        },
      },
    };

    localStorage.setItem(
      "dyslexiaQuestProgress",
      JSON.stringify(updatedProgress)
    );

    setSavedProgress(updatedProgress);

    setCompletedQuestions(
      updatedClassProgress.completedQuestions
    );

    setStageScore(
      updatedClassProgress.xp
    );

    console.log(
      "Stage 1 question progress saved:",
      {
        class: classKey,
        level: levelNumber,
        question: exercise.id,
        completedQuestions:
          updatedClassProgress.completedQuestions,
        totalQuestions: 27,
      }
    );

    return updatedClassProgress;
  };

  // =========================================================
  // SAVE LEVEL PROGRESS
  // Kept as a separate helper for clarity.
  // Question progress itself is already saved immediately.
  // =========================================================

  const saveLevelProgress = (levelNumber) => {
    const classProgress =
      getSavedStage1ClassProgress(selectedClass);

    console.log(
      `Level ${levelNumber} progress already saved question-by-question.`,
      classProgress
    );

    return classProgress;
  };

  // =========================================================
  // SAVE STAGE 4 QUESTION PROGRESS
  // =========================================================

  const saveStage4QuestionProgress = (
    classNumber,
    levelNumber,
    exercise,
    isCorrect,
    xpOverride = null
  ) => {
    const classKey = String(getNormalizedClassNumber(classNumber));
    const levels = getStage4LevelsForClass(classNumber);

    const rawSaved = localStorage.getItem("dyslexiaQuestProgress");

    let previousProgress;
    try {
      previousProgress = rawSaved ? JSON.parse(rawSaved) : createEmptyLearningProgress();
    } catch {
      previousProgress = createEmptyLearningProgress();
    }

    if (!previousProgress.stage4?.classes) {
      previousProgress = {
        ...previousProgress,
        stage4: {
          classes: {
            1: createEmptyStage4ClassProgress(),
            2: createEmptyStage4ClassProgress(),
            3: createEmptyStage4ClassProgress(),
            4: createEmptyStage4ClassProgress(),
            5: createEmptyStage4ClassProgress(),
          },
        },
      };
    }

    const previousClassProgress = {
      ...createEmptyStage4ClassProgress(),
      ...(previousProgress.stage4.classes[classKey] || {}),
    };

    const completedQuestionIds = new Set(previousClassProgress.completedQuestionIds || []);
    const correctQuestionIds = new Set(previousClassProgress.correctQuestionIds || []);

    completedQuestionIds.add(exercise.id);
    if (isCorrect) {
      correctQuestionIds.add(exercise.id);
    }

    const completedLevels = levels
      .filter((level) => level.exercises.every((item) => completedQuestionIds.has(item.id)))
      .map((level) => level.id);

    const completedQuestions = completedQuestionIds.size;
    const updatedXP =
      xpOverride !== null
        ? Math.max(0, Number(xpOverride) || 0)
        : previousClassProgress.xp;

    const updatedClassProgress = {
      ...previousClassProgress,
      completedQuestionIds: Array.from(completedQuestionIds),
      correctQuestionIds: Array.from(correctQuestionIds),
      completedQuestions,
      completedLevels,
      totalQuestions: 30,
      stageCompleted: completedQuestions >= 30,
      xp: updatedXP,
      lastAnsweredQuestionId: exercise.id,
      lastAnsweredLevel: levelNumber,
      savedAt: new Date().toISOString(),
    };

    const updatedProgress = {
      ...previousProgress,
      stage4: {
        ...previousProgress.stage4,
        classes: {
          ...previousProgress.stage4.classes,
          [classKey]: updatedClassProgress,
        },
      },
    };

    localStorage.setItem("dyslexiaQuestProgress", JSON.stringify(updatedProgress));
    setSavedProgress(updatedProgress);
    setStage4Score(updatedClassProgress.xp);

    return updatedClassProgress;
  };

  // =========================================================
  // SAVE STAGE 5 (SHAPES) QUESTION PROGRESS
  // =========================================================

  const saveShapesQuestionProgress = (
    classNumber,
    levelNumber,
    exercise,
    isCorrect,
    xpOverride = null
  ) => {
    const classKey = String(getNormalizedClassNumber(classNumber));
    const levels = getShapesLevelsForClass(classNumber);

    const rawSaved = localStorage.getItem("dyslexiaQuestProgress");

    let previousProgress;
    try {
      previousProgress = rawSaved ? JSON.parse(rawSaved) : createEmptyLearningProgress();
    } catch {
      previousProgress = createEmptyLearningProgress();
    }

    if (!previousProgress.shapes?.classes) {
      previousProgress = {
        ...previousProgress,
        shapes: {
          classes: {
            1: createEmptyShapesClassProgress(),
            2: createEmptyShapesClassProgress(),
            3: createEmptyShapesClassProgress(),
            4: createEmptyShapesClassProgress(),
            5: createEmptyShapesClassProgress(),
          },
        },
      };
    }

    const previousClassProgress = {
      ...createEmptyShapesClassProgress(),
      ...(previousProgress.shapes.classes[classKey] || {}),
    };

    const completedQuestionIds = new Set(previousClassProgress.completedQuestionIds || []);
    const correctQuestionIds = new Set(previousClassProgress.correctQuestionIds || []);

    completedQuestionIds.add(exercise.id);
    if (isCorrect) {
      correctQuestionIds.add(exercise.id);
    }

    const completedLevels = levels
      .filter((level) => level.exercises.every((item) => completedQuestionIds.has(item.id)))
      .map((level) => level.id);

    const completedQuestions = completedQuestionIds.size;
    const updatedXP =
      xpOverride !== null
        ? Math.max(0, Number(xpOverride) || 0)
        : previousClassProgress.xp;

    const updatedClassProgress = {
      ...previousClassProgress,
      completedQuestionIds: Array.from(completedQuestionIds),
      correctQuestionIds: Array.from(correctQuestionIds),
      completedQuestions,
      completedLevels,
      totalQuestions: 16,
      stageCompleted: completedQuestions >= 16,
      xp: updatedXP,
      lastAnsweredQuestionId: exercise.id,
      lastAnsweredLevel: levelNumber,
      savedAt: new Date().toISOString(),
    };

    const updatedProgress = {
      ...previousProgress,
      shapes: {
        ...previousProgress.shapes,
        classes: {
          ...previousProgress.shapes.classes,
          [classKey]: updatedClassProgress,
        },
      },
    };

    localStorage.setItem("dyslexiaQuestProgress", JSON.stringify(updatedProgress));
    setSavedProgress(updatedProgress);
    setShapesScore(updatedClassProgress.xp);

    return updatedClassProgress;
  };

  /* =======================================================
     LOAD PROFILE
     ======================================================= */

  useEffect(() => {
    try {
      const loadedProfiles = getAllProfiles();
      setAllProfiles(loadedProfiles);

      const active = getActiveProfile();
      if (active) {
        const targetClass = getNormalizedClassNumber(active.studentClass || "1");
        setActiveProfileId(active.id || "");
        setStudentName(active.studentName || "");
        setStudentAge(active.studentAge || "");
        setStudentClass(String(targetClass));
        setSchoolName(active.schoolName || "");
        setParentName(active.parentName || "");
        setParentPhone(active.parentPhone || "");
        setParentEmail(active.parentEmail || "");
        setStudentPhoto(active.studentPhoto || "");
        if (active.audioData) {
          setAudioData(active.audioData);
          setAudioURL(active.audioData);
        }
        syncStageLevelsForClass(targetClass);
      }
    } catch (error) {
      console.error("Could not load saved profiles:", error);
    }
  }, []);

  const handleSelectProfile = (profile) => {
    if (!profile) return;
    const targetClass = getNormalizedClassNumber(profile.studentClass || "1");
    setActiveProfileInStore(profile.id);
    setActiveProfileId(profile.id);
    setStudentName(profile.studentName || "");
    setStudentAge(profile.studentAge || "");
    setStudentClass(String(targetClass));
    setSchoolName(profile.schoolName || "");
    setParentName(profile.parentName || "");
    setParentPhone(profile.parentPhone || "");
    setParentEmail(profile.parentEmail || "");
    setStudentPhoto(profile.studentPhoto || "");
    if (profile.audioData) {
      setAudioData(profile.audioData);
      setAudioURL(profile.audioData);
    } else {
      setAudioData(null);
      setAudioURL("");
    }
    setAllProfiles(getAllProfiles());
    syncStageLevelsForClass(targetClass);
  };

  const handleDeleteProfile = (profileId) => {
    const updated = deleteProfileFromStore(profileId);
    setAllProfiles(updated);
    const active = getActiveProfile();
    if (active) {
      handleSelectProfile(active);
    }
  };

  const handleCreateNewProfile = () => {
    setActiveProfileId("");
    setStudentName("");
    setStudentAge("");
    setStudentClass("1");
    setSchoolName("");
    setParentName("");
    setParentPhone("");
    setParentEmail("");
    setStudentPhoto("");
    setAudioData(null);
    setAudioURL("");
    syncStageLevelsForClass(1);
    setScreen("profile");
  };

  /* =======================================================
     VOICE FEEDBACK
     ======================================================= */

  useEffect(() => {
    if (!stageMessage) {
      return;
    }

    if (
      !("speechSynthesis" in window)
    ) {
      return;
    }

    window.speechSynthesis.cancel();

    const exercise =
      playStage1Levels[levelIndex]
        ?.exercises[exerciseIndex];

    if (!exercise) {
      return;
    }

    let text = "";

    if (
      stageMessage.includes(
        "Correct"
      )
    ) {
      text =
        "Correct answer! Great job!";
    } else {
      text =
        `Wrong answer. The correct answer is ${exercise.answer}.`;
    }

    const utterance =
      new SpeechSynthesisUtterance(
        text
      );

    utterance.rate = 0.85;
    utterance.pitch = 1.05;
    utterance.volume = 1;

    window.speechSynthesis.speak(
      utterance
    );

    return () => {
      window.speechSynthesis.cancel();
    };
  }, [
    stageMessage,
    levelIndex,
    exerciseIndex,
    playStage1Levels,
  ]);

  /* =======================================================
     STAGE QUESTION AUDIO
     This is separate from the original profile WAV recorder.
     Matching questions are spoken automatically and can be replayed.
     ======================================================= */

  const playQuestionAudio = (text) => {
    if (!text || !("speechSynthesis" in window)) {
      return;
    }

    window.speechSynthesis.cancel();

    const utterance =
      new SpeechSynthesisUtterance(text);

    utterance.rate = 0.75;
    utterance.pitch = 1.1;
    utterance.volume = 1;

    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    if (screen !== "stage1") {
      return;
    }

    const exercise =
      playStage1Levels[levelIndex]
        ?.exercises[exerciseIndex];

    if (!exercise || exercise.type !== "matching") {
      return;
    }

    const spokenText =
      exercise.spoken ||
      exercise.left ||
      exercise.visual;

    if (!spokenText) {
      return;
    }

    const timer = setTimeout(() => {
      playQuestionAudio(spokenText);
    }, 250);

    return () => {
      clearTimeout(timer);
      window.speechSynthesis?.cancel();
    };
  }, [
    screen,
    levelIndex,
    exerciseIndex,
    playStage1Levels,
  ]);

  /* =======================================================
     PHOTO
     ======================================================= */

  const handlePhotoUpload = (
    event
  ) => {
    const file =
      event.target.files?.[0];

    if (!file) {
      return;
    }

    if (
      !file.type.startsWith(
        "image/"
      )
    ) {
      setSaveMessage(
        "PLEASE SELECT AN IMAGE FILE."
      );

      return;
    }

    const reader =
      new FileReader();

    reader.onload = () => {
      setStudentPhoto(
        reader.result
      );
    };

    reader.readAsDataURL(file);
  };

  /* =======================================================
     START RECORDING
     ORIGINAL AUDIO CODE - UNCHANGED
     ======================================================= */

  const startRecording =
    async () => {
      try {
        setAudioError("");
        setSaveMessage("");

        if (
          !navigator.mediaDevices
            ?.getUserMedia
        ) {
          setAudioError(
            "Your browser does not support microphone recording."
          );

          return;
        }

        const stream =
          await navigator.mediaDevices.getUserMedia(
            {
              audio: true,
            }
          );

        streamRef.current =
          stream;

        const AudioContextClass =
          window.AudioContext ||
          window.webkitAudioContext;

        if (!AudioContextClass) {
          throw new Error(
            "Web Audio API is not supported."
          );
        }

        const audioContext =
          new AudioContextClass();

        audioContextRef.current =
          audioContext;

        if (
          audioContext.state ===
          "suspended"
        ) {
          await audioContext.resume();
        }

        const microphone =
          audioContext.createMediaStreamSource(
            stream
          );

        microphoneRef.current =
          microphone;

        const analyser =
          audioContext.createAnalyser();

        analyserRef.current =
          analyser;

        const processor =
          audioContext.createScriptProcessor(
            4096,
            1,
            1
          );

        processorRef.current =
          processor;

        audioSamplesRef.current =
          [];

        recordingRef.current =
          true;

        processor.onaudioprocess =
          (event) => {
            if (
              !recordingRef.current
            ) {
              return;
            }

            const input =
              event.inputBuffer.getChannelData(
                0
              );

            audioSamplesRef.current.push(
              new Float32Array(input)
            );

            const output =
              event.outputBuffer.getChannelData(
                0
              );

            output.fill(0);
          };

        microphone.connect(
          analyser
        );

        analyser.connect(
          processor
        );

        processor.connect(
          audioContext.destination
        );

        setRecording(true);

        console.log(
          "WAV recording started."
        );
      } catch (error) {
        console.error(
          "Microphone recording error:",
          error
        );

        recordingRef.current =
          false;

        setRecording(false);

        if (
          error.name ===
          "NotAllowedError"
        ) {
          setAudioError(
            "Microphone permission was denied. Please allow microphone access."
          );
        } else {
          setAudioError(
            "Could not start recording. Please try again."
          );
        }
      }
    };

  /* =======================================================
     STOP RECORDING
     ORIGINAL AUDIO CODE - UNCHANGED
     ======================================================= */

  const stopRecording =
    async () => {
      try {
        recordingRef.current =
          false;

        setRecording(false);

        const audioContext =
          audioContextRef.current;

        const microphone =
          microphoneRef.current;

        const processor =
          processorRef.current;

        const analyser =
          analyserRef.current;

        if (microphone) {
          try {
            microphone.disconnect();
          } catch { }
        }

        if (analyser) {
          try {
            analyser.disconnect();
          } catch { }
        }

        if (processor) {
          try {
            processor.disconnect();
          } catch { }
        }

        if (streamRef.current) {
          streamRef.current
            .getTracks()
            .forEach(
              (track) =>
                track.stop()
            );

          streamRef.current =
            null;
        }

        const samples =
          audioSamplesRef.current;

        if (!samples.length) {
          setAudioError(
            "No audio was recorded. Please try again."
          );

          return;
        }

        let totalLength = 0;

        samples.forEach(
          (sample) => {
            totalLength +=
              sample.length;
          }
        );

        const mergedSamples =
          new Float32Array(
            totalLength
          );

        let offset = 0;

        samples.forEach(
          (sample) => {
            mergedSamples.set(
              sample,
              offset
            );

            offset +=
              sample.length;
          }
        );

        const sampleRate =
          audioContext?.sampleRate ||
          44100;

        const wavBlob =
          createWavBlob(
            mergedSamples,
            sampleRate
          );

        const wavURL =
          URL.createObjectURL(
            wavBlob
          );

        setAudioURL(wavURL);

        const dataURL =
          await blobToDataURL(
            wavBlob
          );

        setAudioData(
          dataURL
        );

        setAudioError("");

        console.log(
          "WAV recording created successfully."
        );

        console.log(
          "Audio size:",
          wavBlob.size,
          "bytes"
        );

        audioSamplesRef.current =
          [];

        if (audioContext) {
          try {
            await audioContext.close();
          } catch { }
        }

        audioContextRef.current =
          null;

        microphoneRef.current =
          null;

        processorRef.current =
          null;

        analyserRef.current =
          null;
      } catch (error) {
        console.error(
          "Stop recording error:",
          error
        );

        setAudioError(
          "The recording could not be completed. Please try again."
        );

        recordingRef.current =
          false;

        setRecording(false);
      }
    };

  /* =======================================================
     REMOVE AUDIO
     ORIGINAL AUDIO CODE - UNCHANGED
     ======================================================= */

  const removeRecording =
    () => {
      recordingRef.current =
        false;

      if (streamRef.current) {
        streamRef.current
          .getTracks()
          .forEach(
            (track) =>
              track.stop()
          );

        streamRef.current =
          null;
      }

      if (
        audioURL?.startsWith(
          "blob:"
        )
      ) {
        try {
          URL.revokeObjectURL(
            audioURL
          );
        } catch { }
      }

      setAudioURL("");
      setAudioData("");
      setAudioError("");

      audioSamplesRef.current =
        [];
    };

  /* =======================================================
     RECORD AGAIN
     ORIGINAL AUDIO CODE - UNCHANGED
     ======================================================= */

  const recordAgain =
    async () => {
      removeRecording();

      await new Promise(
        (resolve) =>
          setTimeout(
            resolve,
            150
          )
      );

      startRecording();
    };

  /* =======================================================
     SAVE PROFILE
     ======================================================= */

  const saveProfile =
    () => {
      if (
        !studentName.trim()
      ) {
        setSaveMessage(
          "PLEASE ENTER THE STUDENT'S NAME."
        );

        return;
      }

      if (!studentAge) {
        setSaveMessage(
          "PLEASE ENTER THE STUDENT'S AGE."
        );

        return;
      }
      const ageNumber = Number(studentAge);

      if (
        !studentAge ||
        !Number.isInteger(ageNumber) ||
        ageNumber < 4 ||
        ageNumber > 11
      ) {
        setSaveMessage(
          "INVALID AGE. AGE MUST BE BETWEEN 4 AND 11."
        );

        return;
      }
      if (
        !["1", "2", "3", "4", "5"].includes(studentClass)
      ) {
        setSaveMessage(
          "PLEASE SELECT A GRADE FROM 1 TO 5."
        );

        return;
      }

      if (
        !parentName.trim()
      ) {
        setSaveMessage(
          "PLEASE ENTER THE PARENT OR GUARDIAN'S NAME."
        );

        return;
      }
      if (!/^\d{10}$/.test(parentPhone)) {
        setSaveMessage(
          "INVALID PHONE NUMBER. ENTER EXACTLY 10 DIGITS."
        );

        return;
      }

      if (
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
          parentEmail.trim()
        )
      ) {
        setSaveMessage(
          "INVALID EMAIL FORMAT. PLEASE ENTER A VALID EMAIL ADDRESS."
        );

        return;
      }

      const profile = {
        id: activeProfileId || `profile_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        studentName: studentName.trim(),
        studentAge,
        studentClass,
        schoolName,
        parentName,
        parentPhone,
        parentEmail,
        studentPhoto,
        audioData,
        savedAt: new Date().toISOString(),
      };

      try {
        const { active, all } = saveProfileToStore(profile);
        setAllProfiles(all);
        setActiveProfileId(active.id);

        setSaveMessage(
          "STUDENT PROFILE SAVED SUCCESSFULLY!"
        );

        setTimeout(() => {
          setScreen(
            "profileCreated"
          );

          setSaveMessage("");
        }, 700);
      } catch (error) {
        console.error(
          "Profile save error:",
          error
        );

        setSaveMessage(
          "COULD NOT SAVE THE PROFILE. THE PHOTO OR RECORDING MAY BE TOO LARGE."
        );
      }
    };

  /* =======================================================
     NAVIGATION
     ======================================================= */

  const startProfileCreation =
    () => {
      setSaveMessage("");
      setScreen("profile");
    };

  const startAnalysis =
    () => {
      setScreen("analysis");
    };

  const enterStages =
    () => {
      setScreen("stages");
    };

  const renderAppHeader = (activeScreenKey = screen) => (
    <UniversalAppHeader
      currentScreen={activeScreenKey}
      onNavigate={(target) => {
        if (target === "stages") enterStages();
        else if (target === "profile") startProfileCreation();
        else setScreen(target);
      }}
      studentName={studentName}
      selectedClass={selectedClass}
      profiles={allProfiles}
      onSelectProfile={handleSelectProfile}
    />
  );

  const enterStageOne = () => {
    // Stage 1 uses the student's selected class.
    const classNumber = getNormalizedClassNumber(studentClass || selectedClass);

    // Create a fresh copy WITHOUT changing the question IDs.
    const freshLevels =
      createShuffledStage1(classNumber);

    setPlayStage1Levels(freshLevels);

    let storedProgress = null;
    let parsed = null;

    try {
      const saved =
        localStorage.getItem(
          "dyslexiaQuestProgress"
        );

      parsed =
        saved ? JSON.parse(saved) : null;

      storedProgress =
        parsed?.stage1?.classes?.[
        String(classNumber)
        ] || createEmptyClassProgress();
    } catch {
      storedProgress =
        createEmptyClassProgress();
    }

    // Give the student the 10 XP starting bonus only when this
    // class has no saved Stage 1 progress yet.
    if (
      !storedProgress.started &&
      !storedProgress.completedQuestions &&
      !(storedProgress.completedQuestionIds?.length)
    ) {
      storedProgress = {
        ...createEmptyClassProgress(),
        ...storedProgress,
        xp: 10,
        started: true,
        savedAt: new Date().toISOString(),
      };

      try {
        const progressToSave =
          parsed || createEmptyLearningProgress();

        progressToSave.stage1.classes[String(classNumber)] =
          storedProgress;

        localStorage.setItem(
          "dyslexiaQuestProgress",
          JSON.stringify(progressToSave)
        );
        setSavedProgress(progressToSave);
      } catch (error) {
        console.error("Could not save starting XP:", error);
      }
    }

    // Resume from the first unanswered question.
    let resumeLevel = 0;
    let resumeQuestion = 0;
    let foundUnanswered = false;

    for (
      let level = 0;
      level < freshLevels.length;
      level++
    ) {
      for (
        let question = 0;
        question <
        freshLevels[level].exercises.length;
        question++
      ) {
        const questionId =
          freshLevels[level].exercises[
            question
          ].id;

        if (
          !storedProgress.completedQuestionIds?.includes(
            questionId
          )
        ) {
          resumeLevel = level;
          resumeQuestion = question;
          foundUnanswered = true;
          break;
        }
      }

      if (foundUnanswered) {
        break;
      }
    }

    // If all 27 are already complete, show the report.
    if (!foundUnanswered) {
      setLevelIndex(2);
      setExerciseIndex(8);
      setStageAnswer("");
      setStageMessage("");
      setStageHint("");
      setHintUsed(false);
      setStageScore(
        Number.isFinite(storedProgress.xp) && storedProgress.xp > 0
          ? storedProgress.xp
          : (storedProgress.correctQuestionIds?.length ? storedProgress.correctQuestionIds.length * 3 : 10)
      );
      setCompletedQuestions(
        storedProgress.completedQuestions || 27
      );
      setCompletedLevelNumber(3);
      setScreen("stage1Report");
      return;
    }

    setLevelIndex(resumeLevel);
    setExerciseIndex(resumeQuestion);
    setStageAnswer("");
    setStageMessage("");
    setStageHint("");
    setHintUsed(false);
    setStageScore(
      Number.isFinite(storedProgress.xp) && storedProgress.xp > 0
        ? storedProgress.xp
        : (storedProgress.correctQuestionIds?.length ? storedProgress.correctQuestionIds.length * 3 : 10)
      );
    setCompletedQuestions(
      storedProgress.completedQuestions || 0
    );
    setCompletedLevelNumber(
      storedProgress.completedLevels?.length || 0
    );

    setScreen("stage1");
  };

  /* =======================================================
     ENTER STAGE 2
     ======================================================= */

  const enterStageTwo = () => {
    window.speechSynthesis?.cancel();

    const classNumber = getNormalizedClassNumber(studentClass || selectedClass);
    setPlayStage2Levels(createShuffledStage2(classNumber));

    setStage2LevelIndex(0);
    setStage2ExerciseIndex(0);
    setStage2Message("");
    setStage2SpokenText("");
    setStage2Accuracy(0);
    setStage2Listening(false);
    setStage2Score(10);
    resetStagePerformance("stage2");

    setScreen("stage2");
  };

  /* =======================================================
     ENTER STAGE 3
     ======================================================= */

  const enterStageThree = () => {
    window.speechSynthesis?.cancel();

    if (stage2RecognitionRef.current) {
      try {
        stage2RecognitionRef.current.stop();
      } catch { }
    }

    const classNumber = getNormalizedClassNumber(studentClass || selectedClass);
    setPlayStage3Levels(getStage3LevelsForClass(classNumber));
    setStage3LevelIndex(0);
    setStage3ExerciseIndex(0);
    setStage3Answer("");
    setStage3Message("");
    setStage3Hint("");
    setStage3HintUsed(false);
    setStage3Score(10);
    setScreen("stage3");
  };

  /* =======================================================
     STAGE 4 — MATHS QUEST HANDLERS
     ======================================================= */

  const enterStageFour = () => {
    window.speechSynthesis?.cancel();

    if (stage2RecognitionRef.current) {
      try {
        stage2RecognitionRef.current.stop();
      } catch { }
    }

    const classNumber = getNormalizedClassNumber(studentClass || selectedClass);
    const levels = createShuffledStage4(classNumber);
    setPlayStage4Levels(levels);

    const classProgress = getSavedStage4ClassProgress(classNumber);

    let resumeLevel = 0;
    let resumeQuestion = 0;
    let foundUnanswered = false;

    for (let l = 0; l < levels.length; l++) {
      for (let q = 0; q < levels[l].exercises.length; q++) {
        if (!classProgress.completedQuestionIds?.includes(levels[l].exercises[q].id)) {
          resumeLevel = l;
          resumeQuestion = q;
          foundUnanswered = true;
          break;
        }
      }
      if (foundUnanswered) break;
    }

    if (!foundUnanswered && (classProgress.completedQuestions >= 30 || classProgress.stageCompleted)) {
      setStage4LevelIndex(2);
      setStage4ExerciseIndex(levels[2].exercises.length - 1);
      setStage4Score(classProgress.xp > 0 ? classProgress.xp : 10);
      setScreen("stage4Report");
      return;
    }

    setStage4LevelIndex(resumeLevel);
    setStage4ExerciseIndex(resumeQuestion);
    setStage4Answer("");
    setStage4Message("");
    setStage4Hint("");
    setStage4HintUsed(false);
    setStage4EliminatedOptions([]);
    setStage4Score(classProgress.xp > 0 ? classProgress.xp : 10);
    setScreen("stage4");
  };

  const answerStageFourQuestion = (selectedOption) => {
    if (stage4Message && stage4Message.includes("Correct")) {
      return;
    }

    const currentLevel = playStage4Levels[stage4LevelIndex];
    const currentExercise = currentLevel?.exercises[stage4ExerciseIndex];
    if (!currentExercise) return;

    const isCorrect = selectedOption === currentExercise.answer;
    setStage4Answer(selectedOption);

    const classProgress = getSavedStage4ClassProgress(selectedClass);
    const alreadyCorrect = classProgress.correctQuestionIds?.includes(currentExercise.id);

    const nextXP = isCorrect && !alreadyCorrect ? stage4Score + 3 : stage4Score;
    setStage4Score(nextXP);

    saveStage4QuestionProgress(selectedClass, currentLevel.id, currentExercise, isCorrect, nextXP);
    recordStagePerformance("stage4", isCorrect, currentExercise, selectedOption);

    if (isCorrect) {
      setStage4Message("Correct! +3 XP earned.");
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
        const utt = new SpeechSynthesisUtterance("Correct answer! Great job!");
        utt.rate = 0.9;
        window.speechSynthesis.speak(utt);
      }
    } else {
      setStage4Message("Incorrect. Try again or consult the hint.");
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
        const utt = new SpeechSynthesisUtterance("That's not quite right. Try again or use a hint!");
        utt.rate = 0.9;
        window.speechSynthesis.speak(utt);
      }
    }
  };

  const getMathHint = (exercise) => {
    if (!exercise || !exercise.question) {
      return "Read the numbers carefully and break the question down step-by-step.";
    }
    const q = exercise.question;
    const qLower = q.toLowerCase();

    // Shape checks (if shapes appear in maths bank)
    const shapeMap = [
      { key: "round with no corners", hint: "A circle curves continuously with no corners or straight edges, like a coin." },
      { key: "3 sides", hint: "'Tri' means three! A triangle has 3 straight sides and 3 corners." },
      { key: "4 equal sides", hint: "A square has 4 sides that are all the exact same length." },
      { key: "night sky", hint: "Look for a star shape, which has 5 shiny points." },
      { key: "door or a book", hint: "A rectangle has 4 straight sides: two long sides and two short sides." },
      { key: "love and friendship", hint: "A heart shape has two rounded curves at the top and meets at a point at the bottom." },
      { key: "egg", hint: "An oval is curved like a circle, but gently elongated." },
      { key: "kite", hint: "A diamond (rhombus) is tilted on its corner like a kite in the breeze." },
      { key: "pizza", hint: "A whole uncut pizza is round like a circle." },
      { key: "watermelon", hint: "A wedge slice of watermelon has 3 straight edges meeting in a triangle." },
      { key: "screen", hint: "Phone, tablet, and TV screens are rectangular." },
      { key: "chessboard", hint: "A chessboard is perfectly square with 4 identical sides." },
      { key: "wheel", hint: "Wheels are circular so they can roll smoothly without bumping." },
      { key: "starfish", hint: "Starfish have 5 arms spreading out in a star shape." },
      { key: "storybook", hint: "Books have two long sides and two short sides: a rectangle." },
      { key: "strawberry", hint: "Strawberries narrow down to a point, resembling a heart." },
      { key: "sides does a triangle", hint: "'Tri' means 3! A triangle always has 3 sides." },
      { key: "corners does a square", hint: "A square has 4 corners (vertices), each forming a 90° right angle." },
      { key: "straight sides does a circle", hint: "A circle is a smooth continuous curve with 0 straight sides." },
      { key: "sides does a rectangle", hint: "Count the borders: 2 long + 2 short = 4 sides in total." },
      { key: "5 straight sides", hint: "'Penta' means five: a 5-sided shape is a pentagon." },
      { key: "stretched circle", hint: "An oval (ellipse) looks like a circle gently pulled outward." },
      { key: "slanted sides", hint: "A 4-sided shape with slanted equal sides is a diamond or rhombus." },
      { key: "6 straight sides", hint: "'Hexa' means six: a 6-sided polygon is a hexagon." },
      { key: "wall clock", hint: "Standard wall clocks are round circles so the hands can sweep around evenly." },
      { key: "brick", hint: "Bricks have two long sides and two short sides: a rectangle." },
      { key: "road hazard", hint: "Road warning signs use 3 pointed corners to make a triangle." },
      { key: "playing dice", hint: "A cube has 6 flat square faces (top, bottom, and 4 sides)." },
      { key: "honeybee", hint: "Bees build 6-sided hexagons because they pack together with zero wasted space." },
      { key: "rugby ball", hint: "A rugby ball is curved and elongated like an oval." },
      { key: "rhombus", hint: "A rhombus is a four-sided quadrilateral where all 4 sides are equal." },
      { key: "currency note", hint: "Paper currency notes are shaped like rectangles." },
      { key: "equal in length", hint: "In a regular square, all four sides have the exact same length." },
      { key: "equal and parallel", hint: "In a rectangle, opposite sides run parallel and have the same length." },
      { key: "equilateral", hint: "'Equi' means equal: an equilateral triangle has 3 equal sides." },
      { key: "corners does a pentagon", hint: "A pentagon has 5 sides and 5 corners." },
      { key: "sides does a hexagon", hint: "'Hex' means six: a hexagon has 6 straight sides." },
      { key: "outside edge of a circle", hint: "The distance around the outside curved edge of a circle is called its circumference." },
      { key: "circumference", hint: "The distance around the outside curved edge of a circle is called its circumference." },
      { key: "stop sign", hint: "'Octo' means 8: an 8-sided polygon is an octagon." },
      { key: "6 flat square faces", hint: "A 3D box with 6 square faces is a cube." },
      { key: "round like an orange", hint: "A 3D ball that is round from every direction is a sphere." },
      { key: "cylinder", hint: "A cylinder has two flat circular faces connected by a smooth curved tube." },
      { key: "drinking glass", hint: "A drinking glass has the 3D shape of a cylinder." },
      { key: "soda can", hint: "A soda can has the 3D shape of a cylinder." },
      { key: "ice-cream cone", hint: "A cone has a circular base that narrows up to a single point." },
      { key: "vertices) does a cube", hint: "4 corners on top and 4 corners on the bottom = 8 corners in a cube." },
      { key: "circular faces does a cylinder", hint: "A cylinder has 2 flat circular ends (top and bottom)." },
      { key: "stacked", hint: "Spheres roll off each other because they touch at only a single point." },
      { key: "triangular sides meeting at a point", hint: "A pyramid has sloping triangular sides meeting at a top apex." },
      { key: "two equal sides", hint: "An isosceles triangle has exactly two equal sides (legs)." },
      { key: "4-sided closed shape", hint: "'Quad' means four: any 4-sided closed shape is a quadrilateral." },
      { key: "center of a circle to its outer edge", hint: "A line from the center point to the outer edge is the radius." },
      { key: "two matching halves", hint: "A line of symmetry cuts a shape into two mirror-image halves." },
      { key: "all 3 angles inside any triangle", hint: "The three interior angles of any triangle always add up to 180 degrees." },
      { key: "opposite parallel sides", hint: "A 4-sided shape with both pairs of opposite sides parallel is a parallelogram." },
      { key: "triangles make up a hexagon", hint: "Six equilateral triangles fit together around a center point to form a hexagon." },
      { key: "edges does a cube have", hint: "4 top edges + 4 bottom edges + 4 vertical edges = 12 edges in a cube." },
      { key: "flatter at the", hint: "Earth's daily spin causes it to flatten slightly at the North and South Poles." },
      { key: "cross-section", hint: "Slicing horizontally through a cylinder creates a flat circle." },
      { key: "funnel", hint: "A funnel tapers down from wide to narrow in a conical shape (cone)." },
      { key: "square pyramid has a square base", hint: "One triangular wall rises from each of the 4 edges of the base: 4 triangular faces." },
      { key: "folds up into a 3d shape", hint: "A flat 2D pattern that folds into a 3D solid is called its net." },
      { key: "both roll smoothly and slide flat", hint: "A cylinder rolls on its curved body and slides on its flat circular face." },
      { key: "sphere have", hint: "A sphere has zero flat faces, zero edges, and zero corners (0)." },
      { key: "right angle", hint: "A perpendicular right angle forms a square corner measuring exactly 90 degrees." },
      { key: "right-angled triangle", hint: "Any triangle containing a 90° right angle is a right-angled triangle." },
      { key: "completely across a circle", hint: "A straight line crossing completely through the center from edge to edge is the diameter." },
      { key: "interior angles of a regular hexagon", hint: "Total interior angles equal (6 - 2) × 180° = 720°. Divided by 6 corners = 120 degrees each." },
      { key: "regular octagon with 5 cm", hint: "Perimeter is all 8 sides added: 8 sides × 5 cm = 40 cm." },
      { key: "regular pentagon have", hint: "'Penta' means five: a regular pentagon consists of 5 equal sides." },
      { key: "area of a rectangle", hint: "Area measures the flat space inside. Multiply Length by Width: Length × Width." },
      { key: "never cross", hint: "Lines that run side by side and never intersect are parallel lines." },
      { key: "cube with side length 3", hint: "Volume of a cube is side × side × side: 3 × 3 × 3 = 27 cm³." },
      { key: "maximum volume with minimum surface area", hint: "A sphere encloses the greatest volume inside the smallest surface area." },
      { key: "volume of a cylinder", hint: "Multiply the flat circular base area (πr²) by the Height of the cylinder." },
      { key: "volcanoes", hint: "Erupting lava and ash build up into a cone shape." },
      { key: "edges does a square pyramid", hint: "4 base edges + 4 sloping edges = 8 edges in a square pyramid." },
      { key: "graphene", hint: "Carbon atoms in graphene bond in a 6-sided hexagonal honeycomb lattice." },
      { key: "total surface area is 24", hint: "A cube has 6 identical square faces: divide 24 cm² by 6 = 4 cm²." },
      { key: "grain silos", hint: "Round cylindrical walls distribute outward grain pressure smoothly without corner stress." }
    ];

    for (let i = 0; i < shapeMap.length; i++) {
      if (qLower.includes(shapeMap[i].key)) {
        return shapeMap[i].hint;
      }
    }

    // 1. Addition
    const addMatch = q.match(/(\d+)\s*\+\s*(\d+)/);
    if (addMatch) {
      const a = parseInt(addMatch[1], 10);
      const b = parseInt(addMatch[2], 10);
      const bigger = Math.max(a, b);
      const smaller = Math.min(a, b);
      return `Addition Strategy: Start at ${bigger} (the larger number) and count forward ${smaller} more steps, or add the units and tens columns.`;
    }

    // 2. Subtraction
    const subMatch = q.match(/(\d+)\s*-\s*(\d+)/);
    if (subMatch) {
      const a = parseInt(subMatch[1], 10);
      const b = parseInt(subMatch[2], 10);
      return `Subtraction Strategy: Start with ${a} and take away ${b}, or ask: what number added to ${b} makes ${a}?`;
    }

    // 3. Multiplication
    const mulMatch = q.match(/(\d+)\s*[×*x]\s*(\d+)/);
    if (mulMatch) {
      const a = parseInt(mulMatch[1], 10);
      const b = parseInt(mulMatch[2], 10);
      return `Multiplication Strategy: Think of equal groups: ${a} groups of ${b}, or add ${a} repeated ${b} times.`;
    }

    // 4. Division
    const divMatch = q.match(/(\d+)\s*[÷/]\s*(\d+)/);
    if (divMatch) {
      const a = parseInt(divMatch[1], 10);
      const b = parseInt(divMatch[2], 10);
      return `Division Strategy: How many times does ${b} fit equally into ${a}? Think: ${b} × what = ${a}?`;
    }

    // 5. Sequence
    if (qLower.includes("comes after")) {
      const num = q.match(/\d+/);
      return num ? `Count forward by 1: start at ${num[0]} and take one step forward.` : "Count forward by 1 from the given number.";
    }
    if (qLower.includes("comes before")) {
      const num = q.match(/\d+/);
      return num ? `Count backward by 1: what number comes right before ${num[0]}?` : "Count backward by 1 from the given number.";
    }
    if (qLower.includes("complete:") || qLower.includes("comes next") || qLower.includes("pattern")) {
      return "Pattern Strategy: Look at the jump between neighboring numbers to find what is being added or multiplied each step.";
    }

    // 6. Comparison
    if (qLower.includes("greater") || qLower.includes("largest") || qLower.includes("biggest")) {
      return "Comparison Strategy: Compare the tens digit first; if they are the same, compare the ones digit to find the largest value.";
    }
    if (qLower.includes("smaller") || qLower.includes("smallest") || qLower.includes("least")) {
      return "Comparison Strategy: Look for the number with the smallest value, checking the highest place value first.";
    }

    // 7. Place Value
    if (qLower.includes("place value")) {
      return "Place Value Strategy: Look at where the digit sits: Units (1s), Tens (10s), Hundreds (100s), or Thousands (1000s).";
    }

    // 8. Fractions
    if (qLower.includes("half")) {
      return "Fraction Strategy: 'Half' means dividing the number into two equal parts (divide by 2).";
    }
    if (qLower.includes("quarter")) {
      return "Fraction Strategy: 'One quarter' (1/4) means dividing into four equal parts (divide by 4).";
    }
    if (qLower.includes("fraction")) {
      return "Fraction Strategy: The bottom number (denominator) is total equal parts; the top number (numerator) is parts counted.";
    }

    // 9. Percentages
    if (q.includes("%") || qLower.includes("percent")) {
      return "Percentage Strategy: Percent means 'out of 100'. 10% is dividing by 10, 25% is dividing by 4, and 50% is half.";
    }

    // 10. Geometry & Measurement inside Maths
    if (qLower.includes("perimeter")) {
      return "Perimeter Strategy: The perimeter is the total distance around the outside edge. Add the lengths of all sides together!";
    }
    if (qLower.includes("area")) {
      return "Area Strategy: Area is the flat surface covered inside. For a rectangle or square, multiply Length × Width.";
    }
    if (qLower.includes("volume")) {
      return "Volume Strategy: Volume measures 3D capacity. For a box or cube, multiply Length × Width × Height.";
    }
    if (qLower.includes("minute") && qLower.includes("hour")) {
      return "Time Strategy: Remember that there are 60 minutes in 1 whole hour.";
    }
    if (qLower.includes("hour") && qLower.includes("day")) {
      return "Time Strategy: There are 24 hours in one complete day.";
    }
    if (qLower.includes("centimetre") || qLower.includes("metre")) {
      return "Measurement Strategy: Remember: 1 metre (m) equals 100 centimetres (cm).";
    }
    if (qLower.includes("gram") || qLower.includes("kilogram")) {
      return "Measurement Strategy: Remember: 1 kilogram (kg) equals 1,000 grams (g).";
    }
    if (q.includes("₹") || qLower.includes("spend") || qLower.includes("cost") || qLower.includes("remain") || qLower.includes("left") || qLower.includes("pencil")) {
      return "Word Problem Strategy: Read the story: find what you start with, and whether items are being added, subtracted, or grouped.";
    }
    if (qLower.includes("average")) {
      return "Average Strategy: Add all the numbers together first, then divide that total by how many numbers there are.";
    }
    if (qLower.includes("factor")) {
      return "Factor Strategy: A factor is a whole number that divides into the target number evenly with no remainder.";
    }
    if (qLower.includes("double")) {
      return "Double Strategy: 'Double' means multiplying the number by 2 (or adding the number to itself).";
    }

    // 11. Language questions in Maths Bank
    if (qLower.includes("arrange")) {
      return "Spelling Strategy: Sound out the letters in order: first consonant sound, middle vowel sound, and ending sound.";
    }
    if (qLower.includes("makes sense")) {
      return "Sentence Strategy: Read each option aloud. A correct sentence has clear word order and makes complete sense.";
    }
    if (qLower.includes("rhymes")) {
      return "Rhyming Strategy: Listen for the ending vowel and consonant sound: words rhyme when their endings sound identical.";
    }
    if (qLower.includes("starts with") || qLower.includes("beginning sound")) {
      return "Phonics Strategy: Say the word aloud slowly and focus on the very first sound at the start of your mouth.";
    }
    if (qLower.includes("ends with")) {
      return "Phonics Strategy: Say the word aloud slowly and listen for the last sound at the end.";
    }
    if (qLower.includes("spelled correctly")) {
      return "Spelling Strategy: Sound out each syllable carefully and watch out for silent letters or tricky vowels.";
    }
    if (qLower.includes("long a") || qLower.includes("long e")) {
      return "Vowel Strategy: A long vowel says its own name (like 'ay' in cake or 'ee' in tree).";
    }
    if (qLower.includes("silent e")) {
      return "Phonics Strategy: Look for an 'e' at the end of the word that is quiet but changes the preceding vowel.";
    }
    if (qLower.includes("syllables")) {
      return "Syllable Strategy: Clap each beat in the word to count the syllables (like win-dow = 2 claps).";
    }
    if (qLower.includes("alphabetical order")) {
      return "Alphabet Strategy: Compare the first letter of each word to find which comes next in the A-Z alphabet.";
    }

    return "Read the numbers carefully, break the problem into simple steps, and check which option matches.";
  };

  const getStage3Hint = (exercise) => {
    if (!exercise) return "Look carefully at the letters and sound out the word.";
    const p = (exercise.prompt || exercise.question || "").toLowerCase();

    if (p.includes("comes after")) {
      const match = p.match(/after\s+([a-z])/i);
      const letter = match ? match[1].toUpperCase() : "the letter";
      return `Recite the alphabet: A, B, C, D... What letter comes right after ${letter}?`;
    }
    if (p.includes("comes before")) {
      const match = p.match(/before\s+([a-z])/i);
      const letter = match ? match[1].toUpperCase() : "the letter";
      return `Recite the alphabet: A, B, C, D... What letter comes right before ${letter}?`;
    }
    if (p.includes("complete") || p.includes("_")) {
      return "Sound out the word phonetically to see which vowel or letter makes a real, sensible word.";
    }
    if (p.includes("starts with") || p.includes("beginning sound")) {
      return "Say each word aloud slowly and listen to the very first sound at the start.";
    }
    if (p.includes("rhymes")) {
      return "Listen for words with the same ending sound (like cat and bat, or tree and bee).";
    }
    if (p.includes("spelled correctly")) {
      return "Read each option slowly and check each letter to see which one looks and sounds correctly spelled.";
    }
    if (p.includes("made from")) {
      return "Blend the letter sounds together from left to right to discover the word.";
    }
    if (p.includes("makes sense")) {
      return "Read each sentence aloud to check which one follows correct grammar and makes logical sense.";
    }
    if (p.includes("opposite")) {
      return "Think of the reverse meaning (for example: hot and cold, big and small).";
    }
    if (p.includes("noun")) {
      return "A noun is a naming word for a person, place, animal, or thing.";
    }
    if (p.includes("verb")) {
      return "A verb is an action word that tells what someone or something is doing.";
    }
    if (p.includes("adjective")) {
      return "An adjective is a describing word that tells us what something looks, feels, or behaves like.";
    }

    // Fallback if question is present
    if (exercise.question) {
      return getMathHint(exercise);
    }

    return "Look carefully at the word, sound out each letter, and think about the meaning.";
  };

  const useStageFourHint = () => {
    if (stage4HintUsed) {
      return;
    }

    if (stage4Score < 5) {
      setStage4Message("Incorrect. You need at least 5 XP to unlock a hint.");
      return;
    }

    const currentLevel = playStage4Levels[stage4LevelIndex];
    const currentExercise = currentLevel?.exercises[stage4ExerciseIndex];
    if (!currentExercise) return;

    const newXP = Math.max(0, stage4Score - 5);
    setStage4Score(newXP);
    setStage4HintUsed(true);
    setStage4EliminatedOptions([]);
    const hintText = getMathHint(currentExercise);
    setStage4Hint(hintText);
    setStage4Message("Hint unlocked (-5 XP). Strategy provided below.");

    saveStage4QuestionProgress(selectedClass, currentLevel.id, currentExercise, false, newXP);
    recordHintUsed("stage4");
  };

  const nextStageFourExercise = () => {
    window.speechSynthesis?.cancel();

    const currentLevel = playStage4Levels[stage4LevelIndex];
    if (!currentLevel) return;

    const isLastQuestionOfLevel = stage4ExerciseIndex === currentLevel.exercises.length - 1;

    if (!isLastQuestionOfLevel) {
      setStage4ExerciseIndex((prev) => prev + 1);
      setStage4Answer("");
      setStage4Message("");
      setStage4Hint("");
      setStage4HintUsed(false);
      setStage4EliminatedOptions([]);
      return;
    }

    if (stage4LevelIndex < playStage4Levels.length - 1) {
      setStage4LevelIndex((prev) => prev + 1);
      setStage4ExerciseIndex(0);
      setStage4Answer("");
      setStage4Message("");
      setStage4Hint("");
      setStage4HintUsed(false);
      setStage4EliminatedOptions([]);
      return;
    }

    // All 3 levels completed
    setScreen("stage4Report");
  };

  const restartStageFour = () => {
    const confirmed = window.confirm(
      `Restart Number Ninja Temple for Class ${selectedClass}? Your saved Maths progress for this class will be cleared.`
    );
    if (!confirmed) return;

    window.speechSynthesis?.cancel();

    const classKey = String(selectedClass);
    let currentProgress;
    try {
      currentProgress = JSON.parse(localStorage.getItem("dyslexiaQuestProgress") || "{}");
    } catch {
      currentProgress = createEmptyLearningProgress();
    }

    if (!currentProgress.stage4?.classes) {
      currentProgress.stage4 = { classes: {} };
    }

    currentProgress.stage4.classes[classKey] = {
      completedQuestionIds: [],
      correctQuestionIds: [],
      completedQuestions: 0,
      completedLevels: [],
      xp: 10,
      totalQuestions: 30,
      stageCompleted: false,
      savedAt: new Date().toISOString(),
    };

    localStorage.setItem("dyslexiaQuestProgress", JSON.stringify(currentProgress));
    setSavedProgress(currentProgress);

    setPlayStage4Levels(createShuffledStage4(selectedClass));
    setStage4LevelIndex(0);
    setStage4ExerciseIndex(0);
    setStage4Answer("");
    setStage4Message("");
    setStage4Hint("");
    setStage4HintUsed(false);
    setStage4EliminatedOptions([]);
    setStage4Score(10);
    resetStagePerformance("stage4");
    setScreen("stage4");
  };

  /* =======================================================
     STAGE 5 — SHAPES QUEST HANDLERS
     ======================================================= */

  const enterShapesStage = () => {
    window.speechSynthesis?.cancel();

    if (stage2RecognitionRef.current) {
      try {
        stage2RecognitionRef.current.stop();
      } catch { }
    }

    const classNumber = getNormalizedClassNumber(studentClass || selectedClass);
    const levels = createShuffledShapes(classNumber);
    setPlayShapesLevels(levels);

    const classProgress = getSavedShapesClassProgress(classNumber);

    let resumeLevel = 0;
    let resumeQuestion = 0;
    let foundUnanswered = false;

    for (let l = 0; l < levels.length; l++) {
      for (let q = 0; q < levels[l].exercises.length; q++) {
        if (!classProgress.completedQuestionIds?.includes(levels[l].exercises[q].id)) {
          resumeLevel = l;
          resumeQuestion = q;
          foundUnanswered = true;
          break;
        }
      }
      if (foundUnanswered) break;
    }

    if (!foundUnanswered && (classProgress.completedQuestions >= 16 || classProgress.stageCompleted)) {
      setShapesLevelIndex(1);
      setShapesExerciseIndex(levels[1].exercises.length - 1);
      setShapesScore(classProgress.xp > 0 ? classProgress.xp : 10);
      setScreen("shapesReport");
      return;
    }

    setShapesLevelIndex(resumeLevel);
    setShapesExerciseIndex(resumeQuestion);
    setShapesAnswer("");
    setShapesMessage("");
    setShapesHint("");
    setShapesHintUsed(false);
    setShapesEliminatedOptions([]);
    setShowShapeFact(false);
    setShapesScore(classProgress.xp > 0 ? classProgress.xp : 10);
    setScreen("shapes");
  };

  const answerShapesQuestion = (selectedOption) => {
    if (shapesMessage && shapesMessage.includes("Correct")) {
      return;
    }

    const currentLevel = playShapesLevels[shapesLevelIndex];
    const currentExercise = currentLevel?.exercises[shapesExerciseIndex];
    if (!currentExercise) return;

    const isCorrect = selectedOption === currentExercise.answer;
    setShapesAnswer(selectedOption);

    const classProgress = getSavedShapesClassProgress(selectedClass);
    const alreadyCorrect = classProgress.correctQuestionIds?.includes(currentExercise.id);

    const nextXP = isCorrect && !alreadyCorrect ? shapesScore + 3 : shapesScore;
    setShapesScore(nextXP);

    saveShapesQuestionProgress(selectedClass, currentLevel.id, currentExercise, isCorrect, nextXP);
    recordStagePerformance("shapes", isCorrect, currentExercise, selectedOption);

    // Show the fun shape fact upon answering
    setShowShapeFact(true);

    if (isCorrect) {
      setShapesMessage("Correct! +3 XP earned.");
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
        const utt = new SpeechSynthesisUtterance("Correct answer! Great job!");
        utt.rate = 0.9;
        window.speechSynthesis.speak(utt);
      }
    } else {
      setShapesMessage("Incorrect. Try again or consult the hint.");
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
        const utt = new SpeechSynthesisUtterance("That's not quite right. Try again or check the shape fact!");
        utt.rate = 0.9;
        window.speechSynthesis.speak(utt);
      }
    }
  };

  const useShapesHint = () => {
    if (shapesHintUsed) return;

    if (shapesScore < 5) {
      setShapesMessage("Incorrect. You need at least 5 XP to unlock a hint.");
      return;
    }

    const currentLevel = playShapesLevels[shapesLevelIndex];
    const currentExercise = currentLevel?.exercises[shapesExerciseIndex];
    if (!currentExercise) return;

    const newXP = Math.max(0, shapesScore - 5);
    setShapesScore(newXP);
    setShapesHintUsed(true);
    setShapesEliminatedOptions([]);
    const hintText = currentExercise.hint || "Look at the shape's sides, corners, and real-world examples to find the answer.";
    setShapesHint(hintText);
    setShapesMessage("Hint unlocked (-5 XP). Conceptual clue provided below.");

    saveShapesQuestionProgress(selectedClass, currentLevel.id, currentExercise, false, newXP);
    recordHintUsed("shapes");
  };

  const nextShapesExercise = () => {
    window.speechSynthesis?.cancel();

    const currentLevel = playShapesLevels[shapesLevelIndex];
    if (!currentLevel) return;

    const isLastQuestionOfLevel = shapesExerciseIndex === currentLevel.exercises.length - 1;

    if (!isLastQuestionOfLevel) {
      setShapesExerciseIndex((prev) => prev + 1);
      setShapesAnswer("");
      setShapesMessage("");
      setShapesHint("");
      setShapesHintUsed(false);
      setShapesEliminatedOptions([]);
      setShowShapeFact(false);
      return;
    }

    if (shapesLevelIndex < playShapesLevels.length - 1) {
      setShapesLevelIndex((prev) => prev + 1);
      setShapesExerciseIndex(0);
      setShapesAnswer("");
      setShapesMessage("");
      setShapesHint("");
      setShapesHintUsed(false);
      setShapesEliminatedOptions([]);
      setShowShapeFact(false);
      return;
    }

    // Both levels completed
    setScreen("shapesReport");
  };

  /* =======================================================
       MODULE 06 — READING COMPREHENSION HANDLERS
       ======================================================= */

  const readPassageAloud = (textToRead) => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utt = new SpeechSynthesisUtterance(textToRead);
      utt.rate = 0.85;
      window.speechSynthesis.speak(utt);
    }
  };

  const readQuestionAloud = (textToRead) => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utt = new SpeechSynthesisUtterance(textToRead);
      utt.rate = 0.88;
      window.speechSynthesis.speak(utt);
    }
  };

  const enterComprehensionStage = () => {
    window.speechSynthesis?.cancel();

    if (stage2RecognitionRef.current) {
      try {
        stage2RecognitionRef.current.stop();
      } catch { }
    }

    const classNumber = getNormalizedClassNumber(studentClass || selectedClass);
    const levels = getComprehensionLevelsForClass(classNumber);
    setPlayComprehensionLevels(levels);

    const classProgress = getSavedComprehensionClassProgress(classNumber);

    let resumeLevel = 0;
    let resumeQuestion = 0;
    let foundUnanswered = false;

    for (let l = 0; l < levels.length; l++) {
      for (let q = 0; q < levels[l].questions.length; q++) {
        if (!classProgress.completedQuestionIds?.includes(levels[l].questions[q].id)) {
          resumeLevel = l;
          resumeQuestion = q;
          foundUnanswered = true;
          break;
        }
      }
      if (foundUnanswered) break;
    }

    const totalQuestions = levels.reduce((sum, l) => sum + l.questions.length, 0);
    if (!foundUnanswered && (classProgress.completedQuestions >= totalQuestions || classProgress.stageCompleted)) {
      setCompLevelIndex(levels.length - 1);
      setCompQuestionIndex(levels[levels.length - 1].questions.length - 1);
      setCompScore(classProgress.xp > 0 ? classProgress.xp : 10);
      setScreen("comprehensionReport");
      return;
    }

    setCompLevelIndex(resumeLevel);
    setCompQuestionIndex(resumeQuestion);
    setCompAnswer("");
    setCompMessage("");
    setCompHint("");
    setCompHintUsed(false);
    setCompScore(classProgress.xp > 0 ? classProgress.xp : 10);
    setScreen("comprehension");
  };

  const answerComprehensionQuestion = (selectedOption) => {
    if (compMessage && compMessage.includes("Correct")) {
      return;
    }

    const currentLevel = playComprehensionLevels[compLevelIndex];
    const currentQuestion = currentLevel?.questions?.[compQuestionIndex];
    if (!currentQuestion) return;

    const isCorrect = selectedOption === currentQuestion.answer;
    setCompAnswer(selectedOption);

    const classProgress = getSavedComprehensionClassProgress(selectedClass);
    const alreadyCorrect = classProgress.correctQuestionIds?.includes(currentQuestion.id);

    const nextXP = isCorrect && !alreadyCorrect ? compScore + 3 : compScore;
    setCompScore(nextXP);

    saveComprehensionQuestionProgress(selectedClass, currentLevel.id, currentQuestion, isCorrect, nextXP);
    recordStagePerformance("comprehension", isCorrect, currentQuestion, selectedOption);

    if (isCorrect) {
      setCompMessage("Correct! +3 XP earned.");
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
        const utt = new SpeechSynthesisUtterance("Correct answer! Great job!");
        utt.rate = 0.9;
        window.speechSynthesis.speak(utt);
      }
    } else {
      setCompMessage("Incorrect. Check the passage text or unlock the hint.");
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
        const utt = new SpeechSynthesisUtterance("That's not quite right. Look back at the passage or consult the hint.");
        utt.rate = 0.9;
        window.speechSynthesis.speak(utt);
      }
    }
  };

  const useComprehensionHint = () => {
    if (compHintUsed) return;

    if (compScore < 5) {
      setCompMessage("Incorrect. You need at least 5 XP to unlock a hint.");
      return;
    }

    const currentLevel = playComprehensionLevels[compLevelIndex];
    const currentQuestion = currentLevel?.questions?.[compQuestionIndex];
    if (!currentQuestion) return;

    const newXP = Math.max(0, compScore - 5);
    setCompScore(newXP);
    setCompHintUsed(true);
    const hintText = currentQuestion.hint || "Review the paragraph above to locate the clue for this question.";
    setCompHint(hintText);
    setCompMessage("Hint unlocked (-5 XP). Check the clue below.");

    saveComprehensionQuestionProgress(selectedClass, currentLevel.id, currentQuestion, false, newXP);
    recordHintUsed("comprehension");
  };

  const nextComprehensionExercise = () => {
    window.speechSynthesis?.cancel();

    const currentLevel = playComprehensionLevels[compLevelIndex];
    if (!currentLevel) return;

    const isLastQuestionOfLevel = compQuestionIndex === currentLevel.questions.length - 1;

    if (!isLastQuestionOfLevel) {
      setCompQuestionIndex((prev) => prev + 1);
      setCompAnswer("");
      setCompMessage("");
      setCompHint("");
      setCompHintUsed(false);
      return;
    }

    if (compLevelIndex < playComprehensionLevels.length - 1) {
      setCompLevelIndex((prev) => prev + 1);
      setCompQuestionIndex(0);
      setCompAnswer("");
      setCompMessage("");
      setCompHint("");
      setCompHintUsed(false);
      return;
    }

    // Both levels completed
    setScreen("comprehensionReport");
  };

  const restartComprehensionStage = () => {
    const confirmed = window.confirm(
      `Restart Reading Comprehension for Class ${selectedClass}? Your saved comprehension progress for this class will be reset.`
    );
    if (!confirmed) return;

    window.speechSynthesis?.cancel();

    const classKey = String(selectedClass);
    let currentProgress;
    try {
      currentProgress = JSON.parse(localStorage.getItem("dyslexiaQuestProgress") || "{}");
    } catch {
      currentProgress = createEmptyLearningProgress();
    }

    if (!currentProgress.comprehension?.classes) {
      currentProgress.comprehension = { classes: {} };
    }

    currentProgress.comprehension.classes[classKey] = {
      completedQuestionIds: [],
      correctQuestionIds: [],
      completedQuestions: 0,
      completedLevels: [],
      xp: 10,
      stageCompleted: false,
      savedAt: new Date().toISOString(),
    };

    localStorage.setItem("dyslexiaQuestProgress", JSON.stringify(currentProgress));
    setSavedProgress(currentProgress);

    const levels = getComprehensionLevelsForClass(selectedClass);
    setPlayComprehensionLevels(levels);
    setCompLevelIndex(0);
    setCompQuestionIndex(0);
    setCompAnswer("");
    setCompMessage("");
    setCompHint("");
    setCompHintUsed(false);
    setCompScore(10);
    resetStagePerformance("comprehension");
    setScreen("comprehension");
  };

  const restartShapesStage = () => {
    const confirmed = window.confirm(
      `Restart Shapes Quest for Class ${selectedClass}? Your saved Shapes progress for this class will be cleared.`
    );
    if (!confirmed) return;

    window.speechSynthesis?.cancel();

    const classKey = String(selectedClass);
    let currentProgress;
    try {
      currentProgress = JSON.parse(localStorage.getItem("dyslexiaQuestProgress") || "{}");
    } catch {
      currentProgress = createEmptyLearningProgress();
    }

    if (!currentProgress.shapes?.classes) {
      currentProgress.shapes = { classes: {} };
    }

    currentProgress.shapes.classes[classKey] = {
      completedQuestionIds: [],
      correctQuestionIds: [],
      completedQuestions: 0,
      completedLevels: [],
      xp: 10,
      totalQuestions: 16,
      stageCompleted: false,
      savedAt: new Date().toISOString(),
    };

    localStorage.setItem("dyslexiaQuestProgress", JSON.stringify(currentProgress));
    setSavedProgress(currentProgress);

    setPlayShapesLevels(createShuffledShapes(selectedClass));
    setShapesLevelIndex(0);
    setShapesExerciseIndex(0);
    setShapesAnswer("");
    setShapesMessage("");
    setShapesHint("");
    setShapesHintUsed(false);
    setShapesEliminatedOptions([]);
    setShowShapeFact(false);
    setShapesScore(10);
    resetStagePerformance("shapes");
    setScreen("shapes");
  };


  /* =======================================================
     PLAY MODEL READING
     ======================================================= */

  const playStage2Model = () => {
    if (!("speechSynthesis" in window)) {
      return;
    }

    const exercise =
      playStage2Levels[
        stage2LevelIndex
      ]?.exercises[
      stage2ExerciseIndex
      ];

    if (!exercise) {
      return;
    }

    window.speechSynthesis.cancel();

    const utterance =
      new SpeechSynthesisUtterance(
        exercise.text
      );

    utterance.rate =
      exercise.type === "paragraph"
        ? 0.65
        : exercise.type === "sentence"
          ? 0.72
          : 0.78;

    utterance.pitch = 1.05;
    utterance.volume = 1;

    window.speechSynthesis.speak(
      utterance
    );
  };


  /* =======================================================
     START PRONUNCIATION CHECK
     ======================================================= */

  const startPronunciationCheck = () => {
    const SpeechRecognition =
      window.SpeechRecognition ||
      window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setStage2Message(
        "Speech recognition is not supported in this browser. Please use Google Chrome or Microsoft Edge."
      );

      return;
    }

    const exercise =
      playStage2Levels[
        stage2LevelIndex
      ]?.exercises[
      stage2ExerciseIndex
      ];

    if (!exercise) {
      return;
    }

    window.speechSynthesis?.cancel();

    if (stage2RecognitionRef.current) {
      try {
        stage2RecognitionRef.current.stop();
      } catch { }
    }

    const recognition =
      new SpeechRecognition();

    stage2RecognitionRef.current =
      recognition;

    recognition.lang = "en-US";

    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    setStage2Message(
      "Listening... Please speak clearly into the microphone."
    );

    setStage2SpokenText("");
    setStage2Accuracy(0);
    setStage2Listening(true);

    recognition.onresult = (event) => {

      const spoken =
        event.results?.[0]?.[0]?.transcript ||
        "";

      const accuracy =
        calculateReadingAccuracy(
          exercise.text,
          spoken
        );

      setStage2SpokenText(
        spoken
      );

      setStage2Accuracy(
        accuracy
      );

      setStage2Listening(false);

      if (accuracy >= 80) {
        setStage2Message(
          "Accurate match! Your oral reading matched the target text."
        );

        setStage2Score(
          (previous) =>
            previous + 1
        );
        recordStagePerformance("stage2", true, exercise, spoken);
      } else {
        setStage2Message(
          "Please try again. Speak clearly and maintain an even pace."
        );
        recordStagePerformance("stage2", false, exercise, spoken);
      }
    };

    recognition.onerror = (event) => {
      console.error(
        "Speech recognition error:",
        event.error
      );

      setStage2Listening(false);

      switch (event.error) {
        case "not-allowed":
        case "service-not-allowed":
          setStage2Message(
            "Microphone access denied. Please enable microphone permissions in your browser."
          );
          break;

        case "audio-capture":
          setStage2Message(
            "Microphone unavailable. Please verify your audio hardware configuration."
          );
          break;

        case "no-speech":
          setStage2Message(
            "No audio detected. Please speak closer to the microphone and try again."
          );
          break;

        case "network":
          setStage2Message(
            "Speech recognition service temporarily unavailable. Please try again."
          );
          break;

        case "aborted":
          break;

        default:
          setStage2Message(
            "Speech recognition error. Please try again."
          );
          break;
      }
    };
    recognition.onend = () => {
      setStage2Listening(false);
    };

    try {
      recognition.start();
    } catch (error) {
      console.error(
        "Could not start speech recognition:",
        error
      );

      setStage2Listening(false);

      setStage2Message(
        "Unable to initialize microphone. Please check browser permissions."
      );
    }
  };


  /* =======================================================
     NEXT STAGE 2 EXERCISE
     ======================================================= */

  const nextStage2Exercise = () => {
    window.speechSynthesis?.cancel();

    if (stage2RecognitionRef.current) {
      try {
        stage2RecognitionRef.current.stop();
      } catch { }
    }

    const level =
      playStage2Levels[
      stage2LevelIndex
      ];

    if (
      stage2ExerciseIndex <
      level.exercises.length - 1
    ) {
      setStage2ExerciseIndex(
        (previous) =>
          previous + 1
      );

      setStage2Message("");
      setStage2SpokenText("");
      setStage2Accuracy(0);

      return;
    }

    /*
      Current level completed.
      SAVE PROGRESS.
    */

    const completedLevel =
      stage2LevelIndex + 1;

    const totalStage2Questions =
      playStage2Levels.reduce(
        (total, item) =>
          total +
          item.exercises.length,
        0
      );

    const completedQuestions =
      playStage2Levels
        .slice(
          0,
          completedLevel
        )
        .reduce(
          (total, item) =>
            total +
            item.exercises.length,
          0
        );

    const oldProgress =
      JSON.parse(
        localStorage.getItem(
          "dyslexiaQuestProgress"
        ) || "{}"
      );

    const updatedProgress = {
      ...oldProgress,

      stage2: {
        completedLevels:
          Array.from(
            {
              length:
                completedLevel,
            },
            (_, index) =>
              index + 1
          ),

        completedQuestions,

        totalQuestions:
          totalStage2Questions,
      },
    };

    localStorage.setItem(
      "dyslexiaQuestProgress",
      JSON.stringify(
        updatedProgress
      )
    );

    setSavedProgress(
      updatedProgress
    );

    /*
      Move to next level.
    */

    if (
      stage2LevelIndex <
      playStage2Levels.length - 1
    ) {
      setStage2LevelIndex(
        (previous) =>
          previous + 1
      );

      setStage2ExerciseIndex(0);
      setStage2Message("");
      setStage2SpokenText("");
      setStage2Accuracy(0);

      return;
    }

    /*
      ALL STAGE 2 LEVELS COMPLETE.
    */

    setScreen(
      "stage2Report"
    );
  };
  const restartStageOne =
    () => {
      const confirmed =
        window.confirm(
          `RESTART EAGLE EYE ISLAND FOR CLASS ${selectedClass} FROM THE BEGINNING? YOUR SAVED PROGRESS FOR THIS CLASS WILL BE CLEARED.`
        );

      if (!confirmed) {
        return;
      }

      window.speechSynthesis?.cancel();

      const classKey =
        String(selectedClass);

      let currentProgress;

      try {
        currentProgress =
          JSON.parse(
            localStorage.getItem(
              "dyslexiaQuestProgress"
            ) || "{}"
          );
      } catch {
        currentProgress =
          createEmptyLearningProgress();
      }

      if (
        !currentProgress.stage1?.classes
      ) {
        currentProgress =
          createEmptyLearningProgress();
      }

      const resetClassProgress = {
        ...createEmptyClassProgress(),
        xp: 10,
        started: true,
        savedAt: new Date().toISOString(),
      };

      const updatedProgress = {
        ...currentProgress,
        stage1: {
          ...currentProgress.stage1,
          classes: {
            ...currentProgress.stage1.classes,
            [classKey]:
              resetClassProgress,
          },
        },
      };

      localStorage.setItem(
        "dyslexiaQuestProgress",
        JSON.stringify(
          updatedProgress
        )
      );

      setSavedProgress(
        updatedProgress
      );

      setPlayStage1Levels(
        createShuffledStage1(
          selectedClass
        )
      );

      setLevelIndex(0);
      setExerciseIndex(0);
      setStageAnswer("");
      setStageMessage("");
      setStageHint("");
      setHintUsed(false);
      setStageScore(10);
      setCompletedQuestions(0);
      setCompletedLevelNumber(0);
      resetStagePerformance("stage1");

      setScreen("stage1");
    };

  /* =======================================================
     PREVIOUS QUESTION
     ======================================================= */

  const goBackQuestion =
    () => {
      window.speechSynthesis?.cancel();

      if (exerciseIndex > 0) {
        setExerciseIndex(
          (previous) =>
            previous - 1
        );

        setStageAnswer("");
        setStageMessage("");
        setStageHint("");
        setHintUsed(false);

        return;
      }

      if (levelIndex > 0) {
        const previousLevelIndex =
          levelIndex - 1;

        setLevelIndex(
          previousLevelIndex
        );

        setExerciseIndex(
          playStage1Levels[
            previousLevelIndex
          ].exercises.length - 1
        );

        setStageAnswer("");
        setStageMessage("");
        setStageHint("");
        setHintUsed(false);

        return;
      }

      setStageAnswer("");
      setStageMessage("");
      setStageHint("");
      setHintUsed(false);
    };

  /* =======================================================
     HINT SYSTEM
     ======================================================= */

  const getStage1Hint = (exercise) => {
    if (!exercise) {
      return "LOOK CAREFULLY AT THE TARGET AND COMPARE ALL THE OPTIONS.";
    }

    if (exercise.type === "uppercase") {
      return "LOOK CAREFULLY AT THE CAPITAL LETTER'S SHAPE AND COMPARE IT WITH EACH OPTION.";
    }

    if (exercise.type === "lowercase") {
      return "LOOK FOR THE CAPITAL LETTER THAT HAS THE SAME SHAPE AS THE SMALL LETTER.";
    }

    if (exercise.type === "mixed") {
      return "THE TWO LETTERS BELONG TO THE SAME LETTER PAIR. FOCUS ON THEIR SHAPE, NOT THEIR SIZE.";
    }

    if (exercise.type === "letter") {
      return "COMPARE THE LETTERS ONE BY ONE. CHECK THEIR ORDER AND THEIR SHAPES CAREFULLY.";
    }

    if (exercise.type === "word") {
      return "COMPARE THE WORDS LETTER BY LETTER. CHECK THE FIRST, MIDDLE AND LAST LETTERS.";
    }

    if (exercise.type === "sentence") {
      return "COMPARE THE SENTENCE WORD BY WORD. CHECK LETTER ORDER, SPACES AND PUNCTUATION.";
    }

    return "COMPARE THE TARGET WITH EACH OPTION CAREFULLY. LOOK FOR THE OPTION THAT MATCHES EXACTLY.";
  };

  const useStage1Hint = () => {
    if (
      !stageMessage ||
      !stageMessage.includes("Wrong")
    ) {
      return;
    }

    if (hintUsed) {
      setStageMessage(
        "Incorrect. You have already unlocked the hint for this item. Try again."
      );
      return;
    }

    if (stageScore < 5) {
      setStageMessage(
        "Incorrect. A minimum of 5 XP is required to unlock a hint."
      );
      return;
    }

    const level =
      playStage1Levels[levelIndex];

    const exercise =
      level?.exercises[exerciseIndex];

    if (!exercise) {
      return;
    }

    const newXP =
      Math.max(0, stageScore - 5);

    setStageScore(newXP);
    setStageHint(
      getStage1Hint(exercise)
    );
    setHintUsed(true);
    recordHintUsed("stage1");

    setStageMessage(
      "Incorrect. Hint unlocked (5 XP used). Review the guidance below and try again."
    );

    // Save the XP deduction immediately.
    const classNumber = getNormalizedClassNumber(studentClass || selectedClass);

    const classKey =
      String(classNumber);

    try {
      const rawSaved =
        localStorage.getItem(
          "dyslexiaQuestProgress"
        );

      const progress =
        rawSaved
          ? JSON.parse(rawSaved)
          : createEmptyLearningProgress();

      if (!progress.stage1?.classes) {
        return;
      }

      const classProgress = {
        ...createEmptyClassProgress(),
        ...(progress.stage1.classes[classKey] || {}),
      };

      progress.stage1.classes[classKey] = {
        ...classProgress,
        xp: newXP,
        savedAt:
          new Date().toISOString(),
      };

      localStorage.setItem(
        "dyslexiaQuestProgress",
        JSON.stringify(progress)
      );

      setSavedProgress(progress);
    } catch (error) {
      console.error(
        "Could not save hint XP:",
        error
      );
    }
  };

  /* =======================================================
     ANSWER QUESTION
     ======================================================= */

  const answerStageQuestion =
    (answer) => {
      // Correct answers lock the question.
      // Incorrect answers remain retryable.
      if (
        stageMessage &&
        !stageMessage.includes("Wrong")
      ) {
        return;
      }

      const classNumber = getNormalizedClassNumber(studentClass || selectedClass);

      const level =
        playStage1Levels[
        levelIndex
        ];

      const exercise =
        level?.exercises[
        exerciseIndex
        ];

      if (!exercise) {
        return;
      }

      const isCorrect =
        answer === exercise.answer;

      setStageAnswer(answer);

      // XP is earned for a correct answer and is reduced by hints.
      // Each question awards 3 XP only once, even after retries.
      const alreadyCorrect =
        savedProgress?.stage1?.classes?.[
          String(classNumber)
        ]?.correctQuestionIds?.includes(
          exercise.id
        );

      const nextXP =
        isCorrect && !alreadyCorrect
          ? stageScore + 3
          : stageScore;

      setStageScore(nextXP);

      // SAVE IMMEDIATELY — before moving to the next question.
      // Wrong answers are also saved as completed.
      saveStage1QuestionProgress(
        classNumber,
        level.id,
        exercise,
        isCorrect,
        nextXP
      );

      recordStagePerformance("stage1", isCorrect, exercise, answer);

      if (isCorrect) {
        setStageMessage(
          "Correct! Well done."
        );
      } else {
        // Never reveal the correct answer after a wrong attempt.
        setStageMessage(
          "Incorrect. Try again or use a hint for 5 XP."
        );
      }
    };

  /* =======================================================
     NEXT QUESTION
     ======================================================= */

  const nextExercise =
    () => {
      window.speechSynthesis?.cancel();

      const level =
        playStage1Levels[
        levelIndex
        ];

      if (!level) {
        return;
      }

      const isLastQuestionOfLevel =
        exerciseIndex ===
        level.exercises.length - 1;

      if (!isLastQuestionOfLevel) {
        setExerciseIndex(
          (previous) =>
            previous + 1
        );

        setStageAnswer("");
        setStageMessage("");
        setStageHint("");
        setHintUsed(false);

        return;
      }

      // The last question of this level has already been
      // saved by answerStageQuestion().
      setCompletedLevelNumber(
        level.id
      );

      if (
        levelIndex <
        playStage1Levels.length - 1
      ) {
        setScreen("levelReport");
        return;
      }

      // All 3 levels are complete.
      setScreen("stage1Report");
    };

  /* =======================================================
     RESET PROFILE
     ======================================================= */

  const resetProfile =
    () => {
      const confirmed =
        window.confirm(
          "ARE YOU SURE YOU WANT TO DELETE THE STUDENT PROFILE AND ALL SAVED INFORMATION?"
        );

      if (!confirmed) {
        return;
      }

      removeRecording();

      localStorage.removeItem(
        "dyslexia_student_profile"
      );

      localStorage.removeItem(
        "dyslexiaQuestProgress"
      );

      setSavedProgress(
        createEmptyLearningProgress()
      );

      setStudentName("");
      setStudentAge("");
      setStudentClass("");
      setSchoolName("");

      setParentName("");
      setParentPhone("");
      setParentEmail("");

      setStudentPhoto("");

      setLevelIndex(0);
      setExerciseIndex(0);
      setStageScore(10);
      setCompletedQuestions(0);
      setCompletedLevelNumber(0);
      setStageAnswer("");
      setStageMessage("");
      setStageHint("");
      setHintUsed(false);

      setStage2LevelIndex(0);
      setStage2ExerciseIndex(0);
      setStage2Message("");
      setStage2SpokenText("");
      setStage2Accuracy(0);
      setStage2Listening(false);
      setStage2Score(10);
      setPlayStage2Levels(createShuffledStage2(selectedClass));

      setStage3LevelIndex(0);
      setStage3ExerciseIndex(0);
      setStage3Message("");
      setStage3Answer("");
      setStage3Hint("");
      setStage3HintUsed(false);
      setStage3Score(10);

      setStage4LevelIndex(0);
      setStage4ExerciseIndex(0);
      setStage4Score(10);
      setStage4Answer("");
      setStage4Message("");
      setStage4Hint("");
      setStage4HintUsed(false);
      setStage4EliminatedOptions([]);
      setPlayStage4Levels(createShuffledStage4(selectedClass));

      setShapesLevelIndex(0);
      setShapesExerciseIndex(0);
      setShapesScore(10);
      setShapesAnswer("");
      setShapesMessage("");
      setShapesHint("");
      setShapesHintUsed(false);
      setShapesEliminatedOptions([]);
      setShowShapeFact(false);
      setPlayShapesLevels(createShuffledShapes(selectedClass));

      setCompLevelIndex(0);
      setCompQuestionIndex(0);
      setCompScore(10);
      setCompAnswer("");
      setCompMessage("");
      setCompHint("");
      setCompHintUsed(false);
      setPlayComprehensionLevels(getComprehensionLevelsForClass(selectedClass));

      setScreen("home");
    };

  // Synchronize URL hash with current screen for deep linking and testing
  useEffect(() => {
    const handleHash = () => {
      const h = window.location.hash.replace("#", "").trim();
      if (!h) return;
      if (h === "teacher" || h === "analysis") {
        setScreen("teacher");
      } else if (h === "stages") {
        enterStages();
      } else if (h === "profile") {
        startProfileCreation();
      } else if (h === "profileCreated") {
        setScreen("profileCreated");
      } else if (h === "home") {
        setScreen("home");
      } else if (h === "stage1") {
        enterStageOne();
      } else if (h === "stage1Report") {
        setScreen("stage1Report");
      } else if (h === "stage2") {
        enterStageTwo();
      } else if (h === "stage2Report") {
        setScreen("stage2Report");
      } else if (h === "stage3") {
        enterStageThree();
      } else if (h === "stage3Report") {
        setScreen("stage3Report");
      } else if (h === "stage4") {
        enterStageFour();
      } else if (h === "stage4Report") {
        setScreen("stage4Report");
      } else if (h === "shapes") {
        enterShapesStage();
      } else if (h === "shapesReport") {
        setScreen("shapesReport");
      } else if (h === "comprehension") {
        enterComprehensionStage();
      } else if (h === "comprehensionReport") {
        setScreen("comprehensionReport");
      } else if (h === "levelReport") {
        setScreen("levelReport");
      }
    };

    handleHash();
    window.addEventListener("hashchange", handleHash);
    return () => window.removeEventListener("hashchange", handleHash);
  }, []);

  useEffect(() => {
    const currentHash = window.location.hash.replace("#", "").trim();
    if (screen && currentHash !== screen) {
      window.location.hash = screen;
    }
  }, [screen]);

  /* =======================================================
     HOME PAGE
     ======================================================= */
  /* =======================================================
     REALM 2 — ECHO VALLEY (VOICE & READING SAFARI)
     ======================================================= */

  if (screen === "stage2") {
    const level =
      playStage2Levels[
      stage2LevelIndex
      ];

    const exercise =
      level.exercises[
      stage2ExerciseIndex
      ];

    const totalQuestions =
      playStage2Levels.reduce(
        (total, item) =>
          total +
          item.exercises.length,
        0
      );

    const completedBefore =
      playStage2Levels
        .slice(
          0,
          stage2LevelIndex
        )
        .reduce(
          (total, item) =>
            total +
            item.exercises.length,
          0
        ) +
      stage2ExerciseIndex;

    const currentCompleted =
      completedBefore +
      (stage2Message &&
        stage2SpokenText
        ? 1
        : 0);

    const overallProgress =
      Math.round(
        (currentCompleted /
          totalQuestions) *
        100
      );

    const levelCompleted =
      stage2ExerciseIndex +
      (stage2Message &&
        stage2SpokenText
        ? 1
        : 0);

    const levelProgress =
      Math.round(
        (levelCompleted /
          level.exercises.length) *
        100
      );

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("stages")}
        <div className="page">

          <div className="top-bar">

            <button
              className="back-button"
              onClick={() => {
                window.speechSynthesis?.cancel();

                if (
                  stage2RecognitionRef.current
                ) {
                  try {
                    stage2RecognitionRef.current.stop();
                  } catch { }
                }

                setScreen("stages");
              }}
            >
              ← STAGES
            </button>

            <div className="score-display">
              {stage2Score} XP
            </div>

          </div>

          <section className="stage-card">

            <p className="eyebrow">
              Class {selectedClass} • Module 02: Auditory Processing
            </p>

            <h1>
              Auditory Processing & Reading Aloud
            </h1>

            <p className="stage-description">
              VOICE & READING SAFARI — SPEAK ALOUD AND UNLOCK THE MYSTERIES OF SOUND!
            </p>

            {/* LEVEL TABS */}

            <div className="level-tabs">

              {playStage2Levels.map(
                (
                  item,
                  index
                ) => (
                  <div
                    key={item.id}
                    className={
                      "level-tab " +
                      (index ===
                        stage2LevelIndex
                        ? "active"
                        : index <
                          stage2LevelIndex
                          ? "completed"
                          : "")
                    }
                  >

                    <span>
                      {index <
                        stage2LevelIndex
                        ? <IconCheck size={14} />
                        : item.id}
                    </span>

                    <div>

                      <strong>
                        {item.title}
                      </strong>

                      <small>
                        {item.difficulty}
                      </small>

                    </div>

                  </div>
                )
              )}

            </div>

            {/* OVERALL PROGRESS */}

            <div className="progress-area">

              <div className="progress-label">

                <span>
                  Module 02 Progress
                </span>

                <span>
                  {currentCompleted} /{" "}
                  {totalQuestions}
                </span>

              </div>

              <div className="progress-track">

                <div
                  className="progress-fill"
                  style={{
                    width:
                      `${overallProgress}%`,
                  }}
                />

              </div>

              <p
                style={{
                  textAlign: "center",
                  fontWeight: "700",
                  marginTop: "8px",
                }}
              >
                {overallProgress}% COMPLETED
              </p>

            </div>

            {/* CURRENT LEVEL */}

            <div className="progress-area">

              <div className="progress-label">

                <span>
                  {level.title} PROGRESS
                </span>

                <span>
                  {levelCompleted} /{" "}
                  {level.exercises.length}
                </span>

              </div>

              <div className="progress-track">

                <div
                  className="progress-fill"
                  style={{
                    width:
                      `${levelProgress}%`,
                  }}
                />

              </div>

            </div>

            {/* READING EXERCISE */}

            <div className="exercise-card">

              <div className="exercise-header">

                <span className="exercise-type">

                  {exercise.type ===
                    "word" &&
                    "Word"}

                  {exercise.type ===
                    "sentence" &&
                    "Sentence"}

                  {exercise.type ===
                    "paragraph" &&
                    "Paragraph"}

                </span>

                <span>
                  QUESTION{" "}
                  {stage2ExerciseIndex + 1}
                  /
                  {level.exercises.length}
                </span>

              </div>

              <h2>
                READ THIS ALOUD
              </h2>

              {/* TARGET TEXT */}

              <div
                className={
                  exercise.type ===
                    "paragraph"
                    ? "reading-paragraph"
                    : "reading-target"
                }
              >
                {exercise.text}
              </div>

              {/* MODEL AUDIO */}

              <button
                type="button"
                className="secondary-button"
                onClick={
                  playStage2Model
                }
              >
                Play Audio Model
              </button>

              <p className="listening-hint">
                LISTEN TO THE MODEL FIRST
                IF YOU NEED HELP.
              </p>

              {/* CHILD READING */}

              <div className="reading-record-box">

                <div className="listen-icon">
                  <IconMic size={28} />
                </div>

                <h3>
                  NOW YOU READ
                </h3>

                <p>
                  PRESS THE BUTTON AND
                  READ THE TEXT ALOUD.
                </p>

                <button
                  type="button"
                  className={
                    stage2Listening
                      ? "stop-button listening-active-btn"
                      : "primary-button"
                  }
                  onClick={
                    handleToggleListening
                  }
                  title={stage2Listening ? "Click to stop listening and check reading" : "Click to speak aloud"}
                >
                  {stage2Listening
                    ? "■ Stop Listening"
                    : "🎤 Read Aloud"}
                </button>

                {stage2Listening && (
                  <div className="mic-active-banner">
                    <span className="pulsing-mic-dot" />
                    <span>Listening... Speak clearly into your mic!</span>
                  </div>
                )}

              </div>

              {/* SPEECH RESULT */}

              {stage2SpokenText && (
                <div className="spoken-result">

                  <h3>
                    WHAT I HEARD
                  </h3>

                  <p>
                    "{stage2SpokenText}"
                  </p>

                  <div className="reading-accuracy">

                    <strong>
                      {stage2Accuracy}%
                    </strong>

                    <span>
                      READING MATCH
                    </span>

                  </div>

                </div>
              )}

              {/* FEEDBACK */}

              {stage2Message && (
                <div
                  className={
                    stage2Accuracy >= 65
                      ? "feedback correct-feedback"
                      : "feedback wrong-feedback"
                  }
                >
                  {stage2Message}
                </div>
              )}

              {/* RETRY OR ACCEPT */}

              {stage2Message &&
                stage2Accuracy < 65 && (
                  <div className="stage2-action-row" style={{ display: "flex", gap: "12px", justifyContent: "center", marginTop: "16px", flexWrap: "wrap" }}>
                    <button
                      type="button"
                      className="secondary-button"
                      onClick={() => {
                        setStage2Message("");
                        setStage2SpokenText("");
                        setStage2Accuracy(0);
                      }}
                    >
                      🔄 Try Again
                    </button>
                    <button
                      type="button"
                      className="save-button"
                      style={{ background: "#16a34a", borderColor: "#15803d", padding: "10px 18px" }}
                      onClick={acceptStage2ReadingManually}
                      title="If you spoke clearly but the mic misheard, click here to accept your reading"
                    >
                      ✓ I Read It Clearly (Accept)
                    </button>
                  </div>
                )}

              {/* NEXT */}

              {stage2Accuracy >= 65 && (
                <button
                  type="button"
                  className="save-button next-button"
                  onClick={
                    nextStage2Exercise
                  }
                >
                  {stage2LevelIndex ===
                    playStage2Levels.length - 1 &&
                    stage2ExerciseIndex ===
                    level.exercises.length - 1
                    ? "Complete Module 2"
                    : "NEXT READING →"}
                </button>
              )}

            </div>

          </section>

        </div>
      </div>
    );
  }
  /* =======================================================
     REALM 2 PROGRESS REPORT — ECHO VALLEY
     ======================================================= */

  if (screen === "stage2Report") {
    const totalQuestions =
      playStage2Levels.reduce(
        (total, level) =>
          total +
          level.exercises.length,
        0
      );

    const percentage =
      Math.round(
        (stage2Score /
          totalQuestions) *
        100
      );

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("teacher")}
        <div className="page">

          <section className="complete-card">

            <div className="complete-icon">
              <IconAward size={36} />
            </div>

            <p className="eyebrow">
              Module 02 Assessment Completed
            </p>

            <h1>
              AMAZING READING!
            </h1>

            <h2>
              {studentName}
            </h2>

            <p>
              YOU COMPLETED WORD,
              SENTENCE AND PARAGRAPH
              READING PRACTICE.
            </p>

            <div
              className="final-score"
              style={{
                margin: "25px 0",
              }}
            >
              {totalQuestions} /{" "}
              {totalQuestions}

              <div
                style={{
                  fontSize: "18px",
                  marginTop: "8px",
                }}
              >
                READING ACTIVITIES COMPLETED
              </div>
            </div>

            <div
              className="analysis-grid"
              style={{
                marginTop: "20px",
              }}
            >

              <div className="analysis-item">
                <span>
                  <IconStar size={16} />
                </span>
                <strong>
                  READING SCORE
                </strong>
                <p>
                  {stage2Score} /{" "}
                  {totalQuestions}
                </p>
              </div>

              <div className="analysis-item">
                <span>
                  <IconTarget size={16} />
                </span>
                <strong>
                  ACCURACY
                </strong>
                <p>
                  {totalQuestions > 0
                    ? Math.round((stage2Score / totalQuestions) * 100)
                    : 0}%
                </p>
              </div>

              <div className="analysis-item">
                <span>
                  <IconEdit size={16} />
                </span>
                <strong>
                  WORDS
                </strong>
                <p>
                  {
                    playStage2Levels[0]
                      .exercises.length
                  }
                </p>
              </div>

              <div className="analysis-item">
                <span>
                  <IconBookOpen size={16} />
                </span>
                <strong>
                  SENTENCES
                </strong>
                <p>
                  {
                    playStage2Levels[1]
                      .exercises.length
                  }
                </p>
              </div>

            </div>

            <div className="analysis-note">

              Assessment Activities Evaluated:

              <br />

              Phonetic Word Pronunciation

              <br />

              Oral Sentence Fluency

              <br />

              Passage Comprehension & Pace

              <br />

              Oral Reading Fluency

            </div>

            <StageComprehensiveAnalysis
              stageKey="stage2"
              stageName="Module 02: Auditory Processing & Reading Aloud"
              performance={stagePerformance.stage2}
              totalQuestions={totalQuestions}
              studentName={studentName}
              studentClass={selectedClass}
              score={stage2Score}
              onRestart={() => enterStageTwo()}
              onNextStage={enterStageThree}
              nextStageTitle="Continue to Module 03 (Written Expression) →"
            />

          </section>

        </div>
      </div>
    );
  }
  if (screen === "teacher") {
    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <UniversalAppHeader
          currentScreen="teacher"
          onNavigate={(target) => {
            if (target === "stages") enterStages();
            else if (target === "profile") startProfileCreation();
            else setScreen(target);
          }}
          studentName={studentName}
          selectedClass={selectedClass}
          profiles={allProfiles}
          onSelectProfile={handleSelectProfile}
        />
        <div className="page" style={{ maxWidth: "1400px", padding: "20px 24px 60px" }}>
          <TeacherDashboardView
            onLaunchStage={(stageId) => {
              switch (stageId) {
                case 1:
                  enterStageOne();
                  break;
                case 2:
                  enterStageTwo();
                  break;
                case 3:
                  enterStageThree();
                  break;
                case 4:
                  enterStageFour();
                  break;
                case 5:
                  enterShapesStage();
                  break;
                case 6:
                  enterComprehensionStage();
                  break;
                default:
                  enterStages();
              }
            }}
            onReturnHome={() => setScreen("home")}
            profiles={allProfiles}
            onSelectProfile={handleSelectProfile}
          />
        </div>
      </div>
    );
  }

  if (screen === "home") {
    return (
      <HomeScreen
        onStartProfile={() => {
          startProfileCreation();
        }}
        onEnterStages={enterStages}
        onLaunchStage1={enterStageOne}
        onLaunchStage2={enterStageTwo}
        onLaunchStage3={enterStageThree}
        onLaunchStage4={enterStageFour}
        onLaunchStage5={enterShapesStage}
        onLaunchStage6={enterComprehensionStage}
        onNavigate={(target) => {
          if (target === "stages") enterStages();
          else if (target === "profile") startProfileCreation();
          else setScreen(target);
        }}
        studentName={studentName}
        selectedClass={selectedClass}
        savedProgress={stagePerformance}
      />
    );
  }

  /* =======================================================
     CREATE PROFILE PAGE
     ======================================================= */

  if (screen === "profile") {
    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        <UniversalAppHeader
          currentScreen="profile"
          onNavigate={(target) => {
            if (target === "stages") enterStages();
            else if (target === "profile") startProfileCreation();
            else setScreen(target);
          }}
          studentName={studentName}
          selectedClass={selectedClass}
          profiles={allProfiles}
          onSelectProfile={handleSelectProfile}
        />
        <div className="page">

          <div className="top-bar">

            <button
              className="back-button"
              onClick={() =>
                setScreen("home")
              }
            >
              ← HOME
            </button>

          </div>

          <div className="hero">

            <div className="brain">
              <IconBrain size={32} />
            </div>

            <p className="eyebrow">
              STUDENT ONBOARDING & PROFILES
            </p>

            <h1>
              Student Profile Setup
            </h1>

            <p className="hero-subtitle">
              ACTIVE COHORT & CLINICAL DEMOGRAPHICS
            </p>

            <p className="hero-description">
              Select an existing student profile below to review diagnostic records, or fill in the form to register a new student.
            </p>

          </div>

          {/* ALL SAVED PROFILES COHORT SELECTOR */}
          <div className="saved-profiles-deck-container">
            <div className="saved-profiles-deck-header">
              <div>
                <span className="deck-eyebrow">SAVED COHORT ROSTER ({allProfiles.length})</span>
                <h3>Switch Student or Create New</h3>
              </div>
              <button
                className="btn-deck-new-profile"
                onClick={handleCreateNewProfile}
              >
                + Blank Form (New Student)
              </button>
            </div>

            <div className="saved-profiles-grid">
              {allProfiles.map((p) => {
                const isActive = p.id === activeProfileId || p.studentName === studentName;
                return (
                  <div
                    key={p.id}
                    className={`saved-profile-card ${isActive ? "active" : ""}`}
                    onClick={() => handleSelectProfile(p)}
                  >
                    <div className="spc-avatar">
                      <IconUser size={18} />
                    </div>
                    <div className="spc-info">
                      <strong>{p.studentName}</strong>
                      <span>Class {p.studentClass || 1} • Age {p.studentAge || "—"}</span>
                    </div>
                    {isActive ? (
                      <span className="spc-active-pill">Editing ✓</span>
                    ) : (
                      <button className="spc-switch-btn">Switch</button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <section className="card">

            <h2>
              Student Demographics & Settings
            </h2>

            <p className="section-description">
              ADD THE STUDENT'S INFORMATION BELOW.
            </p>

            {/* PHOTO */}

            <div className="profile-photo-section">

              <div className="photo-preview">

                {studentPhoto ? (
                  <img
                    src={studentPhoto}
                    alt="Student"
                  />
                ) : (
                  <span><IconUser size={40} /></span>
                )}

              </div>

              <label className="upload-button">

                Upload Student Photograph

                <input
                  type="file"
                  accept="image/*"
                  onChange={
                    handlePhotoUpload
                  }
                />

              </label>

              {studentPhoto && (
                <button
                  className="small-button danger"
                  onClick={() =>
                    setStudentPhoto("")
                  }
                >
                  REMOVE PHOTOGRAPH
                </button>
              )}

            </div>

            {/* STUDENT DETAILS */}

            <div className="form-section">

              <h3>
                Student Information
              </h3>

              <div className="form-grid">

                <div className="form-group">

                  <label>
                    STUDENT NAME *
                  </label>

                  <input
                    value={
                      studentName
                    }
                    onChange={(e) =>
                      setStudentName(
                        e.target.value
                      )
                    }
                    placeholder="Enter student's name"
                  />

                </div>

                <div className="form-group">

                  <label>
                    AGE *
                  </label>

                  <input
                    type="number"
                    min="4"
                    max="11"
                    value={
                      studentAge
                    }
                    onChange={(e) =>
                      setStudentAge(
                        e.target.value
                      )
                    }
                    placeholder="Age"
                  />

                </div>

                <div className="form-group">

                  <label>
                    CLASS / GRADE
                  </label>

                  <select
                    value={studentClass}
                    onChange={(e) =>
                      setStudentClass(e.target.value)
                    }
                  >
                    <option value="">
                      SELECT YOUR CLASS
                    </option>

                    <option value="1">
                      CLASS 1
                    </option>

                    <option value="2">
                      CLASS 2
                    </option>

                    <option value="3">
                      CLASS 3
                    </option>

                    <option value="4">
                      CLASS 4
                    </option>

                    <option value="5">
                      CLASS 5
                    </option>
                  </select>

                </div>

                <div className="form-group">

                  <label>
                    SCHOOL
                  </label>

                  <input
                    value={
                      schoolName
                    }
                    onChange={(e) =>
                      setSchoolName(
                        e.target.value
                      )
                    }
                    placeholder="School name"
                  />

                </div>

              </div>

            </div>

            {/* PARENT DETAILS */}

            <div className="form-section">

              <h3>
                Parent / Guardian Information
              </h3>

              <div className="form-grid">

                <div className="form-group">

                  <label>
                    PARENT / GUARDIAN NAME *
                  </label>

                  <input
                    value={
                      parentName
                    }
                    onChange={(e) =>
                      setParentName(
                        e.target.value
                      )
                    }
                    placeholder="Parent or guardian name"
                  />

                </div>

                <div className="form-group">

                  <label>
                    PHONE NUMBER
                  </label>

                  <input
                    type="tel"
                    inputMode="numeric"
                    maxLength={10}
                    value={parentPhone}
                    onChange={(e) => {
                      const value = e.target.value
                        .replace(/\D/g, "")
                        .slice(0, 10);

                      setParentPhone(value);
                    }}
                    placeholder="10-digit phone number"
                  />


                </div>

                <div className="form-group full-width">

                  <label>
                    EMAIL
                  </label>

                  <input
                    type="email"
                    value={
                      parentEmail
                    }
                    onChange={(e) =>
                      setParentEmail(
                        e.target.value
                      )
                    }
                    placeholder="Parent email"
                  />

                </div>

              </div>

            </div>

            {/* AUDIO - UNCHANGED */}

            <div className="form-section voice-section">

              <h3>
                Student Voice Sample
              </h3>

              <p>
                RECORD A SHORT MESSAGE IN
                THE STUDENT'S VOICE.
              </p>

              <div className="voice-prompt">

                Recommended phrase:

                <strong>
                  "Hello! My name is{" "}
                  {studentName ||
                    "_____"}
                  ."
                </strong>

              </div>

              {!recording &&
                !audioURL && (
                  <button
                    className="primary-button"
                    onClick={
                      startRecording
                    }
                  >
                    Start Recording
                  </button>
                )}

              {recording && (
                <div className="recording-active">

                  <div className="recording-dot">
                    ●
                  </div>

                  <h3>
                    RECORDING...
                  </h3>

                  <p>
                    SPEAK CLEARLY INTO
                    THE MICROPHONE.
                  </p>

                  <button
                    className="stop-button"
                    onClick={
                      stopRecording
                    }
                  >
                    Stop Recording
                  </button>

                </div>
              )}

              {!recording &&
                audioURL && (
                  <div className="recording-result">

                    <h3 className="recording-ready">
                      Recording Ready
                    </h3>

                    <p>
                      PRESS PLAY TO HEAR
                      THE STUDENT'S
                      RECORDING.
                    </p>

                    <audio
                      className="audio-player"
                      controls
                      preload="metadata"
                      src={audioURL}
                      onLoadedMetadata={() =>
                        console.log(
                          "Audio loaded successfully."
                        )
                      }
                      onCanPlay={() =>
                        console.log(
                          "Audio can play."
                        )
                      }
                      onError={() =>
                        setAudioError(
                          "The recording could not be played. Please record again."
                        )
                      }
                    />

                    <div className="audio-buttons">

                      <button
                        className="secondary-button danger-border"
                        onClick={
                          removeRecording
                        }
                      >
                        Remove Recording
                      </button>

                      <button
                        className="primary-button"
                        onClick={
                          recordAgain
                        }
                      >
                        Record Again
                      </button>

                    </div>

                    {audioError && (
                      <div className="audio-error">
                        {audioError}
                      </div>
                    )}

                  </div>
                )}

              {audioError &&
                !audioURL && (
                  <div className="audio-error">
                    {audioError}
                  </div>
                )}

            </div>

            {saveMessage && (
              <div className="save-message">
                {saveMessage}
              </div>
            )}

            <button
              className="save-button"
              onClick={
                saveProfile
              }
            >
              Save Student Profile
            </button>

            <p className="privacy-note">
              YOUR PROFILE STAYS SAVED
              ON THIS DEVICE.
            </p>

          </section>

        </div>
      </div>
    );
  }

  /* =======================================================
     PROFILE CREATED
     ======================================================= */

  if (
    screen ===
    "profileCreated"
  ) {
    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("profile")}
        <div className="page">

          <section className="analysis-card">

            <div className="analysis-icon">
              <IconAward size={36} />
            </div>

            <p className="eyebrow">
              PROFILE CREATED
            </p>

            <h1>
              GREAT JOB!
            </h1>

            {studentPhoto && (
              <div
                className="photo-preview"
                style={{
                  margin:
                    "20px auto",
                }}
              >
                <img
                  src={
                    studentPhoto
                  }
                  alt="Student"
                />
              </div>
            )}

            <h2>
              {studentName}
            </h2>

            <p className="analysis-welcome">
              YOUR STUDENT PROFILE
              HAS BEEN CREATED
              SUCCESSFULLY!
            </p>

            <div className="analysis-grid">

              <div className="analysis-item">
                <span><IconGraduationCap size={18} /></span>
                <strong>
                  AGE
                </strong>
                <p>
                  {studentAge}
                </p>
              </div>

              <div className="analysis-item">
                <span><IconBookOpen size={18} /></span>
                <strong>
                  CLASS
                </strong>
                <p>
                  {studentClass ||
                    "NOT PROVIDED"}
                </p>
              </div>

              <div className="analysis-item">
                <span><IconShieldCheck size={18} /></span>
                <strong>
                  SCHOOL
                </strong>
                <p>
                  {schoolName ||
                    "NOT PROVIDED"}
                </p>
              </div>

              <div className="analysis-item">
                <span><IconMic size={18} /></span>
                <strong>
                  VOICE
                </strong>
                <p>
                  {audioData
                    ? "RECORDED"
                    : "NOT RECORDED"}
                </p>
              </div>

            </div>

            <div className="analysis-note">
              Assessment profile successfully initialized and ready.
            </div>

            <button
              className="save-button"
              onClick={
                startAnalysis
              }
            >
              Begin Assessment
            </button>

          </section>

        </div>
      </div>
    );
  }

  /* =======================================================
     STUDENT ANALYSIS
     ======================================================= */

  if (
    screen === "analysis"
  ) {
    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        <UniversalAppHeader
          currentScreen="analysis"
          onNavigate={(target) => {
            if (target === "stages") enterStages();
            else if (target === "profile") startProfileCreation();
            else setScreen(target);
          }}
          studentName={studentName}
          selectedClass={selectedClass}
        />
        <div className="page">

          <div className="top-bar">

            <button
              className="back-button"
              onClick={() =>
                setScreen(
                  "profileCreated"
                )
              }
            >
              ← BACK
            </button>

          </div>

          <section className="analysis-card">

            <div className="analysis-icon">
              <IconTarget size={36} />
            </div>

            <p className="eyebrow">
              STUDENT ASSESSMENT
            </p>

            <h1>
              STUDENT ANALYSIS
            </h1>

            <p className="analysis-welcome">
              WELCOME,{" "}
              <strong>
                {studentName ||
                  "STUDENT"}
              </strong>
              !
            </p>

            <p>
              WE WILL START WITH SIMPLE
              VISUAL RECOGNITION.
              THERE ARE NO DIFFICULT
              CONCEPTUAL QUESTIONS.
            </p>

            <div className="analysis-grid">

              <div className="analysis-item">
                <span><IconEye size={18} /></span>

                <strong>
                  VISUAL RECOGNITION
                </strong>

                <p>
                  LOOK CAREFULLY AT
                  LETTER SHAPES.
                </p>
              </div>

              <div className="analysis-item">
                <span><IconEdit size={18} /></span>

                <strong>
                  LETTER ORIENTATION
                </strong>

                <p>
                  RECOGNISE BOTH FORMS
                  OF LETTERS.
                </p>
              </div>

              <div className="analysis-item">
                <span><IconShapes size={18} /></span>

                <strong>
                  MATCHING
                </strong>

                <p>
                  FIND LETTERS THAT
                  LOOK RELATED.
                </p>
              </div>

              <div className="analysis-item">
                <span><IconLayers size={18} /></span>

                <strong>
                  SORTING
                </strong>

                <p>
                  CHOOSE THE MATCHING
                  LETTER OR WORD.
                </p>
              </div>

            </div>

            <div className="analysis-note">
              Foundational baseline assessment without timed pressure.
              THE CHILD LEARNS THROUGH
              LOOKING, COMPARING AND
              RECOGNISING.
            </div>

            <button
              className="save-button"
              onClick={
                enterStages
              }
            >
              Enter Assessment Modules
            </button>

          </section>

        </div>
      </div>
    );
  }

  /* =======================================================
     STAGES PAGE
     ======================================================= */

  if (
    screen === "stages"
  ) {
    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        <UniversalAppHeader
          currentScreen="stages"
          onNavigate={(target) => {
            if (target === "stages") enterStages();
            else if (target === "profile") startProfileCreation();
            else setScreen(target);
          }}
          studentName={studentName}
          selectedClass={selectedClass}
        />
        <div className="page">

          <div className="top-bar" style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <button
              className="back-button"
              onClick={() =>
                setScreen("analysis")
              }
            >
              {t("backBtn", "← BACK")}
            </button>
            <button
              className="quest-return-home-btn"
              onClick={() => setScreen("home")}
            >
              {t("portalBtn", "🌐 3D Website Portal")}
            </button>
          </div>

          <section className="card stages-card">

            <div className="stages-header">

              <p className="eyebrow">
                {t("stagesEyebrow", "CLINICAL & EDUCATIONAL CURRICULUM")}
              </p>

              <h1>
                {t("stagesTitle", "Cognitive Assessment Modules")}
              </h1>

              <p>
                {t("stagesDesc", "Select an assessment module below. Real-time response performance is tracked and analyzed.")}
              </p>

              <div
                className="analysis-note"
                style={{ margin: "15px 0" }}
              >
                {CLASS_INFO[selectedClass]?.name || "Class Not Selected"}
                <br />
                {t("difficultyLevel", "Difficulty Level:")} {CLASS_INFO[selectedClass]?.difficulty || "Standard"}
              </div>

              <div className="saved-progress-card">
                <strong><IconLayers size={14} /> {t("savedProgress", "Saved Assessment Progress")}</strong>
                <p>
                  Module 01 (Visual Perception): {(
                    savedProgress.stage1?.classes?.[
                      String(selectedClass)
                    ]?.completedQuestions || 0
                  )} / 27 QUESTIONS
                </p>
                <p>
                  Module 04 (Numerical Cognition): {(
                    savedProgress.stage4?.classes?.[
                      String(selectedClass)
                    ]?.completedQuestions || 0
                  )} / 30 QUESTIONS
                </p>
                <p>
                  Module 05 (Spatial Geometry): {(
                    savedProgress.shapes?.classes?.[
                      String(selectedClass)
                    ]?.completedQuestions || 0
                  )} / 16 QUESTIONS
                </p>
                <p>
                  Module 06 (Reading Comprehension): {(
                    savedProgress.comprehension?.classes?.[
                      String(selectedClass)
                    ]?.completedQuestions || 0
                  )} / {(
                    getComprehensionLevelsForClass(selectedClass).reduce(
                      (sum, l) => sum + l.questions.length,
                      0
                    )
                  )} QUESTIONS
                </p>
              </div>

            </div>

            <div className="stage-grid">

              {/* REALM 1: EAGLE EYE ISLAND */}

              <div className="stage-option">

                <div className="realm-pill">Module 01</div>

                <div className="stage-number">
                  <IconEye size={24} />
                </div>

                <h2>
                  Visual Perception
                </h2>

                <p className="realm-tagline">
                  Visual Discrimination & Orientation
                </p>

                <p>
                  3 LEVELS • EASY → HARD
                </p>

                <div
                  className="analysis-note"
                  style={{
                    margin: "15px 0",
                  }}
                >
                  Visual symbol discrimination & pattern search
                  <br />
                  9 Assessment Tasks Per Level
                  <br />
                  27 Total Diagnostic Tasks
                  <br />
                  Progress automatically recorded
                </div>

                <button
                  className="primary-button"
                  onClick={
                    enterStageOne
                  }
                >
                  Begin Module 1
                </button>

              </div>

              {/* REALM 2: ECHO VALLEY */}

              <div className="stage-option">

                <div className="realm-pill">Module 02</div>

                <div className="stage-number">
                  <IconMic size={24} />
                </div>

                <h2>
                  Auditory Processing & Reading
                </h2>

                <p className="realm-tagline">
                  Speech Recognition & Phonemic Decoding
                </p>

                <p>
                  SPEAK WORDS, SENTENCES & STORIES ALOUD
                </p>

                <div
                  className="analysis-note"
                  style={{
                    margin: "15px 0",
                  }}
                >
                  Phonics & Single-Word Pronunciation
                  <br />
                  Oral Sentence Fluency
                  <br />
                  Passage Comprehension Tasks
                  <br />
                  Speech-to-Text Recognition
                </div>

                <button
                  className="primary-button"
                  onClick={enterStageTwo}
                >
                  Begin Module 2
                </button>

              </div>

              {/* REALM 3: WORD WIZARD CASTLE */}

              <div className="stage-option">

                <div className="realm-pill">Module 03</div>

                <div className="stage-number">
                  <IconEdit size={24} />
                </div>

                <h2>
                  Written Expression
                </h2>

                <p className="realm-tagline">
                  Spelling, Vocabulary & Encoding
                </p>

                <p>
                  TRACE WORDS & UNLOCK ANCIENT SPELLS
                </p>

                <div
                  className="analysis-note"
                  style={{
                    margin: "15px 0",
                  }}
                >
                  Interactive Letter Tracing & Spelling
                  <br />
                  Orthographic Word Construction
                  <br />
                  Phonological Rhyme & Syntax Evaluation
                </div>

                <button
                  className="primary-button"
                  onClick={enterStageThree}
                >
                  Begin Module 3
                </button>

              </div>

              {/* REALM 4: NUMBER NINJA TEMPLE */}

              <div className="stage-option">

                <div className="realm-pill">Module 04</div>

                <div className="stage-number">
                  <IconCalculator size={24} />
                </div>

                <h2>
                  Numerical Cognition
                </h2>

                <p className="realm-tagline">
                  Arithmetic & Quantitative Reasoning
                </p>

                <p>
                  MASTER NUMBERS & REASONING JUTSU
                </p>

                <div
                  className="analysis-note"
                  style={{
                    margin: "15px 0",
                  }}
                >
                  Addition & Subtraction Operations
                  <br />
                  Multiplication & division operations STRIKES
                  <br />
                  Applied Quantitative Reasoning
                  <br />
                  10 Math Items Per Level
                </div>

                <button
                  className="primary-button"
                  onClick={enterStageFour}
                >
                  Begin Module 4
                </button>

              </div>

              {/* REALM 5: SHAPE SHIFTER GALAXY */}

              <div className="stage-option">

                <div className="realm-pill">Module 05</div>

                <div className="stage-number">
                  <IconShapes size={24} />
                </div>

                <h2>
                  Spatial Geometry
                </h2>

                <p className="realm-tagline">
                  2D & 3D Dimensional Reasoning
                </p>

                <p>
                  WARP THROUGH 2D & 3D DIMENSIONS
                </p>

                <div
                  className="analysis-note"
                  style={{
                    margin: "15px 0",
                  }}
                >
                  2 Calibrated Spatial Levels
                  <br />
                  2D & 3D Geometric solids
                  <br />
                  Educational Shape Insights
                  <br />
                  8 Spatial Tasks Per Level
                </div>

                <button
                  className="primary-button"
                  onClick={enterShapesStage}
                >
                  Begin Module 5
                </button>

              </div>

              {/* MODULE 06: READING COMPREHENSION */}

              <div className="stage-option">

                <div className="realm-pill">Module 06</div>

                <div className="stage-number">
                  <IconBookOpen size={24} />
                </div>

                <h2>
                  Reading Comprehension
                </h2>

                <p className="realm-tagline">
                  Text Synthesis & Understanding
                </p>

                <p>
                  2 Progressive Levels • Passages & Questions
                </p>

                <div
                  className="analysis-note"
                  style={{
                    margin: "15px 0",
                  }}
                >
                  Persistent passage view & audio read-aloud
                  <br />
                  Factual, vocabulary & inference challenges
                  <br />
                  Calibrated for dyslexic reading fluency
                  <br />
                  Progress automatically recorded
                </div>

                <button
                  className="primary-button"
                  onClick={enterComprehensionStage}
                >
                  Begin Module 6
                </button>

              </div>


            </div>

          </section>

        </div>
      </div>
    );
  }

  /* =======================================================
       MODULE 06 GAME — READING COMPREHENSION
       ======================================================= */

  if (screen === "comprehension") {
    const level = playComprehensionLevels[compLevelIndex] || playComprehensionLevels[0];
    const question = level?.questions?.[compQuestionIndex] || level?.questions?.[0];

    if (!level || !question) {
      return (
        <div className="app">
          <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
          <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
          {renderAppHeader("stages")}
          <div className="page" style={{ textAlign: "center", padding: "80px 20px" }}>
            <div className="stage-card" style={{ maxWidth: 500, margin: "0 auto", padding: 30 }}>
              <h2>Comprehension Glade Ready</h2>
              <p style={{ margin: "16px 0 24px" }}>Passages for Class {selectedClass} are being calibrated.</p>
              <button className="save-button" onClick={() => { setCompLevelIndex(0); setCompQuestionIndex(0); }}>Begin Reading</button>
            </div>
          </div>
        </div>
      );
    }

    const totalQuestions = playComprehensionLevels.reduce(
      (sum, item) => sum + item.questions.length,
      0
    );

    const completedBefore = playComprehensionLevels
      .slice(0, compLevelIndex)
      .reduce((sum, item) => sum + item.questions.length, 0) + compQuestionIndex;

    const currentCompleted =
      completedBefore + (compMessage && compMessage.includes("Correct") ? 1 : 0);

    const overallProgress = Math.round((currentCompleted / totalQuestions) * 100);

    const isLastQuestion =
      compQuestionIndex === level.questions.length - 1 &&
      compLevelIndex === playComprehensionLevels.length - 1;

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("stages")}
        <div className="page">
          <div className="top-bar">
            <button
              className="back-button"
              onClick={() => {
                window.speechSynthesis?.cancel();
                setScreen("stages");
              }}
            >
              <IconChevronLeft size={16} /> Modules
            </button>
            <div className="score-display">
              <IconStar size={14} /> {compScore} XP
            </div>
          </div>

          <section className="stage-card">
            <p className="eyebrow">
              Class {selectedClass} • Module 06: Reading Comprehension
            </p>
            <h1>Reading Comprehension & Text Synthesis</h1>
            <p className="stage-description">
              Read the passage carefully, then answer the questions based on the text.
            </p>

            {/* 2 LEVEL TABS */}
            <div className="level-tabs">
              {playComprehensionLevels.map((item, index) => (
                <div
                  key={item.id}
                  className={
                    "level-tab " +
                    (index === compLevelIndex
                      ? "active"
                      : index < compLevelIndex
                        ? "completed"
                        : "")
                  }
                >
                  <span>
                    {index < compLevelIndex ? <IconCheck size={14} /> : item.id}
                  </span>
                  <div>
                    <strong>{item.title}</strong>
                    <small>{item.difficulty}</small>
                  </div>
                </div>
              ))}
            </div>

            {/* OVERALL PROGRESS */}
            <div className="progress-area">
              <div className="progress-label">
                <span>Module 06 Progress</span>
                <span>{currentCompleted} / {totalQuestions}</span>
              </div>
              <div className="progress-track">
                <div
                  className="progress-fill"
                  style={{ width: `${overallProgress}%` }}
                />
              </div>
            </div>

            {/* COMPREHENSION LAYOUT: PASSAGE + QUESTION */}
            <div className="comprehension-layout">
              {/* 1. PASSAGE CARD */}
              <div className="passage-card">
                <div className="passage-header">
                  <span className="passage-badge">
                    <IconBookOpen size={13} /> {level.readingLevel} • {level.title}
                  </span>
                  <div className="passage-controls">
                    <button
                      type="button"
                      className="shape-fact-audio-btn read-aloud-btn"
                      onClick={() => readPassageAloud(level.passage)}
                      title="Listen to full passage"
                    >
                      <IconVolume size={15} /> 🔊 Read Passage Aloud
                    </button>
                  </div>
                </div>
                <h3 className="passage-title">{level.passageTitle}</h3>
                <div className="passage-content">
                  {level.passage}
                </div>
              </div>

              {/* 2. QUESTION PANEL */}
              <div className="question-panel">
                <div className="question-panel-header">
                  <span className="question-counter-pill">
                    Question {compQuestionIndex + 1} of {level.questions.length}
                  </span>
                  <div style={{ display: "flex", gap: "10px", alignItems: "center", flexWrap: "wrap" }}>
                    {!compHintUsed ? (
                      <button
                        type="button"
                        className="btn-unlock-clue"
                        style={{ padding: "6px 14px", fontSize: "0.85rem" }}
                        onClick={useComprehensionHint}
                        disabled={compScore < 5}
                        title={compScore < 5 ? "Need at least 5 XP to unlock clue" : "Click to reveal helpful pedagogical clue (-5 XP)"}
                      >
                        <IconLightbulb size={16} /> 💡 Conceptual Hint (-5 XP)
                      </button>
                    ) : (
                      <span style={{ display: "inline-flex", alignItems: "center", gap: "6px", fontSize: "0.85rem", fontWeight: "800", color: "#92400e", background: "#fef3c7", padding: "5px 12px", borderRadius: "8px", border: "1.5px solid #f59e0b" }}>
                        <IconLightbulb size={15} /> 💡 Clue Unlocked Below
                      </span>
                    )}
                    <button
                      type="button"
                      className="shape-fact-audio-btn read-aloud-btn"
                      onClick={() => readQuestionAloud(question.question)}
                      title="Read question aloud"
                    >
                      <IconVolume size={14} /> 🔊 Read Question
                    </button>
                  </div>
                </div>

                <h4 className="question-text-title">{question.question}</h4>

                {/* OPTIONS GRID */}
                <div className="comprehension-options-grid">
                  {question.options.map((option, idx) => {
                    const isSelected = compAnswer === option;
                    const isCorrectOption = option === question.answer;
                    const showFeedback = Boolean(compMessage);

                    let btnClass = "comprehension-option-btn";
                    if (showFeedback && isSelected) {
                      btnClass += isCorrectOption ? " selected-correct" : " selected-wrong";
                    }

                    return (
                      <button
                        key={idx}
                        type="button"
                        className={btnClass}
                        onClick={() => answerComprehensionQuestion(option)}
                        disabled={compMessage && compMessage.includes("Correct")}
                      >
                        <span style={{
                          minWidth: "26px",
                          height: "26px",
                          borderRadius: "50%",
                          background: isSelected ? (isCorrectOption ? "#15803d" : "#dc2626") : "#e2e8f0",
                          color: isSelected ? "#ffffff" : "#1e293b",
                          display: "inline-flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontSize: "13px",
                          fontWeight: "800",
                          border: isSelected ? "none" : "1.5px solid #cbd5e1"
                        }}>
                          {String.fromCharCode(65 + idx)}
                        </span>
                        {option}
                      </button>
                    );
                  })}
                </div>

                {/* FEEDBACK */}
                {compMessage && (
                  <div
                    className={
                      compMessage.includes("Correct")
                        ? "feedback correct-feedback"
                        : compMessage.includes("Hint unlocked")
                        ? "hint-unlocked-banner"
                        : "feedback wrong-feedback"
                    }
                  >
                    {compMessage.includes("Hint unlocked") ? (
                      <>
                        <IconLightbulb size={18} />
                        <span>{compMessage}</span>
                      </>
                    ) : (
                      compMessage
                    )}
                  </div>
                )}

                {/* HINT DRAWER */}
                {compHint && (
                  <div className="shape-fact-card pedagogical-clue-card" style={{ marginTop: "16px" }}>
                    <div className="shape-fact-header">
                      <span className="shape-fact-title">
                        <IconLightbulb size={18} /> 💡 PEDAGOGICAL CLUE
                      </span>
                      <button
                        type="button"
                        className="shape-fact-audio-btn read-aloud-btn"
                        onClick={() => readQuestionAloud(compHint)}
                        title="Click to hear this clue read aloud"
                      >
                        <IconVolume size={14} /> 🔊 Read Clue Aloud
                      </button>
                    </div>
                    <div className="shape-fact-body" style={{ color: "#0f172a", fontSize: "1.1rem", fontWeight: "700" }}>
                      {compHint}
                    </div>
                  </div>
                )}

                {/* CONTROLS */}
                <div style={{ display: "flex", gap: "12px", flexWrap: "wrap", marginTop: "18px", alignItems: "center" }}>
                  {!compHintUsed && (
                    <button
                      type="button"
                      className="btn-unlock-clue"
                      onClick={useComprehensionHint}
                      disabled={compScore < 5}
                      title={compScore < 5 ? "Need at least 5 XP to unlock clue" : "Click to reveal helpful pedagogical clue (-5 XP)"}
                    >
                      <IconLightbulb size={18} /> 💡 Conceptual Hint (-5 XP)
                    </button>
                  )}

                  {compMessage && compMessage.includes("Correct") && (
                    <button
                      type="button"
                      className="save-button next-button"
                      style={{ marginTop: 0 }}
                      onClick={nextComprehensionExercise}
                    >
                      {isLastQuestion ? "Complete Module 6" : "Next Question →"}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    );
  }

  /* =======================================================
     MODULE 06 PROGRESS REPORT (COMPREHENSION)
     ======================================================= */

  if (screen === "comprehensionReport") {
    const totalQuestions = playComprehensionLevels.reduce(
      (sum, item) => sum + item.questions.length,
      0
    );

    const maxPossibleXP = totalQuestions * 3;
    const accuracy = totalQuestions > 0
      ? Math.min(100, Math.round((compScore / maxPossibleXP) * 100))
      : 0;

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("teacher")}
        <div className="page">
          <section className="complete-card">
            <div className="complete-icon">
              <IconAward size={36} />
            </div>
            <p className="eyebrow">Module 06 Assessment Completed</p>
            <h1>Reading Comprehension Mastered</h1>
            <h2>{studentName || "Student"}</h2>
            <p>
              You successfully read the passages, synthesized the text, and answered comprehension challenges.
            </p>

            <div className="final-score" style={{ margin: "25px 0" }}>
              {totalQuestions} / {totalQuestions}
              <div style={{ fontSize: "18px", marginTop: "8px" }}>
                Comprehension Tasks Completed
              </div>
            </div>

            <div className="analysis-grid" style={{ marginTop: "20px" }}>
              <div className="analysis-item">
                <span><IconStar size={16} /></span>
                <strong>Comprehension Score</strong>
                <p>{compScore} XP</p>
              </div>

              <div className="analysis-item">
                <span><IconTarget size={16} /></span>
                <strong>Performance</strong>
                <p>{accuracy}%</p>
              </div>

              <div className="analysis-item">
                <span><IconLayers size={16} /></span>
                <strong>Levels</strong>
                <p>2 / 2 Completed</p>
              </div>

              <div className="analysis-item">
                <span><IconGraduationCap size={16} /></span>
                <strong>Grade</strong>
                <p>Class {selectedClass}</p>
              </div>
            </div>

            <div className="analysis-note" style={{ margin: "25px 0" }}>
              Skills Evaluated:
              <br />
              Main Idea & Topic Comprehension
              <br />
              Explicit Text Details & Direct Recall
              <br />
              Vocabulary in Context & Meaning Retrieval
              <br />
              Inferential Reasoning & Synthesis
            </div>

            <StageComprehensiveAnalysis
              stageKey="comprehension"
              stageName="Module 06: Reading Comprehension & Text Synthesis"
              performance={stagePerformance.comprehension}
              totalQuestions={totalQuestions}
              studentName={studentName}
              studentClass={selectedClass}
              score={compScore}
              onRestart={restartComprehensionStage}
              onNextStage={() => setScreen("stages")}
              nextStageTitle="Return to Assessment Modules"
            />
          </section>
        </div>
      </div>
    );
  }

  /* =======================================================
     STAGE 5 GAME — SHAPES QUEST
     ======================================================= */

  if (screen === "shapes") {
    const level = playShapesLevels[shapesLevelIndex] || playShapesLevels[0];
    const exercise = level?.exercises?.[shapesExerciseIndex] || level?.exercises?.[0];

    if (!level || !exercise) {
      return (
        <div className="app">
          <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
          <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
          {renderAppHeader("stages")}
          <div className="page" style={{ textAlign: "center", padding: "80px 20px" }}>
            <div className="stage-card" style={{ maxWidth: 500, margin: "0 auto", padding: 30 }}>
              <h2>Sunstone Altar Ready</h2>
              <p style={{ margin: "16px 0 24px" }}>3D geometry challenges for Class {selectedClass} are aligning.</p>
              <button className="save-button" onClick={() => { setShapesLevelIndex(0); setShapesExerciseIndex(0); }}>Awaken Altar</button>
            </div>
          </div>
        </div>
      );
    }

    const totalQuestions = playShapesLevels.reduce(
      (sum, item) => sum + item.exercises.length,
      0
    );

    const completedBefore = playShapesLevels
      .slice(0, shapesLevelIndex)
      .reduce((sum, item) => sum + item.exercises.length, 0) + shapesExerciseIndex;

    const currentCompleted =
      completedBefore + (shapesMessage && shapesMessage.includes("Correct") ? 1 : 0);

    const overallProgress = Math.round((currentCompleted / totalQuestions) * 100);

    const levelCompleted =
      shapesExerciseIndex + (shapesMessage && shapesMessage.includes("Correct") ? 1 : 0);

    const levelProgress = Math.round((levelCompleted / level.exercises.length) * 100);

    const isLastQuestion =
      shapesExerciseIndex === level.exercises.length - 1 &&
      shapesLevelIndex === playShapesLevels.length - 1;

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("stages")}
        <div className="page">
          <div className="top-bar">
            <button
              className="back-button"
              onClick={() => {
                window.speechSynthesis?.cancel();
                setScreen("stages");
              }}
            >
              ← STAGES
            </button>
            <div className="score-display">
              {shapesScore} XP
            </div>
          </div>

          <section className="stage-card">
            <p className="eyebrow">
              Class {selectedClass} • Module 05: Spatial Geometry
            </p>
            <h1>Spatial Geometry & Structural Reasoning</h1>
            <p className="stage-description">
              WARP THROUGH 2D & 3D DIMENSIONS, COUNT SIDES & CORNERS, AND DISCOVER FUN SHAPE FACTS!
            </p>

            {/* 2 LEVEL TABS */}
            <div className="level-tabs">
              {playShapesLevels.map((item, index) => (
                <div
                  key={item.id}
                  className={
                    "level-tab " +
                    (index === shapesLevelIndex
                      ? "active"
                      : index < shapesLevelIndex
                        ? "completed"
                        : "")
                  }
                >
                  <span>
                    {index < shapesLevelIndex ? <IconCheck size={14} /> : item.id}
                  </span>
                  <div>
                    <strong>{item.title}</strong>
                    <small>{item.difficulty}</small>
                  </div>
                </div>
              ))}
            </div>

            {/* OVERALL PROGRESS */}
            <div className="progress-area">
              <div className="progress-label">
                <span>Module 05 Progress</span>
                <span>{currentCompleted} / {totalQuestions}</span>
              </div>
              <div className="progress-track">
                <div
                  className="progress-fill"
                  style={{ width: `${overallProgress}%` }}
                />
              </div>
              <p
                style={{
                  textAlign: "center",
                  fontWeight: "700",
                  marginTop: "8px",
                }}
              >
                {overallProgress}% COMPLETED
              </p>
            </div>

            {/* CURRENT LEVEL PROGRESS */}
            <div className="progress-area">
              <div className="progress-label">
                <span>{level.title} PROGRESS</span>
                <span>{levelCompleted} / {level.exercises.length}</span>
              </div>
              <div className="progress-track">
                <div
                  className="progress-fill"
                  style={{ width: `${levelProgress}%` }}
                />
              </div>
            </div>

            {/* EXERCISE CARD */}
            <div className="exercise-card">
              <div className="exercise-header">
                <span className="exercise-type">Module 05: Spatial Geometry</span>
                <span>
                  QUESTION {shapesExerciseIndex + 1} / {level.exercises.length}
                </span>
              </div>

              <h2>{exercise.question}</h2>

              {/* CENTRAL SHAPE DISPLAY */}
              {exercise.shape && (
                <div className="shape-display-card">
                  <ShapeVisual shape={exercise.shape} size={110} />
                </div>
              )}

              {/* READ ALOUD BUTTON */}
              <button
                type="button"
                className="shape-fact-audio-btn read-aloud-btn"
                style={{ marginTop: "12px" }}
                onClick={() => {
                  if ("speechSynthesis" in window) {
                    window.speechSynthesis.cancel();
                    const utterance = new SpeechSynthesisUtterance(exercise.question);
                    utterance.rate = 0.8;
                    utterance.pitch = 1.05;
                    window.speechSynthesis.speak(utterance);
                  }
                }}
              >
                <IconVolume size={14} /> 🔊 Read Question Aloud
              </button>

              {/* ANSWER OPTIONS GRID */}
              <div className="answer-grid" style={{ marginTop: "24px" }}>
                {exercise.options.map((option) => {
                  const isSelected = shapesAnswer === option;
                  const isCorrect = option === exercise.answer;

                  let buttonClass = "answer-button ";
                  if (isSelected) {
                    buttonClass += isCorrect ? "correct" : "wrong";
                  }

                  return (
                    <button
                      key={option}
                      className={buttonClass}
                      disabled={Boolean(shapesMessage && shapesMessage.includes("Correct"))}
                      onClick={() => answerShapesQuestion(option)}
                    >
                      {option}
                    </button>
                  );
                })}
              </div>

              {/* FEEDBACK */}
              {shapesMessage && (
                <div
                  className={
                    shapesMessage.includes("Correct")
                      ? "feedback correct-feedback"
                      : "feedback wrong-feedback"
                  }
                  style={{ marginTop: "20px" }}
                >
                  {shapesMessage}
                </div>
              )}

              {/* OPTIONAL FUN SHAPE FACT CARD */}
              {showShapeFact && exercise.fact && (
                <div className="shape-fact-card">
                  <div className="shape-fact-header">
                    <div className="shape-fact-title">
                      Educational Shape Insight:
                    </div>
                    <button
                      type="button"
                      className="shape-fact-audio-btn read-aloud-btn"
                      onClick={() => {
                        if ("speechSynthesis" in window) {
                          window.speechSynthesis.cancel();
                          const u = new SpeechSynthesisUtterance(exercise.fact);
                          u.rate = 0.85;
                          window.speechSynthesis.speak(u);
                        }
                      }}
                    >
                      <IconVolume size={14} /> 🔊 Read Fact Aloud
                    </button>
                  </div>
                  <div className="shape-fact-body">
                    {exercise.fact}
                  </div>
                </div>
              )}

              {shapesHint && (
                <div className="shape-fact-card pedagogical-clue-card" style={{ marginTop: "16px" }}>
                  <div className="shape-fact-header">
                    <span className="shape-fact-title">
                      <IconLightbulb size={18} /> 💡 PEDAGOGICAL HINT
                    </span>
                    <button
                      type="button"
                      className="shape-fact-audio-btn read-aloud-btn"
                      onClick={() => {
                        if ("speechSynthesis" in window) {
                          window.speechSynthesis.cancel();
                          const u = new SpeechSynthesisUtterance(shapesHint);
                          u.rate = 0.85;
                          window.speechSynthesis.speak(u);
                        }
                      }}
                    >
                      <IconVolume size={14} /> 🔊 Read Hint Aloud
                    </button>
                  </div>
                  <div className="shape-fact-body">
                    {shapesHint}
                  </div>
                </div>
              )}

              {/* ACTION BUTTONS */}
              {shapesMessage && !shapesMessage.includes("Correct") && (
                <div
                  style={{
                    display: "flex",
                    gap: "12px",
                    justifyContent: "center",
                    marginTop: "18px",
                    flexWrap: "wrap",
                  }}
                >
                  <button
                    type="button"
                    className="secondary-button"
                    onClick={() => {
                      setShapesAnswer("");
                      setShapesMessage("");
                    }}
                  >
                    Try Again
                  </button>

                  {!shapesHintUsed && (
                    <button
                      type="button"
                      className="btn-unlock-clue"
                      onClick={useShapesHint}
                      disabled={shapesScore < 5}
                    >
                      <IconLightbulb size={16} /> 💡 Conceptual Hint (-5 XP)
                    </button>
                  )}
                </div>
              )}

              {shapesMessage && shapesMessage.includes("Correct") && (
                <button
                  type="button"
                  className="save-button next-button"
                  style={{ marginTop: "20px" }}
                  onClick={nextShapesExercise}
                >
                  {isLastQuestion ? "Complete Module 5" : "Next Question →"}
                </button>
              )}
            </div>
          </section>
        </div>
      </div>
    );
  }

  /* =======================================================
     STAGE 5 PROGRESS REPORT (SHAPES QUEST)
     ======================================================= */

  if (screen === "shapesReport") {
    const totalQuestions = playShapesLevels.reduce(
      (sum, item) => sum + item.exercises.length,
      0
    );

    const maxPossibleXP = totalQuestions * 3;
    const accuracy = totalQuestions > 0
      ? Math.min(100, Math.round((shapesScore / maxPossibleXP) * 100))
      : 0;

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("teacher")}
        <div className="page">
          <section className="complete-card">
            <div className="complete-icon"><IconAward size={36} /></div>
            <p className="eyebrow">Module 05 Assessment Completed</p>
            <h1>SHAPES MASTER!</h1>
            <h2>{studentName || "STUDENT"}</h2>
            <p>
              YOU MASTERED 2D AND 3D SHAPES, SIDES, CORNERS, AND REAL-WORLD GEOMETRY.
            </p>

            <div className="final-score" style={{ margin: "25px 0" }}>
              {totalQuestions} / {totalQuestions}
              <div style={{ fontSize: "18px", marginTop: "8px" }}>
                SHAPES CHALLENGES COMPLETED
              </div>
            </div>

            <div className="analysis-grid" style={{ marginTop: "20px" }}>
              <div className="analysis-item">
                <span><IconStar size={16} /></span>
                <strong>SHAPES SCORE</strong>
                <p>{shapesScore} XP</p>
              </div>

              <div className="analysis-item">
                <span><IconTarget size={16} /></span>
                <strong>PERFORMANCE</strong>
                <p>{accuracy}%</p>
              </div>

              <div className="analysis-item">
                <span><IconShapes size={16} /></span>
                <strong>LEVELS</strong>
                <p>2 / 2 COMPLETED</p>
              </div>

              <div className="analysis-item">
                <span><IconAward size={16} /></span>
                <strong>GRADE</strong>
                <p>CLASS {selectedClass}</p>
              </div>
            </div>

            <div className="analysis-note" style={{ margin: "25px 0" }}>
              Skills Evaluated:
              <br />
              Circles, squares, triangles & rectangles
              <br />
              Stars, hearts, diamonds & ovals
              <br />
              Polygons, vertices, sides & corners
              <br />
              3D Solids: cubes, spheres, cylinders & cones
            </div>

            <StageComprehensiveAnalysis
              stageKey="shapes"
              stageName="Module 05: Spatial Geometry & Structural Reasoning"
              performance={stagePerformance.shapes}
              totalQuestions={totalQuestions}
              studentName={studentName}
              studentClass={selectedClass}
              score={shapesScore}
              onRestart={restartShapesStage}
              onNextStage={() => setScreen("stages")}
              nextStageTitle="Return to Assessment Modules"
            />
          </section>
        </div>
      </div>
    );
  }

  /* =======================================================
     STAGE 4 GAME — MATHS QUEST
     ======================================================= */

  if (screen === "stage4") {
    const level = playStage4Levels[stage4LevelIndex] || playStage4Levels[0];
    const exercise = level?.exercises?.[stage4ExerciseIndex] || level?.exercises?.[0];

    if (!level || !exercise) {
      return (
        <div className="app">
          <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
          <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
          {renderAppHeader("stages")}
          <div className="page" style={{ textAlign: "center", padding: "80px 20px" }}>
            <div className="stage-card" style={{ maxWidth: 500, margin: "0 auto", padding: 30 }}>
              <h2>Maths Jutsu Temple Ready</h2>
              <p style={{ margin: "16px 0 24px" }}>Numerical challenges for Class {selectedClass} are ready.</p>
              <button className="save-button" onClick={() => { setStage4LevelIndex(0); setStage4ExerciseIndex(0); }}>Enter Temple</button>
            </div>
          </div>
        </div>
      );
    }

    const totalQuestions = playStage4Levels.reduce(
      (sum, item) => sum + item.exercises.length,
      0
    );

    const completedBefore = playStage4Levels
      .slice(0, stage4LevelIndex)
      .reduce((sum, item) => sum + item.exercises.length, 0) + stage4ExerciseIndex;

    const currentCompleted =
      completedBefore + (stage4Message && stage4Message.includes("Correct") ? 1 : 0);

    const overallProgress = Math.round((currentCompleted / totalQuestions) * 100);

    const levelCompleted =
      stage4ExerciseIndex + (stage4Message && stage4Message.includes("Correct") ? 1 : 0);

    const levelProgress = Math.round((levelCompleted / level.exercises.length) * 100);

    const isLastQuestion =
      stage4ExerciseIndex === level.exercises.length - 1 &&
      stage4LevelIndex === playStage4Levels.length - 1;

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("stages")}
        <div className="page">
          <div className="top-bar">
            <button
              className="back-button"
              onClick={() => {
                window.speechSynthesis?.cancel();
                setScreen("stages");
              }}
            >
              ← STAGES
            </button>
            <div className="score-display">
              {stage4Score} XP
            </div>
          </div>

          <section className="stage-card">
            <p className="eyebrow">
              Class {selectedClass} • Module 04: Numerical Cognition
            </p>
            <h1>Numerical Cognition & Mathematics</h1>
            <p className="stage-description">
              MASTER NUMBER REASONING & ARITHMETIC JUTSU STEP BY STEP.
            </p>

            {/* LEVEL TABS */}
            <div className="level-tabs">
              {playStage4Levels.map((item, index) => (
                <div
                  key={item.id}
                  className={
                    "level-tab " +
                    (index === stage4LevelIndex
                      ? "active"
                      : index < stage4LevelIndex
                        ? "completed"
                        : "")
                  }
                >
                  <span>
                    {index < stage4LevelIndex ? <IconCheck size={14} /> : item.id}
                  </span>
                  <div>
                    <strong>{item.title}</strong>
                    <small>{item.difficulty}</small>
                  </div>
                </div>
              ))}
            </div>

            {/* OVERALL PROGRESS */}
            <div className="progress-area">
              <div className="progress-label">
                <span>Module 04 Progress</span>
                <span>{currentCompleted} / {totalQuestions}</span>
              </div>
              <div className="progress-track">
                <div
                  className="progress-fill"
                  style={{ width: `${overallProgress}%` }}
                />
              </div>
              <p
                style={{
                  textAlign: "center",
                  fontWeight: "700",
                  marginTop: "8px",
                }}
              >
                {overallProgress}% COMPLETED
              </p>
            </div>

            {/* CURRENT LEVEL PROGRESS */}
            <div className="progress-area">
              <div className="progress-label">
                <span>{level.title} PROGRESS</span>
                <span>{levelCompleted} / {level.exercises.length}</span>
              </div>
              <div className="progress-track">
                <div
                  className="progress-fill"
                  style={{ width: `${levelProgress}%` }}
                />
              </div>
            </div>

            {/* EXERCISE CARD */}
            <div className="exercise-card">
              <div className="exercise-header">
                <span className="exercise-type">Module 04: Mathematics</span>
                <span>
                  QUESTION {stage4ExerciseIndex + 1} / {level.exercises.length}
                </span>
              </div>

              <h2>SOLVE THIS QUESTION</h2>

              <div
                className="reading-target"
                style={{
                  fontSize: "32px",
                  padding: "24px 20px",
                  margin: "20px 0",
                  letterSpacing: "1px",
                }}
              >
                {exercise.question}
              </div>

              {/* READ ALOUD BUTTON */}
              <button
                type="button"
                className="shape-fact-audio-btn read-aloud-btn"
                style={{ marginTop: "12px" }}
                onClick={() => {
                  if ("speechSynthesis" in window) {
                    window.speechSynthesis.cancel();
                    const utterance = new SpeechSynthesisUtterance(exercise.question);
                    utterance.rate = 0.8;
                    utterance.pitch = 1.05;
                    window.speechSynthesis.speak(utterance);
                  }
                }}
              >
                <IconVolume size={14} /> 🔊 Read Question Aloud
              </button>

              {/* ANSWER OPTIONS GRID */}
              <div className="answer-grid" style={{ marginTop: "24px" }}>
                {exercise.options.map((option) => {
                  const isSelected = stage4Answer === option;
                  const isCorrect = option === exercise.answer;

                  let buttonClass = "answer-button ";
                  if (isSelected) {
                    buttonClass += isCorrect ? "correct" : "wrong";
                  }

                  return (
                    <button
                      key={option}
                      className={buttonClass}
                      disabled={Boolean(stage4Message && stage4Message.includes("Correct"))}
                      onClick={() => answerStageFourQuestion(option)}
                    >
                      {option}
                    </button>
                  );
                })}
              </div>

              {/* FEEDBACK & HINT */}
              {stage4Message && (
                <div
                  className={
                    stage4Message.includes("Correct")
                      ? "feedback correct-feedback"
                      : "feedback wrong-feedback"
                  }
                  style={{ marginTop: "20px" }}
                >
                  {stage4Message}
                </div>
              )}

              {stage4Hint && (
                <div className="shape-fact-card pedagogical-clue-card" style={{ marginTop: "16px" }}>
                  <div className="shape-fact-header">
                    <span className="shape-fact-title">
                      <IconLightbulb size={18} /> 💡 PEDAGOGICAL HINT
                    </span>
                    <button
                      type="button"
                      className="shape-fact-audio-btn read-aloud-btn"
                      onClick={() => {
                        if ("speechSynthesis" in window) {
                          window.speechSynthesis.cancel();
                          const u = new SpeechSynthesisUtterance(stage4Hint);
                          u.rate = 0.85;
                          window.speechSynthesis.speak(u);
                        }
                      }}
                    >
                      <IconVolume size={14} /> 🔊 Read Hint Aloud
                    </button>
                  </div>
                  <div className="shape-fact-body">
                    {stage4Hint}
                  </div>
                </div>
              )}

              {/* ACTION BUTTONS */}
              {stage4Message && !stage4Message.includes("Correct") && (
                <div
                  style={{
                    display: "flex",
                    gap: "12px",
                    justifyContent: "center",
                    marginTop: "18px",
                    flexWrap: "wrap",
                  }}
                >
                  <button
                    type="button"
                    className="secondary-button"
                    onClick={() => {
                      setStage4Answer("");
                      setStage4Message("");
                    }}
                  >
                    Try Again
                  </button>

                  {!stage4HintUsed && (
                    <button
                      type="button"
                      className="btn-unlock-clue"
                      onClick={useStageFourHint}
                      disabled={stage4Score < 5}
                    >
                      <IconLightbulb size={16} /> 💡 Conceptual Hint (-5 XP)
                    </button>
                  )}
                </div>
              )}

              {stage4Message && stage4Message.includes("Correct") && (
                <button
                  type="button"
                  className="save-button next-button"
                  style={{ marginTop: "20px" }}
                  onClick={nextStageFourExercise}
                >
                  {isLastQuestion ? "Complete Module 4" : "Next Question →"}
                </button>
              )}
            </div>
          </section>
        </div>
      </div>
    );
  }

  /* =======================================================
     STAGE 4 PROGRESS REPORT
     ======================================================= */

  if (screen === "stage4Report") {
    const totalQuestions = playStage4Levels.reduce(
      (sum, item) => sum + item.exercises.length,
      0
    );

    const maxPossibleXP = totalQuestions * 3;
    const accuracy = totalQuestions > 0
      ? Math.min(100, Math.round((stage4Score / maxPossibleXP) * 100))
      : 0;

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("teacher")}
        <div className="page">
          <section className="complete-card">
            <div className="complete-icon"><IconAward size={36} /></div>
            <p className="eyebrow">Module 04 Assessment Completed</p>
            <h1>MATHS MASTER!</h1>
            <h2>{studentName || "STUDENT"}</h2>
            <p>
              YOU COMPLETED ARITHMETIC, COUNTING AND SHAPE REASONING CHALLENGES.
            </p>

            <div className="final-score" style={{ margin: "25px 0" }}>
              {totalQuestions} / {totalQuestions}
              <div style={{ fontSize: "18px", marginTop: "8px" }}>
                MATHS CHALLENGES COMPLETED
              </div>
            </div>

            <div className="analysis-grid" style={{ marginTop: "20px" }}>
              <div className="analysis-item">
                <span><IconStar size={16} /></span>
                <strong>MATHS SCORE</strong>
                <p>{stage4Score} XP</p>
              </div>

              <div className="analysis-item">
                <span><IconTarget size={16} /></span>
                <strong>PERFORMANCE</strong>
                <p>{accuracy}%</p>
              </div>

              <div className="analysis-item">
                <span><IconCalculator size={16} /></span>
                <strong>LEVELS</strong>
                <p>3 / 3 COMPLETED</p>
              </div>

              <div className="analysis-item">
                <span><IconAward size={16} /></span>
                <strong>GRADE</strong>
                <p>CLASS {selectedClass}</p>
              </div>
            </div>

            <div className="analysis-note" style={{ margin: "25px 0" }}>
              Skills Evaluated:
              <br />
              Addition & numerical sequences
              <br />
              Subtraction & place-value relations
              <br />
              Multiplication & division operations
              <br />
              Perimeters, measurements & geometric logic
            </div>

            <StageComprehensiveAnalysis
              stageKey="stage4"
              stageName="Module 04: Numerical Cognition & Mathematics"
              performance={stagePerformance.stage4}
              totalQuestions={totalQuestions}
              studentName={studentName}
              studentClass={selectedClass}
              score={stage4Score}
              onRestart={restartStageFour}
              onNextStage={enterShapesStage}
              nextStageTitle="Continue to Module 05 (Spatial Geometry) →"
            />
          </section>
        </div>
      </div>
    );
  }

  /* =======================================================
     STAGE 1 GAME
     CLASS-SPECIFIC • VISUAL ONLY
     3 LEVELS × 9 QUESTIONS = 27 QUESTIONS
     ======================================================= */

  /* =======================================================
     STAGE 3 GAME — WRITTEN EXPRESSION & ENCODING
     ======================================================= */
  if (screen === "stage3") {
    const stage3Bank =
      playStage3Levels && playStage3Levels.length > 0
        ? playStage3Levels
        : getStage3LevelsForClass(selectedClass);

    const level = stage3Bank[stage3LevelIndex] || stage3Bank[0];
    const exercise =
      level?.exercises?.[stage3ExerciseIndex] || level?.exercises?.[0];

    if (!level || !exercise) {
      return (
        <div className="app">
          <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
          <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
          {renderAppHeader("stages")}
          <div className="page" style={{ textAlign: "center", padding: "80px 20px" }}>
            <div className="stage-card" style={{ maxWidth: 500, margin: "0 auto", padding: 30 }}>
              <h2>Treehouse Glade Ready</h2>
              <p style={{ margin: "16px 0 24px" }}>Written expression challenges for Class {selectedClass} are ready.</p>
              <button className="save-button" onClick={() => { setStage3LevelIndex(0); setStage3ExerciseIndex(0); }}>Enter Treehouse</button>
            </div>
          </div>
        </div>
      );
    }

    const totalQuestions = stage3Bank.reduce(
      (sum, item) => sum + item.exercises.length,
      0
    );

    const completedBefore =
      stage3Bank
        .slice(0, stage3LevelIndex)
        .reduce(
          (sum, item) => sum + item.exercises.length,
          0
        ) + stage3ExerciseIndex;

    const completed =
      Math.min(
        completedBefore +
        (stage3Message === "CORRECT!" ? 1 : 0),
        totalQuestions
      );

    const overallProgress =
      Math.round((completed / totalQuestions) * 100);

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("stages")}
        <div className="page">
          <div className="top-bar">
            <button
              className="back-button"
              onClick={() => setScreen("stages")}
            >
              ← STAGES
            </button>

            <div className="score-display">
              {stage3Score} XP
            </div>
          </div>

          <section className="stage-card">
            <p className="eyebrow">
              Class {selectedClass} • Module 03: Written Expression
            </p>

            <h1>Written Expression & Language Encoding</h1>

            <p className="stage-description">
              CAST SPELLING SPELLS AND EXPAND WORD UNDERSTANDING STEP BY STEP.
            </p>

            <div className="level-tabs">
              {stage3Bank.map((item, index) => (
                <div
                  key={item.id}
                  className={
                    "level-tab " +
                    (index === stage3LevelIndex
                      ? "active"
                      : index < stage3LevelIndex
                        ? "completed"
                        : "")
                  }
                >
                  <span>
                    {index < stage3LevelIndex ? <IconCheck size={14} /> : item.id}
                  </span>
                  <div>
                    <strong>{item.title}</strong>
                    <small>{item.difficulty}</small>
                  </div>
                </div>
              ))}
            </div>

            <div className="progress-area">
              <div className="progress-label">
                <span>Module 03 Progress</span>
                <span>{completed} / {totalQuestions}</span>
              </div>

              <div className="progress-track">
                <div
                  className="progress-fill"
                  style={{
                    width: `${overallProgress}%`,
                  }}
                />
              </div>
            </div>

            <div className="exercise-card">
              <div className="exercise-header">
                <span className="exercise-type">
                  Module 03: Written Expression
                </span>
                <span>
                  QUESTION {stage3ExerciseIndex + 1}/
                  {level.exercises.length}
                </span>
              </div>

              <h2>{exercise.prompt}</h2>

              <div
                className="stage3-options"
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "10px",
                  marginTop: "20px",
                  marginBottom: "20px",
                }}
              >
                {exercise.options.map((option, index) => (
                  <div
                    key={index}
                    style={{
                      padding: "12px 16px",
                      border: "2px solid #ddd",
                      borderRadius: "10px",
                      textAlign: "center",
                      fontWeight: "600",
                      pointerEvents: "none",
                    }}
                  >
                    {option}
                  </div>
                ))}
              </div>

              <div
                className="answer-options"
                style={{
                  display: "grid",
                  gap: "12px",
                  marginTop: "20px",
                }}
              >
                <div
                  className="answer-options"
                  style={{
                    marginTop: "20px",
                    display: "flex",
                    flexDirection: "column",
                    gap: "12px",
                    alignItems: "center",
                  }}
                >
                  <input
                    type="text"
                    value={stage3Answer}
                    onChange={(e) => setStage3Answer(e.target.value)}
                    placeholder="Type your answer here..."
                    disabled={stage3Message === "CORRECT!"}
                    style={{
                      width: "100%",
                      maxWidth: "500px",
                      padding: "14px 16px",
                      fontSize: "18px",
                      borderRadius: "12px",
                      border: "2px solid #ddd",
                      textAlign: "center",
                    }}
                  />

                  <button
                    type="button"
                    className="primary-button"
                    disabled={
                      !stage3Answer.trim() ||
                      stage3Message === "CORRECT!"
                    }
                    onClick={() => {
                      const typedAnswer = stage3Answer.trim().toLowerCase();
                      const correctAnswer = String(exercise.answer || "")
                        .trim()
                        .toLowerCase();

                      if (typedAnswer === correctAnswer) {
                        setStage3Message("CORRECT!");
                        setStage3Score((previous) => previous + 3);
                        recordStagePerformance("stage3", true, exercise, typedAnswer);
                      } else {
                        setStage3Message("WRONG ANSWER");
                        recordStagePerformance("stage3", false, exercise, typedAnswer);
                      }
                    }}
                  >
                    CHECK ANSWER
                  </button>
                </div>
              </div>

              {stage3Message === "WRONG ANSWER" && (
                <>
                  <div
                    className="feedback wrong-feedback"
                    style={{ marginTop: "18px" }}
                  >
                    WRONG ANSWER
                  </div>

                  {!stage3HintUsed && (
                    <button
                      type="button"
                      className="btn-unlock-clue"
                      style={{ marginTop: "15px" }}
                      disabled={stage3Score < 5}
                      onClick={() => {
                        if (stage3Score < 5) {
                          setStage3Hint(
                            "You need at least 5 XP to use a hint."
                          );
                          return;
                        }

                        setStage3Score(
                          (previous) => previous - 5
                        );

                        setStage3HintUsed(true);
                        setStage3Hint(getStage3Hint(exercise));
                        recordHintUsed("stage3");
                      }}
                    >
                      <IconLightbulb size={16} /> 💡 Conceptual Hint (-5 XP)
                    </button>
                  )}

                  {stage3Hint && (
                    <div className="shape-fact-card pedagogical-clue-card" style={{ marginTop: "16px" }}>
                      <div className="shape-fact-header">
                        <span className="shape-fact-title">
                          <IconLightbulb size={18} /> 💡 PEDAGOGICAL HINT
                        </span>
                        <button
                          type="button"
                          className="shape-fact-audio-btn read-aloud-btn"
                          onClick={() => {
                            if ("speechSynthesis" in window) {
                              window.speechSynthesis.cancel();
                              const u = new SpeechSynthesisUtterance(stage3Hint);
                              u.rate = 0.85;
                              window.speechSynthesis.speak(u);
                            }
                          }}
                        >
                          <IconVolume size={14} /> 🔊 Read Hint Aloud
                        </button>
                      </div>
                      <div className="shape-fact-body">
                        {stage3Hint}
                      </div>
                    </div>
                  )}

                  <button
                    type="button"
                    className="secondary-button"
                    style={{ marginTop: "15px" }}
                    onClick={() => {
                      setStage3Answer("");
                      setStage3Message("");
                      setStage3Hint("");
                    }}
                  >
                    Try Again
                  </button>
                </>
              )}

              {stage3Message === "CORRECT!" && (
                <>
                  <div
                    className="feedback correct-feedback"
                    style={{ marginTop: "18px" }}
                  >
                    CORRECT! +3 XP
                  </div>

                  <button
                    type="button"
                    className="save-button next-button"
                    style={{ marginTop: "18px" }}
                    onClick={() => {
                      const lastQuestion =
                        stage3ExerciseIndex === level.exercises.length - 1;

                      const lastLevel =
                        stage3LevelIndex === stage3Bank.length - 1;

                      if (!lastQuestion) {
                        setStage3ExerciseIndex(
                          (previous) => previous + 1
                        );
                      } else if (!lastLevel) {
                        setStage3LevelIndex((prev) => prev + 1);
                        setStage3ExerciseIndex(0);
                      }
                      else {
                        setScreen("stage3Report");
                      }

                      setStage3Answer("");
                      setStage3Message("");
                      setStage3Hint("");
                      setStage3HintUsed(false);
                    }}
                  >
                    {stage3LevelIndex ===
                      stage3Bank.length - 1 &&
                      stage3ExerciseIndex ===
                      level.exercises.length - 1
                      ? "Complete Module 3"
                      : "NEXT QUESTION →"}
                  </button>
                </>
              )}
            </div>
          </section>
        </div>
      </div>
    );
  }

  /* =======================================================
     STAGE 3 PROGRESS REPORT
     ======================================================= */

  if (screen === "stage3Report") {
    const stage3Bank =
      playStage3Levels && playStage3Levels.length > 0
        ? playStage3Levels
        : getStage3LevelsForClass(selectedClass);

    const totalStage3Questions = stage3Bank.reduce(
      (sum, item) => sum + item.exercises.length,
      0
    );

    const percentage = totalStage3Questions
      ? Math.round((stage3Score / (totalStage3Questions * 3)) * 100)
      : 0;

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("teacher")}
        <div className="page">
          <section className="complete-card">
            <div className="complete-icon"><IconAward size={36} /></div>
            <p className="eyebrow">Module 03 Assessment Completed</p>
            <h1>GREAT WORK!</h1>
            <h2>{studentName}</h2>
            <p>YOU COMPLETED WRITING & UNDERSTANDING PRACTICE.</p>

            <div className="final-score" style={{ margin: "25px 0" }}>
              {stage3Score} XP
              <div style={{ fontSize: "18px", marginTop: "8px" }}>
                {totalStage3Questions} ACTIVITIES COMPLETED
              </div>
            </div>

            <div className="analysis-item" style={{ marginBottom: "20px" }}>
              <span><IconTarget size={16} /></span>
              <strong>WIZARD CASTLE SCORE</strong>
              <p>{percentage}%</p>
            </div>

            <StageComprehensiveAnalysis
              stageKey="stage3"
              stageName="Module 03: Written Expression & Language Encoding"
              performance={stagePerformance.stage3}
              totalQuestions={totalStage3Questions}
              studentName={studentName}
              studentClass={selectedClass}
              score={stage3Score}
              onRestart={() => enterStageThree()}
              onNextStage={enterStageFour}
              nextStageTitle="Continue to Module 04 (Numerical Cognition) →"
            />
          </section>
        </div>
      </div>
    );
  }

  /* =======================================================
     STAGE 1 GAME — VISUAL PERCEPTION & DISCRIMINATION
     ======================================================= */
  if (screen === "stage1") {
    const level = playStage1Levels[levelIndex] || playStage1Levels[0];
    const exercise = level?.exercises?.[exerciseIndex] || level?.exercises?.[0];
    if (!level || !exercise) {
      return (
        <div className="app">
          <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
          <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
          {renderAppHeader("stages")}
          <div className="page" style={{ textAlign: "center", padding: "80px 20px" }}>
            <div className="stage-card" style={{ maxWidth: 500, margin: "0 auto", padding: 30 }}>
              <h2>Mirror Glyph Grove Ready</h2>
              <p style={{ margin: "16px 0 24px" }}>Visual exercises for Class {selectedClass} are ready.</p>
              <button className="save-button" onClick={() => { setLevelIndex(0); setExerciseIndex(0); }}>Begin Eagle Eye</button>
            </div>
          </div>
        </div>
      );
    }

    const classNumber = getNormalizedClassNumber(studentClass || selectedClass);

    const classProgress =
      savedProgress?.stage1?.classes?.[
      String(classNumber)
      ] || createEmptyClassProgress();

    const completedIds =
      classProgress.completedQuestionIds || [];

    const totalExercises = 27;

    const currentLevelCompleted =
      level.exercises.filter((item) =>
        completedIds.includes(item.id)
      ).length;

    const currentCompleted =
      classProgress.completedQuestions || 0;

    const overallProgress =
      Math.round(
        (currentCompleted /
          totalExercises) *
        100
      );

    const levelProgress =
      Math.round(
        (currentLevelCompleted /
          level.exercises.length) *
        100
      );

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("stages")}
        <div className="page">

          <div className="top-bar">

            <button
              className="back-button"
              onClick={() => {
                window.speechSynthesis?.cancel();
                setScreen("stages");
              }}
            >
              ← STAGES
            </button>

            <div className="score-display">
              {stageScore} XP
            </div>

          </div>

          <section className="stage-card">

            <p className="eyebrow">
              Class {classNumber} • Module 01: Visual Perception
            </p>

            <h1>
              Visual Perception & Orthography
            </h1>

            <p className="stage-description">
              SHARPEN YOUR EAGLE VISION! COMPARE PATTERNS AND FIND THE EXACT MATCH.
            </p>

            {/* LEVEL TABS */}

            <div className="level-tabs">

              {playStage1Levels.map(
                (item, index) => (
                  <div
                    key={item.id}
                    className={
                      "level-tab " +
                      (index === levelIndex
                        ? "active"
                        : classProgress.completedLevels?.includes(
                          item.id
                        )
                          ? "completed"
                          : "")
                    }
                  >

                    <span>
                      {classProgress.completedLevels?.includes(
                        item.id
                      )
                        ? <IconCheck size={14} />
                        : item.id}
                    </span>

                    <div>

                      <strong>
                        {item.title}
                      </strong>

                      <small>
                        {item.difficulty}
                      </small>

                    </div>

                  </div>
                )
              )}

            </div>

            {/* OVERALL PROGRESS */}

            <div className="progress-area">

              <div className="progress-label">

                <span>
                  Module 01 Progress
                </span>

                <span>
                  {currentCompleted} / 27
                </span>

              </div>

              <div className="progress-track">

                <div
                  className="progress-fill"
                  style={{
                    width:
                      `${overallProgress}%`,
                  }}
                />

              </div>

              <p
                style={{
                  textAlign: "center",
                  marginTop: "8px",
                  fontWeight: "700",
                }}
              >
                {overallProgress}% COMPLETED
              </p>

            </div>

            {/* CURRENT LEVEL PROGRESS */}

            <div className="progress-area">

              <div className="progress-label">

                <span>
                  {level.title} PROGRESS
                </span>

                <span>
                  {currentLevelCompleted} / 9
                </span>

              </div>

              <div className="progress-track">

                <div
                  className="progress-fill"
                  style={{
                    width:
                      `${levelProgress}%`,
                  }}
                />

              </div>

              <p
                style={{
                  textAlign: "center",
                  fontWeight: "700",
                  marginTop: "8px",
                }}
              >
                {currentLevelCompleted} / 9
                QUESTIONS COMPLETED
              </p>

            </div>

            {/* VISUAL QUESTION */}

            <div className="exercise-card">

              <div className="exercise-header">

                <span className="exercise-type">
                  Module 01: Visual Perception
                </span>

                <span>
                  QUESTION {exerciseIndex + 1} / 9
                </span>

              </div>

              <h2>
                {exercise.question}
              </h2>

              <div className="big-letter">
                {exercise.visual}
              </div>

              <div className="listening-hint">
                Compare options carefully and identify the exact match.
                IT CAREFULLY WITH EACH OPTION.
              </div>

              {/* OPTIONS — NO AUDIO */}

              <div className="answer-grid">

                {exercise.options.map(
                  (option) => (
                    <button
                      key={option}
                      className={
                        "answer-button " +
                        (stageAnswer === option
                          ? option ===
                            exercise.answer
                            ? "correct"
                            : "wrong"
                          : "")
                      }
                      onClick={() =>
                        answerStageQuestion(
                          option
                        )
                      }
                      disabled={
                        Boolean(stageMessage) &&
                        !stageMessage.includes("Wrong")
                      }
                    >
                      {option}
                    </button>
                  )
                )}

              </div>

              {/* HINT / RETRY — ONLY AVAILABLE AFTER AN INCORRECT ANSWER */}

              {stageMessage &&
                stageMessage.includes("Wrong") && (
                  <div
                    className="hint-panel"
                    style={{
                      marginTop: "18px",
                      padding: "16px",
                      borderRadius: "14px",
                      border: "2px solid #f0c75e",
                      background: "#fff9e6",
                      textAlign: "center",
                    }}
                  >
                    {!hintUsed && !stageHint && (
                      <button
                        type="button"
                        className="btn-unlock-clue"
                        onClick={useStage1Hint}
                        disabled={stageScore < 5}
                      >
                        <IconLightbulb size={16} /> 💡 Conceptual Hint (-5 XP)
                      </button>
                    )}

                    {stageScore < 5 &&
                      !hintUsed && (
                        <p
                          style={{
                            margin: "10px 0 0",
                            fontWeight: "700",
                          }}
                        >
                          You need at least 5 XP to unlock a hint.
                        </p>
                      )}

                    {stageHint && (
                      <div className="shape-fact-card pedagogical-clue-card" style={{ margin: "14px 0" }}>
                        <div className="shape-fact-header">
                          <span className="shape-fact-title">
                            <IconLightbulb size={18} /> 💡 PEDAGOGICAL HINT
                          </span>
                          <button
                            type="button"
                            className="shape-fact-audio-btn read-aloud-btn"
                            onClick={() => {
                              if ("speechSynthesis" in window) {
                                window.speechSynthesis.cancel();
                                const u = new SpeechSynthesisUtterance(stageHint);
                                u.rate = 0.85;
                                window.speechSynthesis.speak(u);
                              }
                            }}
                          >
                            <IconVolume size={14} /> 🔊 Read Hint Aloud
                          </button>
                        </div>
                        <div className="shape-fact-body">
                          {stageHint}
                        </div>
                      </div>
                    )}

                    <button
                      type="button"
                      className="primary-button"
                      onClick={() => {
                        setStageAnswer("");
                        setStageMessage("");
                      }}
                      style={{
                        marginTop: "12px",
                      }}
                    >
                      Try Again
                    </button>
                  </div>
                )}

              {/* FEEDBACK */}

              {stageMessage && (
                <div
                  className={
                    stageMessage.includes(
                      "Correct"
                    )
                      ? "feedback correct-feedback"
                      : "feedback wrong-feedback"
                  }
                >
                  {stageMessage}
                </div>
              )}

              {/* NEXT */}

              {stageMessage && (
                <button
                  className="save-button next-button"
                  onClick={nextExercise}
                >
                  {exerciseIndex === 8
                    ? levelIndex === 2
                      ? "Complete Module 1"
                      : "View Level Report"
                    : "NEXT QUESTION →"}
                </button>
              )}

              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  gap: "12px",
                  flexWrap: "wrap",
                  marginTop: "20px",
                }}
              >

                <button
                  className="back-button"
                  onClick={goBackQuestion}
                >
                  ← PREVIOUS QUESTION
                </button>

                <button
                  className="secondary-button"
                  onClick={restartStageOne}
                >
                  Restart Level
                </button>

              </div>

              <div
                className="analysis-note"
                style={{
                  marginTop: "18px",
                }}
              >
                Response recorded
                AUTOMATICALLY AFTER EVERY QUESTION.
              </div>

            </div>

          </section>

        </div>
      </div>
    );
  }

  /* =======================================================
     LEVEL PROGRESS REPORT
     ======================================================= */

  if (screen === "levelReport") {
    const classNumber = getNormalizedClassNumber(studentClass || selectedClass);

    const completedLevel =
      playStage1Levels[
      completedLevelNumber - 1
      ];

    const classProgress =
      savedProgress?.stage1?.classes?.[
      String(classNumber)
      ] || createEmptyClassProgress();

    const completedQuestionsForLevel =
      classProgress.completedQuestionIds?.length || 0;

    const overallPercentage =
      Math.round(
        (completedQuestionsForLevel / 27) *
        100
      );

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("stages")}
        <div className="page">

          <section className="complete-card">

            <div className="complete-icon"><IconAward size={36} /></div>

            <p className="eyebrow">
              CLASS {classNumber} • LEVEL{" "}
              {completedLevelNumber} COMPLETE
            </p>

            <h1>
              {completedLevel?.title}
            </h1>

            <h2>
              WELL DONE,{" "}
              {studentName || "STUDENT"}!
            </h2>

            <p>
              YOU FINISHED ALL 9 QUESTIONS
              IN THIS LEVEL.
              <br />
              YOUR PROGRESS HAS BEEN SAVED.
            </p>

            <div className="final-score">

              9 / 9 Complete

              <div
                style={{
                  fontSize: "18px",
                  marginTop: "8px",
                }}
              >
                LEVEL QUESTIONS COMPLETED
              </div>

            </div>

            <div className="analysis-grid">

              <div className="analysis-item">
                <span><IconBookOpen size={16} /></span>
                <strong>LEVEL PROGRESS</strong>
                <p>9 / 9</p>
              </div>

              <div className="analysis-item">
                <span><IconTarget size={16} /></span>
                <strong>STAGE PROGRESS</strong>
                <p>
                  {completedQuestionsForLevel} / 27
                </p>
              </div>

              <div className="analysis-item">
                <span><IconTarget size={16} /></span>
                <strong>COMPLETION</strong>
                <p>
                  {overallPercentage}%
                </p>
              </div>

              <div className="analysis-item">
                <span><IconLayers size={16} /></span>
                <strong>SAVED</strong>
                <p>YES</p>
              </div>

            </div>

            <div className="progress-area">

              <div className="progress-label">
                <span>
                  OVERALL EAGLE EYE PROGRESS
                </span>

                <span>
                  {completedQuestionsForLevel} / 27
                </span>
              </div>

              <div className="progress-track">

                <div
                  className="progress-fill"
                  style={{
                    width:
                      `${overallPercentage}%`,
                  }}
                />

              </div>

            </div>

            <div className="analysis-note">
              Every response in this assessment level
              HAS BEEN SAVED.
              <br />
              You may proceed to
              THE NEXT LEVEL AT ANY TIME.
            </div>

            <button
              className="save-button"
              onClick={() => {
                if (
                  completedLevelNumber <
                  playStage1Levels.length
                ) {
                  setLevelIndex(
                    completedLevelNumber
                  );

                  setExerciseIndex(0);
                  setStageAnswer("");
                  setStageMessage("");

                  setScreen("stage1");
                } else {
                  setScreen("stage1Report");
                }
              }}
            >
              {completedLevelNumber <
                playStage1Levels.length
                ? `Proceed to Level ${completedLevelNumber + 1
                }`
                : "View Assessment Report"}
            </button>

            <button
              className="secondary-button"
              onClick={() =>
                setScreen("stages")
              }
            >
              ← BACK TO REALMS
            </button>

          </section>

        </div>
      </div>
    );
  }

  /* =======================================================
     STAGE 1 PROGRESS REPORT
     ======================================================= */

  if (screen === "stage1Report") {
    const classNumber = getNormalizedClassNumber(studentClass || selectedClass);

    const classProgress =
      savedProgress?.stage1?.classes?.[
      String(classNumber)
      ] || createEmptyClassProgress();

    const totalQuestions = 27;

    const completedQuestions =
      classProgress.completedQuestions || 0;

    const correctQuestions =
      classProgress.correctQuestionIds?.length || 0;

    const percentage =
      Math.round(
        (correctQuestions /
          totalQuestions) *
        100
      );

    return (
      <div className="app">
        <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
        <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
        {renderAppHeader("teacher")}
        <div className="page">

          <section className="complete-card">

            <div className="complete-icon">
              <IconAward size={36} />
            </div>

            <p className="eyebrow">
              Class {classNumber} • Module 01 Assessment Completed
            </p>

            <h1>
              AMAZING WORK!
            </h1>

            <h2>
              {studentName}
            </h2>

            <p>
              YOU COMPLETED ALL 27 VISUAL
              QUESTIONS FOR CLASS {classNumber}.
              <br />
              YOUR PROGRESS HAS BEEN SAVED.
            </p>

            <div
              className="final-score"
              style={{
                margin: "25px 0",
              }}
            >
              {completedQuestions} / 27

              <div
                style={{
                  fontSize: "18px",
                  marginTop: "8px",
                }}
              >
                QUESTIONS COMPLETED
              </div>
            </div>

            <div
              className="analysis-grid"
              style={{
                marginTop: "20px",
              }}
            >

              <div className="analysis-item">
                <span><IconStar size={16} /></span>

                <strong>
                  SCORE
                </strong>

                <p>
                  {correctQuestions} / 27
                </p>
              </div>

              <div className="analysis-item">
                <span><IconTarget size={16} /></span>

                <strong>
                  ACCURACY
                </strong>

                <p>
                  {percentage}%
                </p>
              </div>

              <div className="analysis-item">
                <span><IconBookOpen size={16} /></span>

                <strong>
                  LEVELS
                </strong>

                <p>
                  3 / 3
                </p>
              </div>

              <div className="analysis-item">
                <span><IconLayers size={16} /></span>

                <strong>
                  SAVED
                </strong>

                <p>
                  YES
                </p>
              </div>

            </div>

            <div
              className="progress-area"
              style={{
                marginTop: "30px",
              }}
            >

              <div className="progress-label">

                <span>
                  STAGE 1 COMPLETION
                </span>

                <span>
                  100%
                </span>

              </div>

              <div className="progress-track">

                <div
                  className="progress-fill"
                  style={{
                    width: "100%",
                  }}
                />

              </div>

            </div>

            <div className="analysis-note">

              Class {classNumber} Module 01 Evaluation:

              <br />

              Level 1: 9 Visual Perception Items

              <br />

              Level 2: 9 Visual Perception Items

              <br />

              Level 3: 9 Visual Perception Items

              <br />

              All 27 Assessment Items Recorded

            </div>

            <p
              style={{
                fontSize: "18px",
                fontWeight: "600",
                margin: "25px 0",
              }}
            >
              Assessment completed. Visual perception responses recorded.
            </p>

            <StageComprehensiveAnalysis
              stageKey="stage1"
              stageName="Module 01: Visual Perception & Orthography"
              performance={stagePerformance.stage1}
              totalQuestions={totalQuestions}
              studentName={studentName}
              studentClass={classNumber}
              score={correctQuestions * 3}
              onRestart={restartStageOne}
              onNextStage={enterStageTwo}
              nextStageTitle="Continue to Module 02 (Auditory Processing) →"
            />

          </section>

        </div>
      </div>
    );
  }

  return (
    <div className="app">
      <SpatialBackground3D pulseTrigger={spatialPulse} pulseType={pulseType} />
      <ParticleFX trigger={fxTrigger} score={fxScore} combo={fxCombo} />
      {renderAppHeader("home")}
      <div className="page" style={{ textAlign: "center", padding: "100px 20px" }}>
        <div className="stage-card" style={{ maxWidth: 540, margin: "0 auto", padding: 40 }}>
          <h2 style={{ fontFamily: "var(--font-heading)", color: "#2d1a04", marginBottom: 12 }}>Expedition Trail Cleared</h2>
          <p style={{ margin: "16px 0 24px", color: "#614e3e", fontSize: "1.05rem" }}>
            You have ventured beyond mapped jungle territories! Tap below to return to expedition headquarters.
          </p>
          <button className="save-button" onClick={() => setScreen("home")}>
            Return to Expedition Camp
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;
